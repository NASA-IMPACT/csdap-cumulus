# run_migration__2026_Jul_28__Add_CMR_And_Tracking_Cols.py

# This is code is not part of the main_interface because it is meant to be a one-off run once during building and never again.
# # Once this code is run, then we uncomment changes to the datamodel, so a fresh rebuild will already include these columns

# # Code Plan
# - Track Execution Time
# - Get the Database Names
# - Get the size (number of rows) of the database BEFORE running
# - Call the SQLite Wrapper function to run the migration for each database
# - Get the size (number of rows) of the database AFTER running

# THESE CHANGES ARE ADDITIVE ONLY

# Imports
from pathlib import Path
import shutil
import time
from lib.sqlite_wrapper import DatabaseManager


base_db_path_backups = "gts_sqliteDBs_AUTO_BACKUP"


# create_dir_if_not_exist(dir_path=base_db_path_backups)
# create_dir_if_not_exist(dir_path="gts_sqliteDBs_AUTO_BACKUP")
def create_dir_if_not_exist(dir_path):
    # Define the target directory path
    dir_path__PATH_Obj = Path(dir_path) #("path/to/directory")

    # Create the directory safely
    dir_path__PATH_Obj.mkdir(parents=True, exist_ok=True)


# Perform the migration (raw sql code)
def migrate_db(db_name_key='DEFAULT'):
    print(f'    Migrating Database: {db_name_key}')
    
    # Time Start
    time__start__Current_DB__Migration = time.perf_counter()

    # Calling this on the Database manager
    db_migration_result = DatabaseManager.run__one_time_migration__2026_Jul_28__Add_CMR_And_Tracking_Cols(db_name_key=db_name_key) # "WV03"
    print(f'      db_migration_result: {db_migration_result}')

    # Time End
    time__end__Current_DB__Migration = time.perf_counter()
    print(f'    ------------------------------------------------------------------------------------------------')
    print(f"    - DB Migration {db_name_key}: Execution time: {time__end__Current_DB__Migration - time__start__Current_DB__Migration:.6f} seconds")
    print(f'    ------------------------------------------------------------------------------------------------')


# IMPORTANT - RUNNING THIS OVERWRITES THE BACKUPS EACH TIME
def backup_db(db_name_key='DEFAULT'):
    print(f'    Backing up DB: {db_name_key}')

    # Time Start
    time__start__Current_DB__Backup = time.perf_counter()

    # Makes sure to also copy the 'default.db'
    db_file_name = db_name_key
    if(db_file_name == "DEFAULT"):
        db_file_name = "default"
    
    # Getting the Paths
    current_db_file_path        = DatabaseManager.get_db_path(db_name_key=db_name_key)
    current_db_backup_file_path = f'{base_db_path_backups}/{db_name_key}.db.bak' 

    print(f'      DB File Path:        {current_db_file_path}')
    print(f'      DB Backup File Path: {current_db_backup_file_path}')

    try:
        shutil.copy2(current_db_file_path, current_db_backup_file_path)
        print(f"      [Backup] Created temporary backup at {current_db_backup_file_path}")
        print(f'      Backup Completed for DB {db_name_key} at Path: {current_db_backup_file_path}')
    except Exception as e:
        print(f"      [Abort] Could not create backup: {e}. Aborting migration.")
    
    # Time End
    time__end__Current_DB__Backup = time.perf_counter()
    print(f'    ------------------------------------------------------------------------------------------------')
    print(f"    - DB Backup {db_name_key}: Execution time: {time__end__Current_DB__Backup - time__start__Current_DB__Backup:.6f} seconds")
    print(f'    ------------------------------------------------------------------------------------------------')

    return

# Main Function Entry Point
def run_migrations():
    print(f'Running: run_migration__2026_Jul_28__Add_CMR_And_Tracking_Cols')
    # Ensure we have a backup directory
    create_dir_if_not_exist(dir_path=base_db_path_backups)

    # The DB Keys 
    DB_Keys = ["DEFAULT", "GE01", "WV01", "WV02", "WV03", "WV04"]


    # Iterate all keys
    print(f'  Processing Keys')
    for DB_Name_Key in DB_Keys:
        
        print(f'')
        print(f'======================================================================')
        print(f'  About to process: {DB_Name_Key}')

        # Check the Size
        print(f'')
        num_of_rows__CurrentDB = DatabaseManager.get_count_num_of_rows_in_table(DB_Name_Key) # "WV03"
        print(f'    DB {DB_Name_Key}:  Granule Table Row Count: {num_of_rows__CurrentDB}')

        # Backup the DB
        print(f'')
        backup_db(db_name_key=DB_Name_Key)

        # Migrate the DB
        print(f'')
        migrate_db(db_name_key=DB_Name_Key)



        print(f'======================================================================')
        print(f'')
        pass

    print(f'')
    print(f'IMPORTANT -- AFTER MIGRATIONS SUCCEEDED, GO UPDATE THE DATA MODEL FOR THE NEW COLUMNS')
    print(f'')

    ## Actually perform the backups for each DB
    #SQLiteDB_name_key   = 'WV04'


# --- Wrapping this in a timer so we can track execution time ---
# Timer Start
time__start = time.perf_counter()

# Actual Entry Point - With Timing
run_migrations()

time__end = time.perf_counter()
print(f'------------------------------------------------------------------------------------------------')
print(f"- TOTAL Execution time: {time__end - time__start:.6f} seconds")
print(f'------------------------------------------------------------------------------------------------')



# END OF FILE