# README.md


## What is this?

This is a tool for finding, verifying and executing the deletion of granules from the delivery bucket that have already been confirmed to be ingested and exist in the published production environment.

This is a tool to address a growing tech debt problem around ingests.
Currently, granules are placed in a delivery bucket. Those granules are then copied to a production bucket during the ingest process. After the ingest is completed, the original copies of the granules in the delivery bucket remain.

This means that two copies of the granules remain.  This tool addresses that problem periodically, in large steps.


#### Where this Runs

This tool was built to be run from an EC2 instance within the same AWS account that owns the granule delivery bucket.

#### How this works

This was written in Python 3.x and uses local SQLite Database to track the status.
That database is the prototype to a planned, more generic `Granule Tracking System` or `GTS`.
This program has multiple pathways that can be executed to perform varioius functions.
The functions are, Creating the local SQLite Databases, outputing DB metrics, Loading/syncing data from DymamoDB to the SQLite DB, running the manifest downloads, comparing the manifests, verifying the CMR presence, Deleting the specific Delivery source granules that are marked as ready for deletes.

Examples of how to use.
Example: python code/main_interface.py --automation --value 3
Example: python code/main_interface.py --automation --value 71
For a list of all currently supported functions, examine `code/main_interface.py`.  Scroll down to near the bottom to see the list of options.
All useful code functionality can be traced from that entry point and `value` number paths.
Note: Just running `python code/main_interface.py` will echo the choices and let you choose via terminal which execution path to take.
Using the --automation and --value flags skip the interactive questions and takes your execution directly to the path that was selected by the value.

#### Limitations

This was currently written to address Maxar/Vantor specific datasets (WV01, WV02, WV03, WV04 and GE01).
If there is need to run this against other datasets or datasets from other vendors, there may be some changes needed in order to match the structure of those datasets.

## Getting this to run

Examine the code/requirements.txt file for python dependencies.

#### Replacing Placeholder Strings

This is an incomplete list of string replacements and their meanings.  When you see characters `<text>`, this is where you must replace with your string value.
```
<AWS_Region>          // Your AWS Region
<delivery-bucket-name>      // Bucket where the files land before an ingest.  This is also the place where leftover granules that need to be deleted exist after they have been ingested.
<gts-utilities-bucket-name>   // Bucket where utilities, non-granule files, live, like backups of the EC2 drives, the code for this application when copied over, etc.
<manifest-bucket-name>      // Bucket where manifests are delivered
<dynamodb_table_name>       // DynamoDB Table Name
<prod-granule-bucket-name>    // The PROD bucket name where the published granules live.
<prod-dr-granule-bucket-name>   // The PROD ORCA bucket name where the backups of the published granules live.

<path/to/granule/root>      // Directory path (or s3 key path) to the root level of where granules are stored.
<path/to/utility/root>      // Directory path (or s3 key path) to the root level of where utility info is stored.
<path/to/manifest/root>     // Directory path where manifests are stored

<prod_manifest_parent_dir>    // Directory path where the prod manifest gets delivered
<prod_dr_manifest_parent_dir>   // Directory path where the prod DR manifest gets delivered (dr - disaster recovery, aka ORCA)



<AWS_Region>          // Your AWS Region
<gts-utilities-bucket-name>   // The bucket used for backups and code transfers
<Code_Destination_Key_Path>   // When transferring code from local environment to EC2 this is the key path where mgts.zip goes.
<Expected_Backup_Key_Path>    // When running an S3 backup, this is the S3 Key path where the backup files go
<path/to/specific/granule>    // A path to a specific granule, usually found in example or test code
<dynamodb_table_name>
<delivery-bucket-name>
```

#### IAM Configuration

Look in the file `server_config/AWS_Policies.txt` for an example configuration of policies that should allow an EC2 instance to access, read and write to the resources it needs.

#### EC2 Setup Instructions

- Use a Ubuntu AMI that is current and validated for security
- Use 2 storage volumes, one smaller one (around 40 gigs should be more than enough) for the operating system that is always attached to the EC2, and a second one (200 to 500 gigs should be enough depending on how large the manifests and SQLite DB will grow) where the data and code will live and execute.
- Attach and make the second storage volume permenant 
- Use at least a t3.large so there is enough ram and vcpus to run the processes
- After the EC2 is launched, attach the IAM Policy to it which contains the IAM configuration listed above
- Use SSM to connect to the EC2 Instance
- Follow the HELPER_GUIDES.txt file to get the code onto the EC2 instance.

## How to Use this (Operations)

After the above items are all setup.
Refer to the 'HELPER_GUIDES.txt' file.


## Future Goals
The main future goals are to 
(1) connect verification and granule status tracking to the end of a continous ingest run which is kind of a prerequisite for automating this process, and
(2) move this system to a cloud native process with it's own Granule Tracking RDS DB and lambda trigger functions, and let it run with significant automation.
Step 1 is external and should be done first
Step 2 requires some level of effort to rewrite some functionality and link things together.


## More Details and Code Comments

This project sits in a grey area between an occasionally usable program and a big step toward the automation of ingesting into Earthdata.
More details can be found in the code comments.
Some of these are still in a scattered state, but there should be enough substance for the porting work and cloud native automation which would be the next significant steps.


