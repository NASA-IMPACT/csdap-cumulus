# run_tests_cmr_requests.py


from lib.cmr_wrapper    import CMRRequestManager
from lib.sqlite_wrapper import DatabaseManager

from datetime import datetime, timezone, timedelta
import time
import sys



# # Delay Helper
# If I want to put a min number of seconds between API requests, this lets us calculate how long we need to sleep after running some code.
# Just pass in the time__start (which should have been captured BEFORE any api request was made (or other process that requires this min sleep duration))
def get_sleep_seconds_to_wait(min_time_needed_to_wait=2.5, time__start=time.time()):
    sleep_seconds = 0

    # Calculate elapsed time since the time that was passed in
    time__elapsed = time.time() - time__start

    # How much time do we need to sleep
    sleep_seconds_needed = min_time_needed_to_wait - time__elapsed
    if (sleep_seconds_needed < 0.0):
        sleep_seconds = 0.0
    else:
        sleep_seconds = sleep_seconds_needed

    return sleep_seconds


# Scratch Notes
#new_granule_update_obj['num_of_attempts_cmr_check'] = selected_db_granule.num_of_attempts_cmr_check     # Piping in the number of checks from the existing DB Granule
#new_granule_update_obj['num_of_attempts_cmr_check'] = current_granule__num_of_attempts_cmr_check
#new_granule_update_obj['num_of_attempts_cmr_check'] = 0


# Testing the Update Object in isolation
def run_SQL_Update_Function_Test_03():
    print(f'')
    print(f'run_SQL_Update_Function_Test_03:      STARTED')
    print(f'')

    # Must have the DB Name key for this operation
    db_name_key = "WV01"

    # When a batch is run, we get a datetime object to store the attempt time
    batch_date_time = datetime.now(timezone.utc)

    # An array to hold all the update objects that are the same shape as what is already in the CMR API function.
    granule_id_update_objects_list = {} # [] 

    # Test Granule: 1
    to_save__granule_id_1         = "WV01_20171119060820_10200100697CF800_17NOV19060820-P1BS-501718201020_01_P005" # "GRANULE_ID_HERE" 
    to_save__granule_concept_id_1 = "G2744188461-CSDA" #"abcdefg"
    #
    update_obj__granule_1 = {}
    update_obj__granule_1['is__Create_New_Granule']           = False # is_new_granule               # False     # This is for when a granule is not already in our local database but comes back from CMR, this can happen if we run this process after ingesting new data but before processing manifests. 
    update_obj__granule_1['num_of_attempts_cmr_check']        = 0
    update_obj__granule_1['batch_date_time']                  = batch_date_time
    update_obj__granule_1['needs_update']                     = True
    update_obj__granule_1['is__CMR_Found']                    = True
    update_obj__granule_1['is__CMR_Downloadbale']             = True # is_downloadable
    update_obj__granule_1['to_save__granule_concept_id']      = to_save__granule_concept_id_1
    #
    # Force the ID to be a string (just in case it is not)
    to_save__granule_id_1 = f'{to_save__granule_id_1}'
    #
    # Save the update object to the update objects list, referencing it where the key is the granule id of the current granule.
    # This validation step is important, even during this live test call.
    can_add_this_granule = CMRRequestManager.check_granule_id_against_db_name_key(db_name_key=db_name_key, granule_id=to_save__granule_id_1) 
    if(can_add_this_granule == True):
        granule_id_update_objects_list[to_save__granule_id_1] = update_obj__granule_1
    else:
        print(f'    WARNING: CMR Returned a Granule ID that does not match the DB Name Key!: The DB Name Key: {db_name_key} and Granule ID: {to_save__granule_id_1}. Skipping the Update Object.')

    # Test Granule: 2
    to_save__granule_id_2         = "WV01_20171119060842_1020010069302900_17NOV19060842-P1BS-501699589090_02_P001" # "ANOTHER_GRANULE_ID_HERE" 
    to_save__granule_concept_id_2 = "G2744188694-CSDA" #"hijklmnop"
    update_obj__granule_2 = {}
    update_obj__granule_2['is__Create_New_Granule']           = False # is_new_granule               # False     # This is for when a granule is not already in our local database but comes back from CMR, this can happen if we run this process after ingesting new data but before processing manifests. 
    update_obj__granule_2['num_of_attempts_cmr_check']        = 0
    update_obj__granule_2['batch_date_time']                  = batch_date_time
    update_obj__granule_2['needs_update']                     = True
    update_obj__granule_2['is__CMR_Found']                    = True
    update_obj__granule_2['is__CMR_Downloadbale']             = True # is_downloadable
    update_obj__granule_2['to_save__granule_concept_id']      = to_save__granule_concept_id_2
    #
    # Force the ID to be a string (just in case it is not)
    to_save__granule_id_2 = f'{to_save__granule_id_2}'
    #
    # Save the update object to the update objects list, referencing it where the key is the granule id of the current granule.
    # This validation step is important, even during this live test call.
    can_add_this_granule = CMRRequestManager.check_granule_id_against_db_name_key(db_name_key=db_name_key, granule_id=to_save__granule_id_2) 
    if(can_add_this_granule == True):
        granule_id_update_objects_list[to_save__granule_id_2] = update_obj__granule_2
    else:
        print(f'    WARNING: CMR Returned a Granule ID that does not match the DB Name Key!: The DB Name Key: {db_name_key} and Granule ID: {to_save__granule_id_2}. Skipping the Update Object.')

    

    # Check each Granule and call the update function based on it's type and switches
    #
    # # Reference
    #
    # CMR Update Path: Granule was found in the CMR and exists in our DB
    # # rows_affected = DatabaseManager.update__granule__was_found_in_CMR(db_name_key="DEFAULT", granule_id="default_granule_id", cmr_concept_id="UNKNOWN", is__cmr_downloadable=True)
    #
    # CMR Update Path: Granule was NOT found in the CMR but does exist in our DB
    # # rows_affected = DatabaseManager.update__existing_granule__was_NOT_found_in_CMR(db_name_key="DEFAULT", granule_id="default_granule_id", num_of_attempts_cmr_check=1)
    #
    # CMR Update Path: NEW Granule was found in the CMR that does NOT exist in our DB - Creating a new entry to catch it
    # # rows_affected = DatabaseManager.create__new_granule__from_found_in_CMR(db_name_key="DEFAULT", granule_id="default_granule_id", cmr_concept_id="UNKNOWN", is__cmr_downloadable=True)


    # ############################################################
    # # UPDATE BLOCK #
    # ############################################################
    #
    # Keeping track of the update paths - Initializing data
    update_paths_log_obj = {}
    update_paths_log_obj['update_path_count__Local_Granule_Found_in_CMR']       = 0
    update_paths_log_obj['update_path_count__Local_Granule_NOT_Found_in_CMR']   = 0
    update_paths_log_obj['update_path_count__NEW_Granule_Found_in_CMR']         = 0

    granule_update_object_keys = granule_id_update_objects_list.keys()
    for granule_update_object_key in granule_update_object_keys:
        print(f'')
        print(f'  About to process granule_update_object_key: {granule_update_object_key}')
        current_update_obj = granule_id_update_objects_list[granule_update_object_key]

        # First off, does this object actually need an update:
        needs_update = current_update_obj["needs_update"]

        # Only proceed if this object DOES need an update
        if(needs_update == True):
            
            # Which Update path is this one on?
            is__CMR_Found = current_update_obj["is__CMR_Found"]
            if(is__CMR_Found == True):
                
                # Is this a new Granule, or confirming an existing Granule?
                is__Create_New_Granule = current_update_obj['is__Create_New_Granule']
                if(is__Create_New_Granule == True):
                    # Update Path Confirmed:  This is a NEW Granule that was seen in the CMR but not known in the current local DB.
                    # update_path_count__NEW_Granule_Found_in_CMR
                    #
                    # Get Data Needed to do this update.
                    is__CMR_Downloadbale            = current_update_obj['is__CMR_Downloadbale']
                    to_save__granule_concept_id     = current_update_obj['to_save__granule_concept_id']
                    #
                    # Do the Update
                    rows_affected = DatabaseManager.create__new_granule__from_found_in_CMR(db_name_key=db_name_key, granule_id=granule_update_object_key, cmr_concept_id=to_save__granule_concept_id, is__cmr_downloadable=is__CMR_Downloadbale)
                    #
                    # Increment the Update Counter
                    update_paths_log_obj['update_path_count__NEW_Granule_Found_in_CMR']   = update_paths_log_obj['update_path_count__NEW_Granule_Found_in_CMR'] + rows_affected

                else:
                    # Update Path Confirmed:  This existing Granule was found in the CMR Response, store the new info!
                    # update_path_count__Local_Granule_Found_in_CMR
                    #
                    # Get Data Needed to do this update.
                    is__CMR_Downloadbale            = current_update_obj['is__CMR_Downloadbale']
                    to_save__granule_concept_id     = current_update_obj['to_save__granule_concept_id']
                    #
                    # Do the Update
                    rows_affected = DatabaseManager.update__granule__was_found_in_CMR(db_name_key=db_name_key, granule_id=granule_update_object_key, cmr_concept_id=to_save__granule_concept_id, is__cmr_downloadable=is__CMR_Downloadbale)
                    #
                    # Increment the Update Counter
                    update_paths_log_obj['update_path_count__Local_Granule_Found_in_CMR']   = update_paths_log_obj['update_path_count__Local_Granule_Found_in_CMR'] + rows_affected

            else:
                # Update Path Confirmed:  This Granule was NOT found in the CMR Response, increment the attempt
                # update_path_count__Local_Granule_NOT_Found_in_CMR
                #
                # Get Data Needed to do this update.
                num_of_attempts_cmr_check           = current_update_obj['num_of_attempts_cmr_check']
                new__num_of_attempts_cmr_check      = num_of_attempts_cmr_check + 1 # Just incrementing the value
                #
                # Do the Update
                rows_affected = DatabaseManager.update__existing_granule__was_NOT_found_in_CMR(db_name_key=db_name_key, granule_id=granule_update_object_key, num_of_attempts_cmr_check=new__num_of_attempts_cmr_check)

                # Increment the Update Counter
                update_paths_log_obj['update_path_count__Local_Granule_NOT_Found_in_CMR']   = update_paths_log_obj['update_path_count__Local_Granule_NOT_Found_in_CMR'] + rows_affected

    # Now let's print out the update report

    # Outputting stuff so I can verify what happened in the DB
    print(f'')
    print(f'  REPORT for this test')
    print(f'')
    print(f'  db_name_key:                             {db_name_key}')
    print(f'  granule_id_update_objects_list:          {granule_id_update_objects_list}')
    #
    update_path_count__Local_Granule_Found_in_CMR       = update_paths_log_obj['update_path_count__Local_Granule_Found_in_CMR']
    update_path_count__Local_Granule_NOT_Found_in_CMR   = update_paths_log_obj['update_path_count__Local_Granule_NOT_Found_in_CMR']
    update_path_count__NEW_Granule_Found_in_CMR         = update_paths_log_obj['update_path_count__NEW_Granule_Found_in_CMR'] 
    print(f'')
    print(f'  update_path_count__Local_Granule_Found_in_CMR:     {update_path_count__Local_Granule_Found_in_CMR}')
    print(f'  update_path_count__Local_Granule_NOT_Found_in_CMR: {update_path_count__Local_Granule_NOT_Found_in_CMR}')
    print(f'  update_path_count__NEW_Granule_Found_in_CMR:       {update_path_count__NEW_Granule_Found_in_CMR}')
    print(f'')

    

    #
    #print(f'  granule_id_update_objects_list__for_SQL: {granule_id_update_objects_list__for_SQL}')
    #print(f'  Here is a sample Update object with 2 REAL granules and REAL data that were already observed in the DB')
    #
    # # SQL Update Object - an object that is formatted to match what SQL Alchemy will expect (and the support function I'm writing for that part)
    # granule_id_update_objects_list__for_SQL = []
    #
    # # Convert the granule_id_update_objects_list into granule_id_update_objects_list__for_SQL
    # print(f'')
    # print(f'  # Convert the granule_id_update_objects_list into granule_id_update_objects_list__for_SQL')
    # print(f'')
    #
    # # Call the SQLite function that runs the batch update (should update all of these objects at once if it was done it correctly)
    # print(f'')
    # print(f'  # Call the SQLite function that runs the batch update (should update all of these objects at once if it was done it correctly)')
    # print(f'  THAT WAS THE LAST STEP.. is it done?')
    # print(f'  Check the DB for visual validation.')
    # print(f'')
    #
    # # Outputting stuff so I can verify what happened in the DB
    # print(f'')
    # print(f'  REPORT for this test')
    # print(f'')
    # print(f'  db_name_key:                             {db_name_key}')
    # print(f'  granule_id_update_objects_list:          {granule_id_update_objects_list}')
    # print(f'  granule_id_update_objects_list__for_SQL: {granule_id_update_objects_list__for_SQL}')
    # #print(f'  Here is a sample Update object with 2 REAL granules and REAL data that were already observed in the DB')
    # print(f'')

    print(f'')
    print(f'run_SQL_Update_Function_Test_03:      REACHED THE END')
    print(f'')













# This is the improved version of the below function -- All proven debug stuff has ben removed.
def run_integrated_test_02__Full_CMR_Request_And_Processing():
    print(f'')
    print(f'run_integrated_test_02__Full_CMR_Request_And_Processing:      STARTED')
    print(f'')

    # Total Time Tracking - Start Time
    time__total__start = time.time()
    



    # Inputs (Set these Before calling the actual cmr_wrapper function that does all this heavy lifting)
    print(f'run_integrated_test_02__Full_CMR_Request_And_Processing: WARN: HardCoding DB Name Key To WV01 and Concept ID for this test.  The real, live version needs to be dynamic or passed in as an external parameter. ')
    db_name_key                 = "WV01"
    collection_concept_id__LIST = CMRRequestManager.get_collection_concept_id_list()

    # Settings
    print(f'run_integrated_test_02__Full_CMR_Request_And_Processing: WARN: HardCoding Double check these settings before going to the live version.')
    cmr_checking__num_of_batches_to_run                     = 5 #4 # 2   # How many times the outer loop will run.
    cmr_checking__min_delay_seconds_between_api_requests    = 2.5     # How long we should delay between api reqeusts to the CMR.
    cmr_checking__max_retries                               = 3       # Max Retries per granule for selecting from our local database.
    cmr_checking__max_num_of_granules_to_select_per_batch   = 500 #7 #4 #500  # Testing this with 4 at a time, 500 is what we will run in production.
    
    # This shows detailed Granule Data from the CMR.  
    # # Turn this on if I need to debug something on the live server.
    highly_detailed_logging                                 = False #True # False
    #medium_detailed_logging                                 = False 

    # Get the Count of how many Total Granules there are remaining
    total_remaining_count__BEFORE = DatabaseManager.get_remaining_granule_count__for_cmr_API_call(db_name_key=db_name_key, max_retries=cmr_checking__max_retries)


    # Info for the report at the bottom of this function
    report__num_of_batches_attempted = 0
    report__num_of_batches_completed = 0
    report__num_of_updates_made__localDB_granules_not_found_in_cmr  = 0
    report__num_of_updates_made__localDB_granules_found_in_cmr      = 0
    report__num_of_updates_made__new_granules_found_in_cmr          = 0
    report__num_of_errors = 0
    report__error_log = []

    # DRAFT version of the report
    # print(f'Expecting How many granules were processed')
    # print(f'Expecting How many granules were updated (found and updated, removed from the -remaining granule- list)')
    # print(f'Expecting How many granules were NOT FOUND')
    # print(f'Expecting How many granules were FAILED')

    # Output for the log
    print(f'')
    print(f'  About to enter the Batch Granule Processing Loop: Params:')
    print(f'    Settings:')
    print(f'      cmr_checking__num_of_batches_to_run:                     {cmr_checking__num_of_batches_to_run}')
    print(f'      cmr_checking__min_delay_seconds_between_api_requests:    {cmr_checking__min_delay_seconds_between_api_requests}')
    print(f'      cmr_checking__max_retries:                               {cmr_checking__max_retries}')
    print(f'      cmr_checking__max_num_of_granules_to_select_per_batch:   {cmr_checking__max_num_of_granules_to_select_per_batch}')
    print(f'    Params:')
    print(f'      db_name_key:                 {db_name_key}')
    print(f'      collection_concept_id__LIST: {collection_concept_id__LIST}')
    print(f'')
    print(f'      highly_detailed_logging:     {highly_detailed_logging}')
    #print(f'      medium_detailed_logging:     {medium_detailed_logging}')
    print(f'')
    sys.stdout.flush()  # Force Terminal Output (helps with monitoring progress) # Forces all buffered print statements above to output right now

    # Each run through this loop is for a single batch.
    for i in range(cmr_checking__num_of_batches_to_run):
        try:
            # Start tracking the time inside the loop.  I am also using this as a mechanism for delaying the next API Request to the CMR
            time__loop__start = time.time()

            # When a batch is run, we get a datetime object to store the attempt time
            batch_date_time = datetime.now(timezone.utc)

            # Starting a batch, need to increment the attempt counter 
            report__num_of_batches_attempted = report__num_of_batches_attempted + 1

            # Count starts at 0, for logging, adding 1 to it for readability
            current_batch_number = i + 1
            print(f'')
            print(f'  ------------------------------------------------------------------------')
            print(f'    Batch: {current_batch_number} of {cmr_checking__num_of_batches_to_run}: Starting to process a new Batch of {cmr_checking__max_num_of_granules_to_select_per_batch} Granules at Datetime: {batch_date_time}')
            
            # Get the remaining number of granules during this run, Select a batch of granules.
            # These values should change after each update near the end of this outer loop.
            current_granule_rows_remaining_count    = DatabaseManager.get_remaining_granule_count__for_cmr_API_call(db_name_key=db_name_key, max_retries=cmr_checking__max_retries)
            current_granule_rows_list               = DatabaseManager.get_granules_for_cmr_API_call(db_name_key=db_name_key, max_num_of_granules=cmr_checking__max_num_of_granules_to_select_per_batch, max_retries=cmr_checking__max_retries) # max_retries=3 (max_retries is an Optional Param defaulted at 3)

            # Print how many total granules are left, and how many were selected.
            current_num_of_granules_selected = 0
            if(current_granule_rows_list == None):
                print(f'    No granules selected this iteration... Maybe there are no remaining granules in our local database?')
                current_num_of_granules_selected = 0
                current_granule_rows_list = []        # Setting from None to empty list to prevent a for loop error below.
            else:
                current_num_of_granules_selected = len(current_granule_rows_list)
                print(f'    Selected {current_num_of_granules_selected} out of {current_granule_rows_remaining_count} remaining Granules')

            # Making an object that can be used to update the database.
            granule_id_update_objects_list = {}#[]
            #
            # Iterate to load up this update list with an initial keys and information.
            for selected_db_granule in current_granule_rows_list:

                # Setup the new object
                new_granule_update_obj = {}
                new_granule_update_obj['is__Create_New_Granule']    = False     # This is for when a granule is not already in our local database but comes back from CMR, this can happen if we run this process after ingesting new data but before processing manifests.
                new_granule_update_obj['num_of_attempts_cmr_check'] = selected_db_granule.num_of_attempts_cmr_check     # Piping in the number of checks from the existing DB Granule
                new_granule_update_obj['batch_date_time']           = batch_date_time
                #new_granule_update_obj['needs_update']             = False    # This value gets changed at the end
                new_granule_update_obj['needs_update']              = True      # Setting this to True now because if the rest is untouched, that means we have to log an attempt.  This saves an iteration later!
                new_granule_update_obj['is__CMR_Found']             = False     # If it's in this list, it should start as False until shown otherwise..
                new_granule_update_obj['is__CMR_Downloadbale']      = False     # If it's in this list, it should start as False until shown otherwise..

                # Using the granule's id as the key to let me reduce the look up from iterating a list to a direct string array call.
                # This means, that I can later process all updates in a kind of linear way and for all all update types rather than iterating the updates multiple times.
                object_key_name__granule_id = f'{selected_db_granule.granule_id}'
                can_add_this_granule = CMRRequestManager.check_granule_id_against_db_name_key(db_name_key=db_name_key, granule_id=object_key_name__granule_id)
                if(can_add_this_granule == True):
                    granule_id_update_objects_list[object_key_name__granule_id] = new_granule_update_obj
                else:
                    print(f'    WARNING: The DB Name Key: {db_name_key} and Granule ID: {object_key_name__granule_id}. Did not match')

            # Force Terminal Output (helps with monitoring progress) # Forces all buffered print statements above to output right now
            sys.stdout.flush()  

            # # Actually Make the API Request for the whole batch right here.
            # Only run this part of the loop if we actually selected at least 1 granule from the local database.
            if(current_num_of_granules_selected > 0):
                try:
                    # Output for the log
                    print(f'    Making an API Request to the CMR for {current_num_of_granules_selected} selected granules and all of our known collection concept ids...')

                    # Run the CMR API Reqeust
                    cmr_response_JSON, has_api_error = CMRRequestManager.send_CMR_API_Post_Request_For_Granule_Batch(granule_rows_list=current_granule_rows_list, collection_concept_id_list=collection_concept_id__LIST)
                    
                    # Defaults
                    hits = 0
                    items = []
                    if not cmr_response_JSON:
                        print(f'      The response JSON was completely blank.')
                    else:
                        # Getting some of the props and parsing them out
                        hits    = cmr_response_JSON.get('hits', 0)
                        items   = cmr_response_JSON.get('items', [])

                    # Output for the log
                    print(f'    CMR API Request got {hits} hits out of {current_num_of_granules_selected} Granules from our DB selection.')

                    # Only proceed if we got hits (returned results from the CMR), if not, then output a message to the log saying this.
                    if(hits == 0):
                        print(f'    No Granule Search Hits to process from CMR for this batch.  Batch: {current_batch_number} of {cmr_checking__num_of_batches_to_run}')
                    else:
                        # Output for the log
                        print(f'    Iterating through and reading each Granule result hit from the CMR...')

                        # Iterate through each granule result that came from the CMR
                        for cmr_response_item in items:
                            try:
                                # # Guide for processing this JSON - Possibly slightly out dated
                                #
                                # "items[].meta",                   // Item Top Level object, holds top level info
                                # "items[].meta.concept-type",      // Verify this is granule.  Value should be: "granule"
                                # "items[].meta.concept-id",        // The Granule's Concept ID, starts with letter "G" Example: "G2744189394-CSDA"
                                #
                                # "items[].umm",                    // Item Top Level object, holds most of the Granule Metadata 
                                # "items[].umm.GranuleUR",          // Holds the Granule ID (as we know it).  Example: "WV01_20171119060932_102001006BB20B00_17NOV19060932-P1BS-501699587090_03_P033"
                                # "items[].umm.RelatedUrls,"        // Holds a list of Download URLs // To verify if this granule is downloadlable: items[0].umm.RelatedUrls    must exist AND must not be a blank array (have at least one URL property that is not blank AND have a 'Type': that is equal to: 'GET DATA')
                                #
                                # # Extra Stuff
                                # If we want to go deeper, we can analyze the files
                                # This tells us if there is actual file size content
                                # "items[].umm.DataGranule.ArchiveAndDistributionInformation[].SizeInBytes",
                                # # In these keys, we can also get the list of files as well.

                                # Gather all required info.  If any of this fails, we do not have a granule to update (maybe something on the CMR side did not process this granule correctly?)
                                item__meta              = cmr_response_item.get('meta', {})
                                item__concept_type      = item__meta.get('concept-type', "")
                                item__concept_id        = item__meta.get('concept-id', "")
                                #
                                item__umm               = cmr_response_item.get('umm', {})
                                item__GranuleUR         = item__umm.get('GranuleUR', "")
                                #
                                item__RelatedUrls       = item__umm.get('RelatedUrls', [])
                                #
                                # # Getting these down inside of the loop. -- Iterate all URLs to check this stuff, stop when constraint is satisfied.
                                # item__RelatedUrls_URL   = item__RelatedUrls[0].get('URL', "")
                                # item__RelatedUrls_Type  = item__RelatedUrls[0].get('Type', "")

                                # Stringify the expected strings so we don't get mess in the DB (Santizing)
                                item__concept_id   = f'{item__concept_id}'
                                item__concept_type = f'{item__concept_type}'
                                item__GranuleUR    = f'{item__GranuleUR}'

                                # Need to pipe in existing granule attempts count
                                #new_granule_update_obj['num_of_attempts_cmr_check'] = selected_db_granule.num_of_attempts_cmr_check     # Piping in the number of checks from the existing DB Granule
                                current_granule__num_of_attempts_cmr_check = 0 # Default is 0 for new granules.  We assume this is a new granule until shown that it is not.
                                #new_granule_update_obj['num_of_attempts_cmr_check'] = selected_db_granule.num_of_attempts_cmr_check     # Piping in the number of checks from the existing DB Granule
                                #new_granule_update_obj['num_of_attempts_cmr_check'] = current_granule__num_of_attempts_cmr_check
                                #new_granule_update_obj['num_of_attempts_cmr_check'] = 0

                                # Is this a newly seen granule? (Granule that only exists in CMR and not yet in the local database?)
                                # Checking the existing keys to see if it is present.
                                #new_granule_update_obj['is__Create_New_Granule']  = False     # This is for when a granule is not already in our local database but comes back from CMR, this can happen if we run this process after ingesting new data but before processing manifests.
                                is_new_granule = True  # Default to True until proven false (until we know otherwise)
                                selected_granule_keys = granule_id_update_objects_list.keys()
                                for key in selected_granule_keys:
                                    if(key == item__GranuleUR):
                                        is_new_granule = False # Found this granule ID in the list, that means it is NOT new.. setting to False
                                        current_granule__num_of_attempts_cmr_check = granule_id_update_objects_list[key]["num_of_attempts_cmr_check"] # Bringing over the existing granule's number of attempts
                                        break;

                                if(highly_detailed_logging == True):
                                    print(f'')
                                    print(f'      DEBUG:: selected_granule_keys: {selected_granule_keys} ')
                                    print(f'      DEBUG:: is_new_granule:        {is_new_granule} ')
                                    print(f'')

                                if(highly_detailed_logging == True):
                                    # Output for the Log
                                    #print(f'      (Highly Detailed Logging): {highly_detailed_logging} ')
                                    print(f'      Current Granule from CMR, Observed Data: ')
                                    print(f'        item__concept_type:  {item__concept_type}')
                                    print(f'        item__concept_id:    {item__concept_id}')
                                    print(f'        item__GranuleUR:     {item__GranuleUR}')

                                sys.stdout.flush()

                                
                                # In this section, I'm verifying that we are looking at a granule and then checking to see if at least one download URL is present (a 'GET DATA' url type).
                                # The updates later will be one of two paths for granules from the CMR, and a third path for granules not found in CMR
                                # This bit checks for the two paths for found granules from the CMR                                
                                is_granule_found                = False     # This variable controls if we even found the granule or not (also controls which update specific DB update should happen based on finding the granule)
                                to_save__granule_concept_id     = ""
                                to_save__granule_id             = ""        # This is NOT an update, but I am using what CMR says the granule UR is to update our local DB, this lets me skip doing a whole bunch of costly checkpoints in the code after recieving the data... also, the missed granules will get updated in a later step blindly, so both lists should get handled with no problems.  
                                is_downloadable                 = False

                                # Does the CMR response object say that this part is a granule?
                                if(item__concept_type == "granule"):
                                    to_save__granule_concept_id = item__concept_id      # Value like: "G2744189394-CSDA"
                                    if(item__GranuleUR != ""):
                                        to_save__granule_id = item__GranuleUR
                                        is_granule_found = True

                                        # Now the sub check to see if the granules are downloadable
                                        # For a granule to be downloadable: # items[].umm.RelatedUrls    must exist AND must not be a blank array (have at least one URL property that is not blank AND have a 'Type': that is equal to: 'GET DATA')
                                        for related_url in item__RelatedUrls:
                                            related_url_URL   = related_url.get('URL', "")
                                            related_url_Type  = related_url.get('Type', "")

                                            if(related_url_Type == "GET DATA"):
                                                if(related_url_URL != ""):
                                                    is_downloadable = True
                                                    # Exit the loop so we don't check any more after we already found an existing one.
                                                    break;


                                # We've got all the info.. now to save the granule to the big update list.
                                # Remember, We are only looking at a singl granule from the CMR.
                                # This part of the code creates a new update object and adds it to 'granule_id_update_objects_list'
                                # # The cool part about using it's id as the key is that if the granule is in the initial update objects list, then it should get overwritten with new information found in the CMR, if it is not in the list, it gets added and processed anyway!
                                current_CMR_Granule__update_obj = {}
                                if(is_granule_found == True):
                                    # At this point, we know we have a granule that was found in the CMR and needs an update
                                    current_CMR_Granule__update_obj['is__Create_New_Granule']           = is_new_granule               # False     # This is for when a granule is not already in our local database but comes back from CMR, this can happen if we run this process after ingesting new data but before processing manifests. 
                                    current_CMR_Granule__update_obj['num_of_attempts_cmr_check']        = current_granule__num_of_attempts_cmr_check  # This was handled earlier in the code and already accounts for a new granule VS bringing in data from an existing granule.
                                    current_CMR_Granule__update_obj['batch_date_time']                  = batch_date_time
                                    current_CMR_Granule__update_obj['needs_update']                     = True
                                    current_CMR_Granule__update_obj['is__CMR_Found']                    = True
                                    current_CMR_Granule__update_obj['is__CMR_Downloadbale']             = is_downloadable
                                    current_CMR_Granule__update_obj['to_save__granule_concept_id']      = to_save__granule_concept_id

                                    # Use the Granule ID that came from the CMR (if it matches, it will overwrite the update object correctly)
                                    to_save__granule_id = f'{to_save__granule_id}'

                                    # Make sure this granule belongs in the current local database (we do not want duplicate granules scattered across different local databases.)
                                    can_add_this_granule = CMRRequestManager.check_granule_id_against_db_name_key(db_name_key=db_name_key, granule_id=to_save__granule_id)

                                    if(can_add_this_granule == True):
                                        granule_id_update_objects_list[to_save__granule_id] = current_CMR_Granule__update_obj
                                    else:
                                        print(f'    WARNING: CMR Returned a Granule ID that does not match the DB Name Key!: The DB Name Key: {db_name_key} and Granule ID: {to_save__granule_id}. Skipping the Update Object.')

                                # End of Parsing CMR Reqeust infos

                            except Exception as e:
                                #print(f'      ERROR: There was an error when parsing through the item key from an individual granule returned from the CMR API Request.  cmr_response_item: {cmr_response_item}.  Error Info: {e}')
                                error_message = f'ERROR: There was an error when parsing through the item key from an individual granule returned from the CMR API Request.  Batch Number: {i}.  cmr_response_item: {cmr_response_item}.  Error Info: {e}'
                                report__error_log.append(error_message)
                                print(f'      {error_message}')
                                report__num_of_errors = report__num_of_errors + 1
                                sys.stdout.flush()
                            


                    # ############################################################
                    # # UPDATE BLOCK #
                    # ############################################################
                    #
                    # Keeping track of the update paths - Initializing data
                    update_paths_log_obj = {}
                    update_paths_log_obj['update_path_count__Local_Granule_Found_in_CMR']       = 0
                    update_paths_log_obj['update_path_count__Local_Granule_NOT_Found_in_CMR']   = 0
                    update_paths_log_obj['update_path_count__NEW_Granule_Found_in_CMR']         = 0


                    # Get the keys
                    granule_update_object_keys = granule_id_update_objects_list.keys()
                    len__granule_update_object_keys = len(granule_update_object_keys)

                    #current_batch_number
                    # Doing an Output to the console that this batch made it to the update phase
                    print(f'')
                    print(f'    Batch: {current_batch_number} of {cmr_checking__num_of_batches_to_run}: About to process updates on {len__granule_update_object_keys} objects')

                    if(has_api_error == True):
                        print(f'      There was an API Error when attempting to get this batch from the CMR.  No Updates to be done, so we can automatically retry this batch later.')
                    else:
                        # Actually iterate and do the updates
                        for granule_update_object_key in granule_update_object_keys:
                            
                            #print(f'')
                            if(highly_detailed_logging == True):
                                print(f'  About to process granule_update_object_key: {granule_update_object_key}')

                            # Getting the current object from the granule ID (used as the key)
                            current_update_obj = granule_id_update_objects_list[granule_update_object_key]

                            # First off, does this object actually need an update:
                            needs_update = current_update_obj["needs_update"]

                            # Only proceed if this object DOES need an update
                            if(needs_update == True):
                                
                                # Which Update path is this one on?
                                is__CMR_Found = current_update_obj["is__CMR_Found"]
                                if(is__CMR_Found == True):
                                    
                                    # Is this a new Granule, or confirming an existing Granule?
                                    is__Create_New_Granule = current_update_obj['is__Create_New_Granule']
                                    if(is__Create_New_Granule == True):
                                        # Update Path Confirmed:  This is a NEW Granule that was seen in the CMR but not known in the current local DB.
                                        # update_path_count__NEW_Granule_Found_in_CMR
                                        #
                                        # Get Data Needed to do this update.
                                        is__CMR_Downloadbale            = current_update_obj['is__CMR_Downloadbale']
                                        to_save__granule_concept_id     = current_update_obj['to_save__granule_concept_id']
                                        #
                                        # Do the Update
                                        rows_affected = DatabaseManager.create__new_granule__from_found_in_CMR(db_name_key=db_name_key, granule_id=granule_update_object_key, cmr_concept_id=to_save__granule_concept_id, is__cmr_downloadable=is__CMR_Downloadbale)
                                        #
                                        # Increment the Update Counter
                                        update_paths_log_obj['update_path_count__NEW_Granule_Found_in_CMR']   = update_paths_log_obj['update_path_count__NEW_Granule_Found_in_CMR'] + rows_affected

                                    else:
                                        # Update Path Confirmed:  This existing Granule was found in the CMR Response, store the new info!
                                        # update_path_count__Local_Granule_Found_in_CMR
                                        #
                                        # Get Data Needed to do this update.
                                        is__CMR_Downloadbale            = current_update_obj['is__CMR_Downloadbale']
                                        to_save__granule_concept_id     = current_update_obj['to_save__granule_concept_id']
                                        #
                                        # Do the Update
                                        rows_affected = DatabaseManager.update__granule__was_found_in_CMR(db_name_key=db_name_key, granule_id=granule_update_object_key, cmr_concept_id=to_save__granule_concept_id, is__cmr_downloadable=is__CMR_Downloadbale)
                                        #
                                        # Increment the Update Counter
                                        update_paths_log_obj['update_path_count__Local_Granule_Found_in_CMR']   = update_paths_log_obj['update_path_count__Local_Granule_Found_in_CMR'] + rows_affected

                                else:
                                    # Update Path Confirmed:  This Granule was NOT found in the CMR Response, increment the attempt
                                    # update_path_count__Local_Granule_NOT_Found_in_CMR
                                    #
                                    # Get Data Needed to do this update.
                                    num_of_attempts_cmr_check           = current_update_obj['num_of_attempts_cmr_check']
                                    new__num_of_attempts_cmr_check      = num_of_attempts_cmr_check + 1 # Just incrementing the value
                                    #
                                    # Do the Update
                                    rows_affected = DatabaseManager.update__existing_granule__was_NOT_found_in_CMR(db_name_key=db_name_key, granule_id=granule_update_object_key, num_of_attempts_cmr_check=new__num_of_attempts_cmr_check)

                                    # Increment the Update Counter
                                    update_paths_log_obj['update_path_count__Local_Granule_NOT_Found_in_CMR']   = update_paths_log_obj['update_path_count__Local_Granule_NOT_Found_in_CMR'] + rows_affected

                    # Now let's print out the update report

                    # Outputting stuff so I can verify what happened in the DB
                    update_path_count__Local_Granule_Found_in_CMR       = update_paths_log_obj['update_path_count__Local_Granule_Found_in_CMR']
                    update_path_count__Local_Granule_NOT_Found_in_CMR   = update_paths_log_obj['update_path_count__Local_Granule_NOT_Found_in_CMR']
                    update_path_count__NEW_Granule_Found_in_CMR         = update_paths_log_obj['update_path_count__NEW_Granule_Found_in_CMR'] 

                    # Incrementing the total report counters
                    report__num_of_updates_made__localDB_granules_found_in_cmr      = report__num_of_updates_made__localDB_granules_found_in_cmr     + update_path_count__Local_Granule_Found_in_CMR
                    report__num_of_updates_made__localDB_granules_not_found_in_cmr  = report__num_of_updates_made__localDB_granules_not_found_in_cmr + update_path_count__Local_Granule_NOT_Found_in_CMR
                    report__num_of_updates_made__new_granules_found_in_cmr          = report__num_of_updates_made__new_granules_found_in_cmr         + update_path_count__NEW_Granule_Found_in_CMR

                    # Outputting stuff so I can verify what happened in the DB
                    if(highly_detailed_logging == True):
                        print(f'')
                        print(f'    REPORT for Batch: {current_batch_number} of {cmr_checking__num_of_batches_to_run}')
                        print(f'')
                        print(f'      db_name_key:                             {db_name_key}')
                        print(f'      has_api_error:                           {has_api_error}')
                        print(f'      granule_id_update_objects_list:          {granule_id_update_objects_list}')
                        #
                        print(f'')
                        print(f'      update_path_count__Local_Granule_Found_in_CMR:     {update_path_count__Local_Granule_Found_in_CMR}')
                        print(f'      update_path_count__Local_Granule_NOT_Found_in_CMR: {update_path_count__Local_Granule_NOT_Found_in_CMR}')
                        print(f'      update_path_count__NEW_Granule_Found_in_CMR:       {update_path_count__NEW_Granule_Found_in_CMR}')
                        print(f'')
                    else:
                        print(f'')
                        print(f'    REPORT for Batch: {current_batch_number} of {cmr_checking__num_of_batches_to_run}, Local DB: {db_name_key}, API Errors? {has_api_error}')
                        print(f'      THIS_BATCH:     Local Granules Found in CMR: {update_path_count__Local_Granule_Found_in_CMR} , Local Granules NOT Found in CMR: {update_path_count__Local_Granule_NOT_Found_in_CMR} , New Granules Found in CMR: {update_path_count__NEW_Granule_Found_in_CMR}')
                        print(f'      RUNNING_TOTALS: Local Granules Found in CMR: {report__num_of_updates_made__localDB_granules_found_in_cmr} , Local Granules NOT Found in CMR: {report__num_of_updates_made__localDB_granules_not_found_in_cmr} , New Granules Found in CMR: {report__num_of_updates_made__new_granules_found_in_cmr}')
                        print(f'')

                    # Force Terminal Output (helps with monitoring progress) # Forces all buffered print statements above to output right now
                    sys.stdout.flush()  

                    
                    #print(f'  DEBUG -- cmr_response_JSON: {cmr_response_JSON}')
                    #print(f'  DEBUG -- -- hits: {hits}')
                    #print(f'  DEBUG -- -- items: {items}')

                    #print(f'    NEXT UP.. READ SPECIFIC PROP FROM THIS JSON! -- convert to a python object and then do the whole, if exists key -- so it does not break when one is NOT found.')




                    
                    # THIS IS WHERE THE UPDATE OBJECT SHOULD GO... IF ANYTHING WITH THIS BATCH FAILS, THIS CODE WILL GET BYPASSED..
                    # THIS IS WHERE THE UPDATE OBJECT SHOULD GO... IF ANYTHING WITH THIS BATCH FAILS, THIS CODE WILL GET BYPASSED..
                    # THIS IS WHERE THE UPDATE OBJECT SHOULD GO... IF ANYTHING WITH THIS BATCH FAILS, THIS CODE WILL GET BYPASSED..
                    # THIS IS WHERE THE UPDATE OBJECT SHOULD GO... IF ANYTHING WITH THIS BATCH FAILS, THIS CODE WILL GET BYPASSED..
                    # THIS IS WHERE THE UPDATE OBJECT SHOULD GO... IF ANYTHING WITH THIS BATCH FAILS, THIS CODE WILL GET BYPASSED..
                

                





                except Exception as e:
                    #print(f'    ERROR: There was an unexpected Error making the CMR API Request.  Is the CMR Down?  Error Info: {e}')
                    error_message = f'ERROR: There was an unexpected Error making the CMR API Request.  Is the CMR Down?  Batch Number: {i}  Error Info: {e}'
                    report__error_log.append(error_message)
                    print(f'    {error_message}')
                    report__num_of_errors = report__num_of_errors + 1
                    sys.stdout.flush()


            # END OF:   if(current_num_of_granules_selected > 0):

            # Force Terminal Output (helps with monitoring progress) # Forces all buffered print statements above to output right now
            sys.stdout.flush()


            
            #Placeholder
            #--Filtering and cleaning out this version of the code - and also completing the SQLITE CODE FOR THE UPDATER TO USE (further down)



            

            # End of the loop, if needed, wait before starting on the next batch.
            num_of_seconds_to_sleep = get_sleep_seconds_to_wait(min_time_needed_to_wait=cmr_checking__min_delay_seconds_between_api_requests, time__start=time__loop__start)
            if(num_of_seconds_to_sleep > 0.0):
                print(f'    Batch: {current_batch_number} of {cmr_checking__num_of_batches_to_run}: ...Waiting {num_of_seconds_to_sleep} seconds before next API Request')
                time.sleep(num_of_seconds_to_sleep)
            print(f'')

            
            # Increment the counter that tracks when a batch is completed
            report__num_of_batches_completed = report__num_of_batches_completed + 1

            print(f'  ------------------------------------------------------------------------')
            print(f'')
            # Force Terminal Output (helps with monitoring progress) # Forces all buffered print statements above to output right now
            sys.stdout.flush()


        except Exception as e:
            #print(f'    ERROR: There was an unexpected Error at the Batch Level.  Is there a problem selecting granules from the Local DB?  Batch Number: {i}  Error Info: {e}')
            error_message = f'ERROR: There was an unexpected Error at the Batch Level.  Is there a problem selecting granules from the Local DB?  Batch Number: {i}  Error Info: {e}'
            report__error_log.append(error_message)
            print(f'    {error_message}')
            report__num_of_errors = report__num_of_errors + 1
            sys.stdout.flush()


    # Now get the counts AFTER  all is done.
    total_remaining_count__AFTER = DatabaseManager.get_remaining_granule_count__for_cmr_API_call(db_name_key=db_name_key, max_retries=cmr_checking__max_retries)

    # REFERENCE
    # report__num_of_batches_attempted = 0
    # report__num_of_batches_completed = 0
    # report__num_of_updates_made__localDB_granules_not_found_in_cmr  = 0
    # report__num_of_updates_made__localDB_granules_found_in_cmr      = 0
    # report__num_of_updates_made__new_granules_found_in_cmr          = 0
    # report__num_of_errors                                           = 0
    # report__error_log = []

    # Old Version
    # print(f'Expecting How many granules were processed')
    # print(f'Expecting How many granules were updated (found and updated, removed from the -remaining granule- list)')
    # print(f'Expecting How many granules were NOT FOUND')
    # print(f'Expecting How many granules were FAILED')

    # Final Run Report
    print(f'')
    print(f'CMR Validation and Updating Report:')
    print(f'total_remaining_count__BEFORE:    {total_remaining_count__BEFORE}')
    print(f'')
    print(f'Number of Batches Attempted:    {report__num_of_batches_attempted}')
    print(f'Number of Batches Completed:    {report__num_of_batches_completed}')
    print(f'')
    print(f'Number of Locally Tracked Granules Found in CMR (Already Ingested):          {report__num_of_updates_made__localDB_granules_found_in_cmr}')
    print(f'Number of Locally Tracked Granules NOT found in CMR (Needs to be ingested):  {report__num_of_updates_made__localDB_granules_not_found_in_cmr}')
    print(f'Number of New Granules Found in CMR (Needs Manifest Verifications):          {report__num_of_updates_made__new_granules_found_in_cmr}')
    print(f'')
    print(f'Number of Errors in the whole process:    {report__num_of_errors}')
    print(f'  Error Log:')
    sys.stdout.flush()
    error_line_counter = 0
    for error_line in report__error_log:
        print(f'    {error_line_counter}: {error_line}')
        error_line_counter = error_line_counter + 1
    
    print(f'')
    print(f'total_remaining_count__AFTER:     {total_remaining_count__AFTER}')
    print(f'')


    # Put this at the begining of any of these processes
    # # Total Time Tracking - Start Time
    # time__total__start = time.time()
    #
    # Total Time Tracking - End Time
    time__total__end = time.time()
    #
    # Raw Seconds
    time__total__elapsed = time__total__end - time__total__start  
    #
    # Converting raw seconds into Days, Hours, Minutes, and Seconds
    time_delta = timedelta(seconds=time__total__elapsed)
    # Format the time_delta cleanly into a human-readable single line
    days = time_delta.days
    hours, remainder = divmod(time_delta.seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    #
    print(f'')
    print(f'  Total Elapsed Time for this run: {time__total__elapsed:.2f} total Seconds ')
    print(f'    Human Readable Total Duration: {days} Days, {hours} Hours, {minutes} Minutes, {seconds} Seconds')
    print(f'')

    print(f'')
    print(f'run_integrated_test_02__Full_CMR_Request_And_Processing:      REACHED THE END')
    print(f'')























# Example that is close to the Main Interface version -- Think -- Integration Test
# # The name of this function is actually a much smaller scope then what it ended up being!
def run_integrated_test_01__Validate_And_Update_Multiple_Granules():
    # Write the code here like it would exist in the main interface parts.
    print(f'')
    print(f'run_integrated_test_01__Validate_And_Update_Multiple_Granules:      STARTED')
    print(f'')

    # BEFORE even calling this function, we will need these variables
    # Get the Current Database (This is hardcoded for this test, but it needs to be dynamic on the real/live version)
    print(f'run_integrated_test_01__Validate_And_Update_Multiple_Granules: WARN: HardCoding DB Name Key To WV01 and Concept ID for this test.  The real, live version needs to be dynamic or passed in as an external parameter. ')
    db_name_key                 = "WV01"
    collection_concept_id__LIST = CMRRequestManager.get_collection_concept_id_list()
    # collection_concept_id__LIST = ['C2497387766-CSDA', 'C2520285535-CSDA']
    #collection_concept_id   = "C2497387766-CSDA",  # // This is WV01_Pan_L1B
    # Might be able to make multiple concept ids in one request..
    

    # # BEFORE the looped section 
    # Do a count to see how many granules fit the criteria


    # # Working on this now --

    # Settings
    cmr_checking__num_of_batches_to_run                     = 2   # How many times the outer loop will run.
    cmr_checking__min_delay_seconds_between_api_requests    = 2.5   # How long we should delay between api reqeusts to the CMR.
    cmr_checking__max_retries                               = 3
    cmr_checking__max_num_of_granules_to_select_per_batch   = 4 #500  # Testing this with 4 at a time, 500 is what we will run in production.
    
    

    # Get the Count of how many Total Granules there are remaining
    total_remaining_count__BEFORE = DatabaseManager.get_remaining_granule_count__for_cmr_API_call(db_name_key=db_name_key, max_retries=cmr_checking__max_retries)

    # Moved this to inside the loop
    # Select Multiple Granules from the local SQLite DB
    #granule_rows_list              = DatabaseManager.get_granules_for_cmr_API_call(db_name_key="WV01", max_num_of_granules=50) # max_retries=3 (max_retries is an Optional Param defaulted at 3)
    #granule_rows_list               = DatabaseManager.get_granules_for_cmr_API_call(db_name_key=db_name_key, max_num_of_granules=cmr_checking__max_num_of_granules_to_select_per_batch, max_retries=cmr_checking__max_retries)


    print(f'')
    print(f'  About to enter the Batch Granule Processing Loop: Params:')
    print(f'    Settings:')
    print(f'      cmr_checking__num_of_batches_to_run:                     {cmr_checking__num_of_batches_to_run}')
    print(f'      cmr_checking__min_delay_seconds_between_api_requests:    {cmr_checking__min_delay_seconds_between_api_requests}')
    print(f'      cmr_checking__max_retries:                               {cmr_checking__max_retries}')
    print(f'      cmr_checking__max_num_of_granules_to_select_per_batch:   {cmr_checking__max_num_of_granules_to_select_per_batch}')
    print(f'    Params:')
    print(f'      db_name_key:                 {db_name_key}')
    print(f'      collection_concept_id__LIST: {collection_concept_id__LIST}')
    print(f'')

    
    #
    # WRITE THE LOOP THAT SELECTS AND CALLS EACH BATCHES
    # Each run through this loop is for a single batch.
    for i in range(cmr_checking__num_of_batches_to_run):
        try:
            current_batch_number = i + 1
            print(f'  ------------------------------------------------------------------------')
            print(f'    Batch: {current_batch_number} of {cmr_checking__num_of_batches_to_run}: Starting to process a new Batch of {cmr_checking__max_num_of_granules_to_select_per_batch} Granules')
            pass
            #
            # THIS PART IS INSIDE THE LOOP
            time__loop__start = time.time()

            
            # Get the remaining number of granules during this run, Select a batch of granules.
            current_granule_rows_remaining_count    = DatabaseManager.get_remaining_granule_count__for_cmr_API_call(db_name_key=db_name_key, max_retries=cmr_checking__max_retries)
            current_granule_rows_list               = DatabaseManager.get_granules_for_cmr_API_call(db_name_key=db_name_key, max_num_of_granules=cmr_checking__max_num_of_granules_to_select_per_batch, max_retries=cmr_checking__max_retries) # max_retries=3 (max_retries is an Optional Param defaulted at 3)

            # Print how many total granules are left, and how many were selected.
            current_num_of_granules_selected = 0
            if(current_granule_rows_list == None):
                print(f'    No granules selected this iteration... Maybe there are no remaining granules in our local database?')
                current_num_of_granules_selected = 0
            else:
                current_num_of_granules_selected = len(current_granule_rows_list)
                print(f'    Selected {current_num_of_granules_selected} out of {current_granule_rows_remaining_count} remaining Granules')

            # Making an object that can be used to update the database.
            granule_id_update_objects_list = {}#[]
            #
            # Iterate to load up this update list with an initial keys and information.
            for selected_db_granule in current_granule_rows_list:
                new_granule_update_obj = {}
                #new_granule_update_obj['needs_update']             = False     # This value gets changed at the end
                new_granule_update_obj['needs_update']             = True      # Setting this to True now because if the rest is untouched, that means we have to log an attempt.
                new_granule_update_obj['is__CMR_Found']            = False     # If it's in this list, it should start as False until shown otherwise..
                new_granule_update_obj['is__CMR_Downloadbale']     = False     # If it's in this list, it should start as False until shown otherwise..

                # This is the magical part -- using the granule's id as the key lets me reduce the look up from iterating a list to a direct string array call.
                # This means, without knowing the order or teh number of elements, I can add objects to this array. So that means if a granule was seen in the CMR but not in this batch list, it can still get updated, or if a granule was not seen in the CMR but I want to update the number of attempts for granules not found.
                object_key_name__granule_id = f'{selected_db_granule.granule_id}'
                can_add_this_granule = CMRRequestManager.check_granule_id_against_db_name_key(db_name_key=db_name_key, granule_id=object_key_name__granule_id)
                if(can_add_this_granule == True):
                    granule_id_update_objects_list[object_key_name__granule_id] = new_granule_update_obj
                else:
                    print(f'    WARNING: The DB Name Key: {db_name_key} and Granule ID: {object_key_name__granule_id}. Did not match')
            #
            # DEBUG
            # print(f'  #############################################')
            # print(f'  DEBUG: {granule_id_update_objects_list}')
            # print(f'  #############################################')
            # # DEBUG OUTPUT:
            # DEBUG: {'WV01_20171119060820_10200100697CF800_17NOV19060820-P1BS-501718201020_01_P005': {'needs_update': False, 'is__CMR_Found': False, 'is__CMR_Downloadbale': False}, 'WV01_20171119060842_1020010069302900_17NOV19060842-P1BS-501699589090_02_P001': {'needs_update': False, 'is__CMR_Found': False, 'is__CMR_Downloadbale': False}, 'WV01_20171119060843_1020010069302900_17NOV19060843-P1BS-501699589090_02_P002': {'needs_update': False, 'is__CMR_Found': False, 'is__CMR_Downloadbale': False}, 'WV01_20171119060844_1020010069302900_17NOV19060844-P1BS-501699589090_02_P003': {'needs_update': False, 'is__CMR_Found': False, 'is__CMR_Downloadbale': False}}

            # for granule in granule_rows_list:
            #     granule_id_list.append(f'{granule.granule_id}')
            
            # # Make a list of JUST the IDs (Makes it easier to iterate and search)
            # granule_id_list = []
            #     for granule in granule_rows_list:
            #         granule_id_list.append(f'{granule.granule_id}')

            # Force Terminal Output (helps with monitoring progress) # Forces all buffered print statements above to output right now
            sys.stdout.flush()

            # Only run this part of the loop if we actually selected at least 1 granule.
            if(current_num_of_granules_selected > 0):
                
                try:
                    print(f'    Making an API Request to the CMR for {current_num_of_granules_selected} selected granules and all of our known collection concept ids...')

                    # Run the CMR API Reqeust
                    cmr_response_JSON = CMRRequestManager.send_CMR_API_Post_Request_For_Granule_Batch(granule_rows_list=current_granule_rows_list, collection_concept_id_list=collection_concept_id__LIST)
                    #CMRRequestManager.run_HC_Test_03__Multiple_Post()      # Post Request for multiple Granules
                    #cmr_response_JSON = CMRRequestManager.send_CMR_API_Post_Request_For_Granule_Batch(granule_rows_list=current_granule_rows_list, collection_concept_id=collection_concept_id)
                    
                    # Getting some of the props and parsing them out
                    hits = cmr_response_JSON.get('hits', 0)
                    items = cmr_response_JSON.get('items', [])

                    print(f'    CMR API Request got {hits} hits out of {current_num_of_granules_selected} Granules from our DB selection.')
                    #print(f'      DEBUG: items (ARRAY): {items}')  # This returns lots of content:  OUTPUT: DEBUG: items (ARRAY): [{'meta': {'concept-type': 'granule', 'concept-id': 'G2744188461-CSDA', 'revision-id': 2, .....

                    if(hits == 0):
                        print(f'    No Granule Search Hits to process from CMR for this batch.  Batch: {current_batch_number} of {cmr_checking__num_of_batches_to_run}')
                    else:
                        # Iterate through each granule
                        print(f'    Iterating through and reading each Granule result hit from the CMR...')

                        for cmr_response_item in items:
                            #print(f'      DEBUG: cmr_response_item (Single_Item_In_array): {cmr_response_item}')  # This works as well:  OUTPUT: DEBUG: cmr_response_item (Single_Item_In_array): {'meta': {'concept-type': 'granule', 'concept-id': 'G2744189112-CSDA', 'revision-id': 2, .....
                            try:
                                # # Guide for processing this JSON
                                #
                                # "items[].meta",                   // Item Top Level object, holds top level info
                                # "items[].meta.concept-type",      // Verify this is granule.  Value should be: "granule"
                                # "items[].meta.concept-id",        // The Granule's Concept ID, starts with letter "G" Example: "G2744189394-CSDA"
                                #
                                # "items[].umm",                    // Item Top Level object, holds most of the Granule Metadata 
                                # "items[].umm.GranuleUR",          // Holds the Granule ID (as we know it).  Example: "WV01_20171119060932_102001006BB20B00_17NOV19060932-P1BS-501699587090_03_P033"
                                # "items[].umm.RelatedUrls,"        // Holds a list of Download URLs // To verify if this granule is downloadlable: items[0].umm.RelatedUrls    must exist AND must not be a blank array (have at least one URL property that is not blank AND have a 'Type': that is equal to: 'GET DATA')
                                #
                                # # Extra Stuff
                                # If we want to go deeper, we can analyze the files
                                # This tells us if there is actual file size content
                                # "items[].umm.DataGranule.ArchiveAndDistributionInformation[].SizeInBytes",
                                # # In these keys, we can also get the list of files as well.

                                # Gather all required info.  If any of this fails, we do not have a granule to update (maybe something on the CMR side did not process this granule correctly?)
                                item__meta              = cmr_response_item.get('meta', {})
                                item__concept_type      = item__meta.get('concept-type', "")
                                item__concept_id        = item__meta.get('concept-id', "")
                                #
                                item__umm               = cmr_response_item.get('umm', {})
                                item__GranuleUR         = item__umm.get('GranuleUR', "")
                                #
                                item__RelatedUrls       = item__umm.get('RelatedUrls', [])
                                #
                                # # Get these down inside of the loop. -- Iterate all URLs to check this stuff, stop when constraint is satisfied.
                                # item__RelatedUrls_URL   = item__RelatedUrls[0].get('URL', "")
                                # item__RelatedUrls_Type  = item__RelatedUrls[0].get('Type', "")

                                

                                print(f'      DEBUG: Iterating through and reading each Granule result hit from the CMR...')
                                print(f'      DEBUG: item__concept_type:  {item__concept_type}')
                                print(f'      DEBUG: item__concept_id:    {item__concept_id}')
                                print(f'      DEBUG: item__GranuleUR:     {item__GranuleUR}')

                                # print(f'      DEBUG: item__RelatedUrls:      {item__RelatedUrls}')
                                # print(f'      DEBUG: item__RelatedUrls_URL:  {item__RelatedUrls_URL}')
                                # print(f'      DEBUG: item__RelatedUrls_Type: {item__RelatedUrls_Type}')

                                is_granule_found                = False     # This variable controls if we even found the granule or not (also controls which update specific DB update should happen based on finding the granule)
                                to_save__granule_concept_id     = ""
                                to_save__granule_id             = ""        # This is NOT an update, but I am using what CMR says the granule UR is to update our local DB, this lets me skip doing a whole bunch of costly checkpoints in the code after recieving the data... also, the missed granules will get updated in a later step blindly, so both lists should get handled with no problems.  
                                is_downloadable                 = False

                                if(item__concept_type == "granule"):
                                    to_save__granule_concept_id = item__concept_id      # Value like: "G2744189394-CSDA"
                                    if(item__GranuleUR != ""):
                                        to_save__granule_id = item__GranuleUR
                                        is_granule_found = True

                                        # Now the sub check to see if the granules are downloadable
                                        for related_url in item__RelatedUrls:
                                            related_url_URL   = related_url.get('URL', "")
                                            related_url_Type  = related_url.get('Type', "")

                                            #print(f'        DEBUG: related_url_URL:  {related_url_URL}')
                                            #print(f'        DEBUG: related_url_Type: {related_url_Type}')

                                            if(related_url_Type == "GET DATA"):
                                                if(related_url_URL != ""):
                                                    is_downloadable = True
                                                    # Exit the loop
                                                    break;

                                # We've got all the info.. now to save the granule to the big update list.
                                #
                                # SEE THIS LINE IN THE ABOVE CODE FOR REFERENCE:  
                                #for selected_db_granule in current_granule_rows_list:
                                print(f'  DEBUG: #for selected_db_granule in current_granule_rows_list:')

                                # Remember, We are only looking at a singl granule from the CMR.
                                current_CMR_Granule__update_obj = {}
                                if(is_granule_found == True):
                                    # At this point, we know we have a granule that was found in the CMR and needs an update
                                    current_CMR_Granule__update_obj['needs_update']                     = True
                                    current_CMR_Granule__update_obj['is__CMR_Found']                    = True
                                    current_CMR_Granule__update_obj['is__CMR_Downloadbale']             = is_downloadable
                                    current_CMR_Granule__update_obj['to_save__granule_concept_id']      = to_save__granule_concept_id

                                    # Use the Granule ID that came from the CMR (if it matches, it will overwrite the update object correctly)
                                    to_save__granule_id = f'{to_save__granule_id}'

                                    # Make sure this granule belongs in the current local database (we do not want duplicate granules scattered across different local databases.)
                                    can_add_this_granule = CMRRequestManager.check_granule_id_against_db_name_key(db_name_key=db_name_key, granule_id=to_save__granule_id)

                                    if(can_add_this_granule == True):
                                        granule_id_update_objects_list[to_save__granule_id] = current_CMR_Granule__update_obj
                                    else:
                                        print(f'    WARNING: CMR Returned a Granule ID that does not match the DB Name Key!: The DB Name Key: {db_name_key} and Granule ID: {to_save__granule_id}. Skipping the Update Object.')

                                # # Example Below showing how the default state looks of all granules from selected DB batch
                                # for selected_db_granule in current_granule_rows_list:
                                #     new_granule_update_obj = {}
                                #     new_granule_update_obj['needs_update']             = False     # This value gets changed at the end
                                #     new_granule_update_obj['is__CMR_Found']            = False     # If it's in this list, it should start as False until shown otherwise..
                                #     new_granule_update_obj['is__CMR_Downloadbale']     = False     # If it's in this list, it should start as False until shown otherwise..

                                #     # This is the magical part -- using the granule's id as the key lets me reduce the look up from iterating a list to a direct string array call.
                                #     # This means, without knowing the order or teh number of elements, I can add objects to this array. So that means if a granule was seen in the CMR but not in this batch list, it can still get updated, or if a granule was not seen in the CMR but I want to update the number of attempts for granules not found.
                                #     object_key_name__granule_id = f'{selected_db_granule.granule_id}'
                                #     can_add_this_granule = CMRRequestManager.check_granule_id_against_db_name_key(db_name_key=db_name_key, granule_id=object_key_name__granule_id)
                                #     if(can_add_this_granule == True):
                                #         granule_id_update_objects_list[object_key_name__granule_id] = new_granule_update_obj
                                #     else:
                                #         print(f'    WARNING: The DB Name Key: {db_name_key} and Granule ID: {object_key_name__granule_id}. Did not match')

                                #print(f'      DEBUG: is_downloadable:     {is_downloadable}')


                            except Exception as e:
                                print(f'      ERROR: There was an error when parsing through the item key from an individual granule returned from the CMR API Request.  cmr_response_item: {cmr_response_item}.  Error Info: {e}')
                                pass
                            

                    #print(f'  DEBUG -- cmr_response_JSON: {cmr_response_JSON}')
                    #print(f'  DEBUG -- -- hits: {hits}')
                    #print(f'  DEBUG -- -- items: {items}')

                    #print(f'    NEXT UP.. READ SPECIFIC PROP FROM THIS JSON! -- convert to a python object and then do the whole, if exists key -- so it does not break when one is NOT found.')
                
                except Exception as e:
                    print(f'    ERROR: There was an unexpected Error making the CMR API Request.  Is the CMR Down?  Error Info: {e}')

            #
            #------- AND FINISH LOOKING UP CONCEPT IDS AND WIRING THEM UP HERE

            

            # TESTING
            # for granule in current_granule_rows_list:
            #     print(f'granule.granule_id: {granule.granule_id}')

            # REMAINING STUFF FOR THIS FUNCTION
            #
            # - Select the next batch of granules
            # - Run the CMR Query
            # - - For Each Granule found in the CMR API Results
            # - - - Parse the CMR Results to see if this granule is in the CMR (get the concept id), and see if it is downloadable, verify that granule IS in the batch list
            # - - - Update the Granules in the local DB (Either confirming the status and storing the concept ID, or incrementing the retries)
            # - - - - This above thing will require at least 2 new SQL statements and lots of tests.
            # - - - Record the status for the report for each granule (Either the granule was confirmed OR was not confirmed and needs to be later retried.)

            # Force Terminal Output (helps with monitoring progress) # Forces all buffered print statements above to output right now
            sys.stdout.flush()

            # Finally, run the updates on this batch of granules (Note, IF CMR Returned granules that fit in this Database that we do not know about, we may have extra granules being added...)
            #granule_id_update_objects_list  # This is actually an object, with a bunch of keys!
            #for granule_to_update in granule_id_update_objects_list
            try:
                granule_ids_key_list = list(granule_id_update_objects_list.keys())
                print(f'- We are now at the part to update all the granules....')
                print(f'    granule_ids_key_list:             {granule_ids_key_list}')
                print(f'    granule_id_update_objects_list:   {granule_id_update_objects_list}')
                print(f'    DEBUG: Listing ALL info in each of these objects')
                for granule_id_key in granule_ids_key_list:
                    current_update_obj = granule_id_update_objects_list[granule_id_key]

                    # REFERENCE
                    #
                    # new_granule_update_obj['needs_update']             = True      # Setting this to True now because if the rest is untouched, that means we have to log an attempt.
                    # new_granule_update_obj['is__CMR_Found']            = False     # If it's in this list, it should start as False until shown otherwise..
                    # new_granule_update_obj['is__CMR_Downloadbale']     = False     # If it's in this list, it should start as False until shown otherwise..
                    #
                    # current_CMR_Granule__update_obj['needs_update']                     = True
                    # current_CMR_Granule__update_obj['is__CMR_Found']                    = True
                    # current_CMR_Granule__update_obj['is__CMR_Downloadbale']             = is_downloadable
                    # current_CMR_Granule__update_obj['to_save__granule_concept_id']      = to_save__granule_concept_id
                    #

                    needs_update                    = current_update_obj.get('needs_update',                False)
                    is__CMR_Found                   = current_update_obj.get('is__CMR_Found',               False)
                    is__CMR_Downloadbale            = current_update_obj.get('is__CMR_Downloadbale',        False)
                    to_save__granule_concept_id     = current_update_obj.get('to_save__granule_concept_id', "")
                    print(f'      DEBUG: granule_id_key:                  {granule_id_key}')
                    print(f'        DEBUG: needs_update:                    {needs_update}')
                    print(f'        DEBUG: is__CMR_Found:                   {is__CMR_Found}')
                    print(f'        DEBUG: is__CMR_Downloadbale:            {is__CMR_Downloadbale}')
                    print(f'        DEBUG: to_save__granule_concept_id:     {to_save__granule_concept_id}')
                    
            except Exception as e:
                print(f'    ERROR: There was an unexpected Error when attempting to update granules from this batch.  Is there a problem with connecting to the local DB?  Batch Number: {i}  Error Info: {e}')

            # Simulating variable work
            #time.sleep(3.1)  

            # End of the loop, if needed, wait before starting on the next batch.
            num_of_seconds_to_sleep = get_sleep_seconds_to_wait(min_time_needed_to_wait=cmr_checking__min_delay_seconds_between_api_requests, time__start=time__loop__start)
            if(num_of_seconds_to_sleep > 0.0):
                print(f'    Batch: {current_batch_number} of {cmr_checking__num_of_batches_to_run}: ...Waiting {num_of_seconds_to_sleep} seconds before next API Request')
                time.sleep(num_of_seconds_to_sleep)
            print(f'')

            # Force Terminal Output (helps with monitoring progress) # Forces all buffered print statements above to output right now
            sys.stdout.flush()
            
            #print(f'  ------------------------------------------------------------------------')
        except Exception as e:
            print(f'    ERROR: There was an unexpected Error at the Batch Level.  Is there a problem selecting granules from the Local DB?  Batch Number: {i}  Error Info: {e}')

    total_remaining_count__AFTER = DatabaseManager.get_remaining_granule_count__for_cmr_API_call(db_name_key=db_name_key, max_retries=cmr_checking__max_retries)

    print(f'')
    print(f'CMR Validation and Updating Report:')
    print(f'total_remaining_count__BEFORE:    {total_remaining_count__BEFORE}')
    print(f'')
    print(f'Expecting How many granules were processed')
    print(f'Expecting How many granules were updated (found and updated, removed from the -remaining granule- list)')
    print(f'Expecting How many granules were NOT FOUND')
    print(f'Expecting How many granules were FAILED')
    print(f'')
    print(f'total_remaining_count__AFTER:     {total_remaining_count__AFTER}')
    print(f'')
    

    print(f'')
    print(f'run_integrated_test_01__Validate_And_Update_Multiple_Granules:      REACHED THE END')
    print(f'')
    pass








def main_test():
    pass
    # # Can we make an API Call to CMR for a Single or Multiple Granules? - YES
    #CMRRequestManager.run_HC_Test_01()                 # Learned a lot -- abandonded for the next version
    #CMRRequestManager.run_HC_Test_02__Simpler_Get()    # CMR API Request for Single Granule -- Works
    #CMRRequestManager.run_HC_Test_03__Multiple_Post()      # Post Request for multiple Granules
    #
    #
    #
    # # Can we query the database for the next list of granules to process? - 
    # Note: Before Calling this function, we should already know which Collection and Which Database Name Key
    # The Collection name will be used to look up the concept ID in the CMR Request Manager, the Database Name Key tells us which SQLite Table to look in for the correct granules list.
    granule_rows_remaining_count    = DatabaseManager.get_remaining_granule_count__for_cmr_API_call(db_name_key="WV01", max_retries=3)
    granule_rows_list               = DatabaseManager.get_granules_for_cmr_API_call(db_name_key="WV01", max_num_of_granules=50) # max_retries=3 (max_retries is an Optional Param defaulted at 3)
    #
    # Output the granule rows list
    print(f'granule_rows_remaining_count: {granule_rows_remaining_count}')
    if granule_rows_list is None:
        print("No granule_rows_list found.")
    else:
        # You can safely READ the data outside the session
        for granule_row in granule_rows_list:
            print(f"Found ID: {granule_row.id}: granule_id: {granule_row.granule_id}")



# Entry Point
#main_test()
#run_integrated_test_01__Validate_And_Update_Multiple_Granules()
run_integrated_test_02__Full_CMR_Request_And_Processing()
#run_SQL_Update_Function_Test_03()

# END OF FILE