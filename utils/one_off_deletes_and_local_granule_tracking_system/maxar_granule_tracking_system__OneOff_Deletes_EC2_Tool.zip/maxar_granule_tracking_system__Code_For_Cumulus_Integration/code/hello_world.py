# hello_world.py

import os
import sys

# Allows running from one directory up.
sys.path.append(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))

from lib.utils import utils

print('hello world 2')

utils.utils_output_test()

# Testing and dev for accessing DynamoDB Records and parsing them.
#utils.test_get_sample_dynamoDB_Data(dynamodb_table_name='WV04<dynamodb_table_name>')

