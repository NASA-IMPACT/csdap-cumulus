# main_interface.py


# If called with no parameters, the options are displayed and the user can choose which one to use
# example: python code/main_interface.py

# If called with the automation parameter and a value, then the code automatically selects that path and executes it.
# example: python code/main_interface.py --automation --value 7

# Imports
import argparse
import sys
import os
import json
import time
import math
from datetime import datetime, timezone, timedelta
import boto3
from botocore.exceptions import ClientError, NoCredentialsError, PartialCredentialsError

# Allows running from one directory up.
sys.path.append(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))

# Local App Imports
from lib.utils                  import utils
from lib.sqlite_wrapper         import DatabaseManager
from lib.backup_system          import BackupSystem
from lib.manifest_processing    import ManifestProcessing
from lib.cmr_wrapper            import CMRRequestManager
from config.config              import config




# # Section START
# ####################################################################################################################################################################################
# # Section: Delete specific Granule files from S3 and DynamoDB rows            START
# ####################################################################################################################################################################################

# ################
# # Helper Functions for handling Deletes of S3 files and DynamoDB Rows
# ################

# This just makes sure I am connected to AWS before proceeding
def test_aws_credentials(is_silent=True):
    sts = boto3.client("sts")
    try:
        identity = sts.get_caller_identity()
        #print("Connected to AWS - Verified")
        if(is_silent == False):
            print("Connected to AWS!")
            print(f"Account: {identity['Account']}")
            print(f"UserArn: {identity['Arn']}")
        return True
    #except ClientError as e:
    except (ClientError, NoCredentialsError, PartialCredentialsError) as e:
        print(f'ERROR: AWS credential test failed.  Error Message: {e}')
        #print("ERROR: AWS credential test failed.")
        #print(e)
        return False


# Get the list of individual full s3 file paths for a given DynamoDB Key (file_path), and validate using the granule id.
# REbuild the file paths for S3 from the DynamoDB
def get_s3_file_paths__from__dynamo_db_file_path_value(DynamoDB_Key__file_path="", granule_id_validate_string=""):
    s3_file_paths = []
    is_error__get_s3_file_paths = False
    error_message__get_s3_file_paths = ""

    is_pass_validation = True  # Falsifiable.  This turns to False if any of the validation steps fail.

    # Make sure this key path is not blank
    if(DynamoDB_Key__file_path==""):
        s3_file_paths = []
        is_error__get_s3_file_paths = True
        error_message__get_s3_file_paths = error_message__get_s3_file_paths + " | get_s3_file_paths__from__dynamo_db_file_path_value: Parameter DynamoDB_Key__file_path was blank.  You must supply a DynamoDB_Key__file_path value."
        is_pass_validation = False

    # Make sure the granule_id_validate_string is not blank
    if(granule_id_validate_string==""):
        s3_file_paths = []
        is_error__get_s3_file_paths = True
        error_message__get_s3_file_paths = error_message__get_s3_file_paths + " | get_s3_file_paths__from__dynamo_db_file_path_value: Parameter granule_id_validate_string was blank.  You must supply a granule_id_validate_string value."
        is_pass_validation = False

    # Make sure the granule id is contained in the file_path
    granule_id_in__file_path = granule_id_validate_string in DynamoDB_Key__file_path
    if(granule_id_in__file_path == False):
        s3_file_paths = []
        is_error__get_s3_file_paths = True
        error_message__get_s3_file_paths = error_message__get_s3_file_paths + " | The granule_id_validate_string parameter must be contained in DynamoDB_Key__file_path.  If the granule_id is not found in the dynamoDB Key, that means this may be the wrong file to delete.  This also validates the length and dataset by proxy."
        is_pass_validation = False

    # Only proceed if the validation passed
    if(is_pass_validation == True):
        s3_file_paths.append(f'{DynamoDB_Key__file_path}-cmr.json')
        s3_file_paths.append(f'{DynamoDB_Key__file_path}-BROWSE.jpg')
        s3_file_paths.append(f'{DynamoDB_Key__file_path}.tif')
        s3_file_paths.append(f'{DynamoDB_Key__file_path}.xml')
        s3_file_paths.append(f'{DynamoDB_Key__file_path}.tar')
        s3_file_paths.append(f'{DynamoDB_Key__file_path}.rename')
        # Additional Variants
        s3_file_paths.append(f'{DynamoDB_Key__file_path}.ntf')
        s3_file_paths.append(f'{DynamoDB_Key__file_path}-thumb.jpg')

    # Return the values
    return s3_file_paths, is_error__get_s3_file_paths, error_message__get_s3_file_paths


# Gets the correct Matching DynamoDB table from the internal db_name_key (Each SQLite table corresponds to a dynamoDB table)
def helper__dynamoDB__get_dynamoDB_table_name__from__db_name_key(db_name_key="DEFAULT"):
    ret__dynamoDB_table_name = None

    # # DynamoDB Tables
    # WV01<dynamodb_table_name>
    # WV02<dynamodb_table_name>
    # WV03<dynamodb_table_name>
    # WV04<dynamodb_table_name>
    # GE01<dynamodb_table_name>

    if(db_name_key=="WV01"):
        ret__dynamoDB_table_name = "WV01<dynamodb_table_name>"
    if(db_name_key=="WV02"):
        ret__dynamoDB_table_name = "WV02<dynamodb_table_name>"
    if(db_name_key=="WV03"):
        ret__dynamoDB_table_name = "WV03<dynamodb_table_name>"
    if(db_name_key=="WV04"):
        ret__dynamoDB_table_name = "WV04<dynamodb_table_name>"
    if(db_name_key=="GE01"):
        ret__dynamoDB_table_name = "GE01<dynamodb_table_name>"
    
    return ret__dynamoDB_table_name

# ################
# # Helper: Actual Function that does the Deleting from S3
# ################

# # ONLY DELETE A SINGLE S3 KEY PATH WITH THIS FUNCTION
#
# is_deleted__s3_delete, is_error__s3_delete, error_message__s3_delete = delete_s3_file(bucket='', key='')
def delete_s3_file(bucket='', key=''):
    s3 = boto3.client("s3")

    is_deleted      = True      # this is also a proxy for is file NOT present.. so if we try to delete a file that is not present, nothing fails and the function return tells us the file was 'deleted'.
    is_error        = False
    error_message   = f''

    #if(bucket==''):
    if bucket is None or bucket.strip() == '':
        is_deleted      = False
        is_error        = True
        error_message   = f"delete_s3_file: Failed to delete '{key}' from bucket '{bucket}': Cannot pass a blank bucket value into this function"
        return is_deleted, is_error, error_message

    #if(key==''):
    if key is None or key.strip() == '':
        is_deleted      = False
        is_error        = True
        error_message   = f"delete_s3_file: Failed to delete '{key}' from bucket '{bucket}': Cannot pass a blank key value into this function"
        return is_deleted, is_error, error_message


    try:
        response = s3.delete_object(Bucket=bucket, Key=key)
        # If we reach here, either the file existed and was deleted,
        # or it didn't exist and S3 treated it as a success.
        #print(f"File '{key}' is now gone from bucket '{bucket}'.")
        is_deleted      = True
        is_error        = False
        #return True
        return is_deleted, is_error, error_message

    except ClientError as e:
        # Handle only real failures (permissions, missing bucket, etc.)
        #print(f"Failed to delete '{key}': {e}")
        #return False
        is_deleted      = False
        is_error        = True
        error_message   = f"Failed to delete '{key}' from bucket '{bucket}': ClientError Message: {e}" #f''
        return is_deleted, is_error, error_message

# # DELETE A BATCH OF S3 KEY PATHS IN ONE AWS COMMAND WITH THIS FUNCTION (6x more efficient)
#
# 'keys' input example
# 
# keys_to_delete = [
#     "folder/object1.txt",
#     "folder/object2.txt",
#     "folder/object3.txt",
#     # ...
# ]
# 
# is_deleted, is_error, err_msg = delete_s3_files("mybucket", keys_to_delete)
#
# if is_error:
#     print(f"Batch delete failed: {err_msg}")
# else:
#     print("All objects deleted successfully (including any that didn't exist).")
#
#
# is_deleted__s3_batch_delete, is_error__s3_batch_delete, error_message__s3_batch_delete = delete_s3_files(bucket='', keys=[...])
def delete_s3_files(bucket='', keys=None):
    s3 = boto3.client("s3")

    is_deleted      = True
    is_error        = False
    error_message   = ''

    # Validate bucket
    if bucket is None or bucket.strip() == '':
        return False, True, f"delete_s3_files: Cannot pass a blank bucket value into this function.  Deletes that did NOT happen: Failed to delete '{keys}' from bucket '{bucket}'"

    # Validate keys list
    if keys is None or len(keys) == 0:
        return False, True, f"delete_s3_files: Keys list cannot be empty.  Deletes that did NOT happen: Failed to delete '{keys}' from bucket '{bucket}'"
    
    # Validate individual keys
    for key in keys:
        if key is None or key.strip() == '':
            return False, True, f"delete_s3_files: Blank key found in keys list: Blank Key: '{key}'.  Failed to delete '{keys}' from bucket '{bucket}'"

    # Build bulk delete payload
    objects = [{'Key': key} for key in keys]

    try:
        response = s3.delete_objects(
            Bucket=bucket,
            Delete={'Objects': objects}
        )

        # S3 bulk delete semantics:
        # - Missing objects count as successful deletions
        # - Only actual permission/bucket/account errors throw exceptions

        # If we reach here, the batch delete itself succeeded
        is_deleted = True
        is_error   = False
        return is_deleted, is_error, error_message

    except ClientError as e:
        is_deleted    = False
        is_error      = True
        error_message = f"delete_s3_files: ClientError during delete_objects: {e}.  Failed to delete '{keys}' from bucket '{bucket}'"
        return is_deleted, is_error, error_message


# ################
# # Helper: Actual Function that does the Deleting from DynamoDB
# ################

# # ONLY DELETE A SINGLE DYNAMODB ROW WITH THIS FUNCTION
#
# Deletes a dynamoDB row, 
# is_deleted__dynamoDB_Row_Delete, is_error__dynamoDB_Row_Delete, error_message__dynamoDB_Row_Delete = delete_dynamoDB_row(dynamoDB_table_name=dynamoDB_table_name, dynamoDB_key=dynamoDB_key)
def delete_dynamoDB_row(dynamoDB_table_name='', dynamoDB_key=None):
    
    is_deleted      = False
    is_error        = False
    error_message   = ''

    # Validate input
    if dynamoDB_table_name is None or dynamoDB_table_name.strip() == '':
        is_error = True
        error_message = f'Error: dynamoDB_table_name cannot be blank.  Rows Not Deleted: dynamoDB_table_name: {dynamoDB_table_name}, dynamoDB_key: {dynamoDB_key}'
        return is_deleted, is_error, error_message

    # if dynamoDB_key is None or dynamoDB_key.strip() == '':
    #     is_error = True
    #     error_message = 'Error: dynamoDB_key cannot be blank.'
    #     return is_deleted, is_error, error_message
    
    # Validate key dict
    if dynamoDB_key is None or not isinstance(dynamoDB_key, dict):
        is_error = True
        error_message = f'Error: dynamoDB_key must be a dict and cannot be None.  Rows Not Deleted: dynamoDB_table_name: {dynamoDB_table_name}, dynamoDB_key: {dynamoDB_key}'
        return is_deleted, is_error, error_message

    # Validate that "file_path" exists in the dict
    if "file_path" not in dynamoDB_key:
        is_error = True
        error_message = f'Error: dynamoDB_key must contain "file_path".  Rows Not Deleted: dynamoDB_table_name: {dynamoDB_table_name}, dynamoDB_key: {dynamoDB_key}'
        return is_deleted, is_error, error_message


    dynamodb = boto3.resource("dynamodb", region_name='<AWS_Region>')
    table = dynamodb.Table(dynamoDB_table_name)

    try:
        response = table.delete_item(
            #Key = { "file_path": dynamoDB_key },
            Key = dynamoDB_key,
            ReturnValues = "ALL_OLD"
        )

        # ALL_OLD returns the deleted item if it existed
        if "Attributes" in response:
            # Row existed and was deleted
            is_deleted = True
            return is_deleted, is_error, error_message
        else:
            # Row did not exist — treat as successfully deleted
            is_deleted = True
            return is_deleted, is_error, error_message

    except ClientError as e:
        is_error = True
        error_message = f"Error deleting DynamoDB row: {e}.  Rows Not Deleted: dynamoDB_table_name: {dynamoDB_table_name}, dynamoDB_key: {dynamoDB_key}"
        return is_deleted, is_error, error_message


# Support Function to wrap the keys properly
def to_dynamo_key(py_key):
    return {
        "file_path": {"S": py_key["file_path"]}
    }


# # DELETE A BATCH OF DynamoDB ROWS (25 max in one request) IN ONE AWS COMMAND WITH THIS FUNCTION (about 6x more efficient)
#
# is_deleted__dynamoDB_BatchDelete, is_error__dynamoDB_BatchDelete, error_message__dynamoDB_BatchDelete = delete_dynamoDB_rows(dynamoDB_table_name=dynamoDB_table_name, dynamoDB_keys=[{...}, {...}, ...])
def delete_dynamoDB_rows(dynamoDB_table_name='', dynamoDB_keys=None):

    is_deleted      = False
    is_error        = False
    error_message   = ''

    # Validate table name
    if dynamoDB_table_name is None or dynamoDB_table_name.strip() == '':
        return False, True, "Error: dynamoDB_table_name cannot be blank."

    # Validate list of keys
    if dynamoDB_keys is None or not isinstance(dynamoDB_keys, list) or len(dynamoDB_keys) == 0:
        return False, True, f"Error: dynamoDB_keys must be a non-empty list.  Rows Not Deleted: dynamoDB_table_name: {dynamoDB_table_name}, dynamoDB_keys: {dynamoDB_keys}"

    # DynamoDB batch_write_item max = 25 items
    if len(dynamoDB_keys) > 25:
        return False, True, f"Error: DynamoDB batch delete supports a maximum of 25 rows. You passed {len(dynamoDB_keys)}.  Rows Not Deleted: dynamoDB_table_name: {dynamoDB_table_name}, dynamoDB_keys: {dynamoDB_keys}"

    # Validate each key
    for key in dynamoDB_keys:
        if key is None or not isinstance(key, dict):
            return False, True, f"Error: each DynamoDB key must be a dict.  Rows Not Deleted: dynamoDB_table_name: {dynamoDB_table_name}, dynamoDB_keys: {dynamoDB_keys}"
        if "file_path" not in key:
            return False, True, f'Error: each DynamoDB key dict must contain "file_path".  Rows Not Deleted: dynamoDB_table_name: {dynamoDB_table_name}, dynamoDB_keys: {dynamoDB_keys}'

    dynamodb = boto3.client("dynamodb", region_name="<AWS_Region>")

    # Build batch delete request
    # delete_requests = [
    #     {"DeleteRequest": {"Key": key}}
    #     for key in dynamoDB_keys
    # ]
    delete_requests = [
        {"DeleteRequest": {"Key": to_dynamo_key(key)}} 
        for key in dynamoDB_keys
    ]


    try:
        response = dynamodb.batch_write_item(
            RequestItems={dynamoDB_table_name: delete_requests}
        )

        # If UnprocessedItems is empty → everything deleted successfully
        unprocessed = response.get("UnprocessedItems", {})
        if unprocessed and dynamoDB_table_name in unprocessed:
            # DynamoDB occasionally leaves some items unprocessed
            # You can decide whether to retry — but per your instructions,
            # error grouping is fine.
            is_deleted    = False
            is_error      = True
            error_message = f"Some DynamoDB rows were not processed (These were not deleted): {unprocessed}.  Total Rows passed in: dynamoDB_table_name: {dynamoDB_table_name}, dynamoDB_keys: {dynamoDB_keys}"
            return is_deleted, is_error, error_message

        # All rows deleted or treated as deleted (missing rows count as success)
        is_deleted = True
        is_error   = False
        return is_deleted, is_error, error_message

    except ClientError as e:
        is_deleted    = False
        is_error      = True
        error_message = f"Error deleting DynamoDB rows: {e}.  Rows Not Deleted: dynamoDB_table_name: {dynamoDB_table_name}, dynamoDB_keys: {dynamoDB_keys}"
        return is_deleted, is_error, error_message


# ################
# # The Actual function to do the heavy lifting.  Handles deleting and outputing a report.
# ################

# # # Usage Examples
#
# # WV04 - Single Batch, Single Granule, Detailed Logging on
# helper__Execute_Delete_Granules_from_S3_and_DynamoDB_and_Update_Processing(db_name_key="WV04", delivery_deletes__num_of_batches_to_run=1, delivery_deletes__max_num_of_granules_to_select_per_batch=1, max_db_chunk_size=100000, delivery_deletes__max_retries=3, is_just_do_all_remaining=False, highly_detailed_logging=True, is_delete_granules_in_batches=False, max_num_of_granules_per_delete_batch=25)
#
# # WV04 - Small Batch of 2, 3 Granules per batch (6 granules total), Detailed Logging on
# helper__Execute_Delete_Granules_from_S3_and_DynamoDB_and_Update_Processing(db_name_key="WV04", delivery_deletes__num_of_batches_to_run=2, delivery_deletes__max_num_of_granules_to_select_per_batch=3, max_db_chunk_size=100000, delivery_deletes__max_retries=3, is_just_do_all_remaining=False, highly_detailed_logging=True, is_delete_granules_in_batches=True, max_num_of_granules_per_delete_batch=25)
#
# # WV04 - Remaining Granules (batch size calculated), Large Batches of 5k granules per batch, Detailed Loggin OFF
# # helper__Execute_Delete_Granules_from_S3_and_DynamoDB_and_Update_Processing(db_name_key="WV04", delivery_deletes__num_of_batches_to_run=1000, delivery_deletes__max_num_of_granules_to_select_per_batch=5000, max_db_chunk_size=100000, delivery_deletes__max_retries=3, is_just_do_all_remaining=False, highly_detailed_logging=False, is_delete_granules_in_batches=True, max_num_of_granules_per_delete_batch=25)

# # The Actual function to do the heavy lifting.  Handles deleting and outputing a report.
#
# # Batch Delete Params:
# is_delete_granules_in_batches=True,       # This means that up to N number of granules will be collected before a boto3 s3 and DynamoDB delete operation is performed.  Performing multiple deletes in a single command is far more efficient than calling boto3 for every s3 file and for every dynamoDB row.  The only cost here is that if there is one fail, the local DB will get a fail/retry count for all the granules in the batch.
# max_num_of_granules_per_delete_batch=25   # We are limited to 25 granules because we can only delete 25 dynamoDB rows in a single call, each dynamoDB row is a single granule.  S3 can do up to 1000 files in one call, to keep the deletes synced, I'm letting the dynamoDB limiting factor be the limiter for S3 as well, so we can batch 25 granules worth of files into the s3 as well, which is about 150 files (6 files x 1 granule).
def helper__Execute_Delete_Granules_from_S3_and_DynamoDB_and_Update_Processing(db_name_key="DEFAULT", delivery_deletes__num_of_batches_to_run=1, delivery_deletes__max_num_of_granules_to_select_per_batch=1, max_db_chunk_size=100000, delivery_deletes__max_retries=3, is_just_do_all_remaining=False, highly_detailed_logging=True, is_delete_granules_in_batches=True, max_num_of_granules_per_delete_batch=25):
    print(f'')
    print(f'helper__Execute_Delete_Granules_from_S3_and_DynamoDB_and_Update_Processing:      STARTED')
    print(f'')

    # This is the max number of rows that can be deleted from a dynamoDB table on AWS in a single boto3 request.
    aws_dynamoDB_Max_rows_per_delete = 25

    # Total Time Tracking - Start Time
    time__total__start = time.time()

    # Hard Coded for now because it is the only bucket we are working with for now.
    s3_bucket_name = "<delivery-bucket-name>"

    # Info for the report at the bottom of this function
    time__db_select__elapsed__LIST = []
    time__db_update__elapsed__LIST = []
    time__db_count__elapsed__LIST = []
    #
    time__loop__elapsed__LIST = [] # This one is a bit different and tracks loop time, but does the same analysis on it. # time__loop__elapsed  

    # Get the Count of how many Total Granules there are remaining
    time__db_count__start   = time.time()
    total_remaining_count__BEFORE = DatabaseManager.get_count__Granules_Ready_For_Delete(db_name_key=db_name_key, max_retries=delivery_deletes__max_retries)
    time__db_count__end     = time.time()
    time__db_count__elapsed = time__db_count__end - time__db_count__start
    time__db_count__elapsed__LIST.append(time__db_count__elapsed)

    # This var current_granule_rows_remaining_count is really just a running estimate.. making the above query inside the batch destroys the efficiency on very large tables (instead of taking micro seconds, the query takes minutes).. so using this variable for estimates instead.
    current_granule_rows_remaining_count = total_remaining_count__BEFORE

    # This var is for keeping track of how many granules we are trying to chew through on this run.  It is initially calculated based on how many batches and how many granules per batch.
    total_estimated_granules_this_run = 0 # Defaults at 0, so if nothing changes, then nothing happens further below.

    # If we just want to do as many of the remaining granules as possible...
    print(f'')
    if(is_just_do_all_remaining == True):
        # Then calculate how many batches we would need to run and overwrite: delivery_deletes__num_of_batches_to_run with that number.
        if(delivery_deletes__max_num_of_granules_to_select_per_batch > 0):
            est_num_of_batches_to_run           = int(total_remaining_count__BEFORE / delivery_deletes__max_num_of_granules_to_select_per_batch) + 2 # Adding two to account for int rounding down and an extra 1 for padding.
            print(f'  is_just_do_all_remaining: was set to {is_just_do_all_remaining}.  Calculating')
            print(f'    Estimated that about {est_num_of_batches_to_run} batches will be needed of size {delivery_deletes__max_num_of_granules_to_select_per_batch} to complete processing for {total_remaining_count__BEFORE} Remaining Granules in DB {db_name_key}')
            print(f'    Overwriting original delivery_deletes__num_of_batches_to_run value of: {delivery_deletes__num_of_batches_to_run} batches to run, with new calculated value of: {est_num_of_batches_to_run} batches to run.')
            #delivery_deletes__num_of_batches_to_run = est_num_of_batches_to_run * delivery_deletes__max_num_of_granules_to_select_per_batch
            delivery_deletes__num_of_batches_to_run = est_num_of_batches_to_run 
            #
            #total_estimated_granules_this_run = delivery_deletes__num_of_batches_to_run
            total_estimated_granules_this_run = delivery_deletes__num_of_batches_to_run * delivery_deletes__max_num_of_granules_to_select_per_batch
            print(f'    Expected that about {total_estimated_granules_this_run} total granules will be run in {delivery_deletes__num_of_batches_to_run} batches of size {delivery_deletes__max_num_of_granules_to_select_per_batch} granules each.  Before this run begins, there are {total_remaining_count__BEFORE} Remaining Granules in the DB {db_name_key}')
    else:
        print(f'  is_just_do_all_remaining: was set to {is_just_do_all_remaining}.  Using input value for delivery_deletes__num_of_batches_to_run of {delivery_deletes__num_of_batches_to_run}')
        total_estimated_granules_this_run = delivery_deletes__num_of_batches_to_run * delivery_deletes__max_num_of_granules_to_select_per_batch
        #print(f'    Estimated that about {delivery_deletes__num_of_batches_to_run} batches will be needed of size {delivery_deletes__max_num_of_granules_to_select_per_batch} to complete processing for {total_remaining_count__BEFORE} Remaining Granules')
        print(f'    Expected that about {total_estimated_granules_this_run} total granules will be run in {delivery_deletes__num_of_batches_to_run} batches of size {delivery_deletes__max_num_of_granules_to_select_per_batch} granules each.  Before this run begins, there are {total_remaining_count__BEFORE} Remaining Granules in the DB {db_name_key}')

    # Calculate number of chunks
    number_of_db_chunks = 0
    if(total_estimated_granules_this_run > 0):
        if(max_db_chunk_size > 0):
            number_of_db_chunks = math.ceil(total_estimated_granules_this_run / max_db_chunk_size) # The last chunk will always select a smaller number of rows (rounding up catches the remainder)
            print(f'  number_of_db_chunks: {number_of_db_chunks}.  (Number times a select of max size {max_db_chunk_size} is done from the DB for this run).  Each Select Costs can cost minutes of processing time.')
        
    # Tracking the total number of time spent doing certain DB Queries.
    db_query_seconds__selects = 0
    db_query_seconds__updates = 0

    # Show the time estimate
    previously_observed_seconds_per_batch = 25.0
    est_seconds_to_complete     = (delivery_deletes__num_of_batches_to_run * previously_observed_seconds_per_batch) # somewhat over estimated observed batch average seconds. #__min_delay_seconds_between_api_requests)
    est_hours_to_complete       = math.ceil(est_seconds_to_complete / (60 * 60)) #int(est_seconds_to_complete / (60 * 60))
    #
    print(f'      Based on previously observed seconds per batch of {previously_observed_seconds_per_batch} per batch, This process will take an estimated total {est_hours_to_complete} hours to complete (Total Estimated Seconds: {est_seconds_to_complete}). ')
    print(f'        (Note: This estimate does NOT include an accurate time to do Count or Selection Queries which can take several Minutes on DBs with more than 1 million rows.)')
    print(f'        (Note: Update Queries on large databases can take several seconds, rather than microseconds on very small databases)')
    print(f'')
    #
    # Calculate additional time for DB queries - Update after I know how long these things actually take.
    est_seconds_per_large_select_statement = float(10.0) # About 10 seconds average observed in GE01.  #int(5*60) # First estimate is 5 minutes per select statement
    est_seconds_added_for_all_select_statements     = est_seconds_per_large_select_statement * number_of_db_chunks
    est_hours_added_for_all_select_statements       = math.ceil(est_seconds_added_for_all_select_statements / (60 * 60)) #int(est_seconds_added_for_all_select_statements / (60 * 60))
    #
    est_seconds_per_small_update_statement = float(0.001) # 0.001 per update is actually pretty close to observed in GE01.   # First estimate is 1000 granules can be updated per second.  Will modify with real data.
    est_seconds_added_for_all_update_statements     = est_seconds_per_small_update_statement * total_estimated_granules_this_run
    est_hours_added_for_all_update_statements       = math.ceil(est_seconds_added_for_all_update_statements / (60 * 60)) #int(est_seconds_added_for_all_select_statements / (60 * 60))
    #
    est_seconds_per_count_statement = float(2.27)  # 2.27 seconds Observed in GE01 #float(5*60) # First estimate is 5 minutes per count statement
    est_seconds_added_for_all_count_statements     = est_seconds_per_count_statement * 2 # We only count twice, once before processing and once at the end of the run.
    est_hours_added_for_all_count_statements       = math.ceil(est_seconds_added_for_all_count_statements / (60 * 60)) #int(est_seconds_added_for_all_select_statements / (60 * 60))
    #
    print(f'      Additional Time Estimates for DB Queries')
    print(f'        All Large Chunk Select Statements: ({number_of_db_chunks} Large Select Statements) Totals: Est Total Hours: {est_hours_added_for_all_select_statements}.  Est Total Seconds: {est_seconds_added_for_all_select_statements}')
    print(f'        All Small Update Statements:       ({total_estimated_granules_this_run} Small Update Statements) Totals: Est Total Hours: {est_hours_added_for_all_update_statements}.  Est Total Seconds: {est_seconds_added_for_all_update_statements}')
    print(f'        All Count Statements:              (2 Count Statements) Totals: Est Total Hours: {est_hours_added_for_all_count_statements}.  Est Total Seconds: {est_seconds_added_for_all_count_statements}')
    print(f'')
    #
    est_total_seconds = est_seconds_to_complete + est_seconds_added_for_all_select_statements + est_seconds_added_for_all_update_statements + est_seconds_added_for_all_count_statements
    est_total_hours   = math.ceil(est_total_seconds / (60 * 60))
    print(f'      Total Execution Time, Including SQL Additions.')
    print(f'        Est. Total Hours (rounded up):   {est_total_hours}, Est. Total Seconds: {est_total_seconds}')
    
    # An Array to hold granules being poped out of the chunk select, and placed into the batch array to be processed in each batch.
    current_db_chunk_granule_list = []

    # Reference - defined earlier in the code
    #
    # # Info for the report at the bottom of this function
    # time__db_select__elapsed__LIST = []
    # time__db_update__elapsed__LIST = []
    # time__db_count__elapsed__LIST = []
    #
    report__num_of_chunks_selected = 0              # New Report Param, keeping track of how many Select Statements we ran
    report__total_num_of_granules_selected = 0      # New Report Param, keeping track of how many actual granules were selected (including the last chunk which will likely be smaller than the max size.)
    report__num_of_batches_attempted = 0
    report__num_of_batches_completed = 0
    #
    report__num_of_updates_made__localDB_granules_deleted           = 0     # Deleted from both S3 and DynamoDB (Or was already in that state where it was all deleted)
    report__num_of_updates_made__localDB_granules_NOT_deleted       = 0     # At least an S3 file and/or DynamoDB item was found and Could not be deleted.  This increments the num_of_attempts_counter
    #
    report__num_of_errors = 0
    report__error_log = []

    # Output for the log
    print(f'')
    print(f'  About to enter the Batch Granule Processing Loop: Params:')
    print(f'    Settings:')
    print(f'      is_just_do_all_remaining:                                   {is_just_do_all_remaining}')
    print(f'      delivery_deletes__num_of_batches_to_run:                    {delivery_deletes__num_of_batches_to_run}')
    print(f'      delivery_deletes__max_retries:                              {delivery_deletes__max_retries}')
    print(f'      delivery_deletes__max_num_of_granules_to_select_per_batch:  {delivery_deletes__max_num_of_granules_to_select_per_batch}')
    print(f'      Expected Number of DB Chunks (Select Statements):           {number_of_db_chunks}')
    print(f'      Max DB Chunk Size (Max Num of Granules Selected per Chunk): {max_db_chunk_size}')
    print(f'      is_delete_granules_in_batches:                              {is_delete_granules_in_batches}')
    print(f'      Max Number of Granules to delete per delete_batch:          {max_num_of_granules_per_delete_batch}, (This is different than selection batches above.  25 is the max possible value)')
    print(f'    Params:')
    print(f'      db_name_key:                 {db_name_key}')
    print(f'')
    print(f'      highly_detailed_logging:     {highly_detailed_logging}')
    print(f'')
    sys.stdout.flush()  # Force Terminal Output (helps with monitoring progress) # Forces all buffered print statements above to output right now

    # Control Variables
    can_proceed_with_delete_attempts__TopLevel = True

    # Get the DynamoDB
    dynamoDB_table_name = helper__dynamoDB__get_dynamoDB_table_name__from__db_name_key(db_name_key=db_name_key)

    if dynamoDB_table_name is None:
        #print(f"ERROR: Could not find a Matching DynamoDB Table name for {db_name_key}.  If there is no DynamoDB table, we cannot proceed.")
        error_message = f'ERROR: Could not find a Matching DynamoDB Table name for {db_name_key}.  If there is no DynamoDB table, we cannot proceed.'
        report__error_log.append(error_message)
        print(f'  {error_message}')
        report__num_of_errors = report__num_of_errors + 1
        sys.stdout.flush()
        can_proceed_with_delete_attempts__TopLevel = False

    if(can_proceed_with_delete_attempts__TopLevel == False):
        print(f'There was a caught error.  Cannot continue with the Deletes')
    else:

        # Each run through this loop is for a single batch.
        for i in range(delivery_deletes__num_of_batches_to_run):
            
            try:
                # Start tracking the time inside the loop.  I am also using this as a mechanism for delaying the next API Request to the CMR
                time__loop__start = time.time()

                # When a batch is run, we get a datetime object to store the attempt time
                batch_date_time = datetime.now(timezone.utc)
            
                # Starting a batch, need to increment the attempt counter 
                report__num_of_batches_attempted = report__num_of_batches_attempted + 1

                # Count starts at 0, for logging, adding 1 to it for readability
                current_batch_number = i + 1
                print(f'')
                print(f'  ------------------------------------------------------------------------')
                print(f'    Batch: {current_batch_number} of {delivery_deletes__num_of_batches_to_run}: Starting to process a new Batch of {delivery_deletes__max_num_of_granules_to_select_per_batch} Granules to Execute Delivery Buckets Delete at Datetime: {batch_date_time}')

                # Chunking Mechanism - so we don't run select statements very often.
                current_granule_rows_list = [] # These are the original Batch Items (inside this part of the loop, we have a whole batch of granules).
                #
                # Check the Current Length (how many rows are left in the db chunk list)
                current_length_of_db_chunk_list = len(current_db_chunk_granule_list)
                if(current_length_of_db_chunk_list == 0):
                    # The chunk list is empty.  This is either the first time through the loop, or a middle time through the loop that needs refilling, or maybe the last time through the loop (where there are still batches, but no more granules to select)
                    # Figure out which time through the loop (if we should be trying to reload the chunk selection or not)
                    if(report__num_of_chunks_selected < number_of_db_chunks):
                        # Does not matter if this is the first time or middle time, at this point, we need to select the next chunk.
                        time__db_select__start   = time.time()
                        current_db_chunk_granule_list = DatabaseManager.get_granules__That_Are_Ready_For_Deletes(db_name_key=db_name_key, max_num_of_granules=max_db_chunk_size, max_retries=delivery_deletes__max_retries) # max_retries=3 (max_retries is an Optional Param defaulted at 3)
                        # Fix for when out of granules (can't handle lenght of None)
                        if(current_db_chunk_granule_list == None):
                            print(f'   *Attempted New Chunk: {report__num_of_chunks_selected}, but it seems we are now out of granules to select!')
                            current_db_chunk_granule_list = []
                        time__db_select__end     = time.time()
                        time__db_select__elapsed = time__db_select__end - time__db_select__start
                        len__current_db_chunk_granule_list = len(current_db_chunk_granule_list)
                        print(f'   *** New Chunk: {report__num_of_chunks_selected}, Selected: {len__current_db_chunk_granule_list} Granules.  Seconds Elapsed: {time__db_select__elapsed}')
                        #
                        # Increment the trackers
                        time__db_select__elapsed__LIST.append(time__db_select__elapsed)
                        report__num_of_chunks_selected = report__num_of_chunks_selected + 1
                        report__total_num_of_granules_selected = report__total_num_of_granules_selected + len__current_db_chunk_granule_list
                    else:
                        # We have reached the max number of chunks that we needed to select.  Do nothing here
                        print(f'      We have reached the max number of chunks ({report__num_of_chunks_selected} out of {number_of_db_chunks}) selected for this run.  No more selections for this run.  If this repeats, it might just be trying to finish the batch numbers.') #  If this message repeats more than once, that is an error, DEBUG IT!')
                #
                # Now we have to put chunked granules in the 'current_granule_rows_list' variable.
                len_2__current_length_of_db_chunk_list = len(current_db_chunk_granule_list)
                if(len_2__current_length_of_db_chunk_list > 0):
                    # Can only proceed with this if we actually have granules in the chunked list.
                    current_granule_rows_list = [] # Have to be a list (not a 'None' for this to work)
                    #
                    # Always expecting this list to run something like 2000 times.
                    for i in range(delivery_deletes__max_num_of_granules_to_select_per_batch): 
                        # Now can only put something in the list if there is something to pop.  Can only pop if the list is NOT 0, or there will be an error!
                        # Since popping actually changes the array size while inside this first if statement, I have to do the if checking again.
                        len_3__current_length_of_db_chunk_list = len(current_db_chunk_granule_list)
                        if(len_3__current_length_of_db_chunk_list > 0):
                            # This bit of code actually will move the granule off the chunk list and then append it to the 'current_granule_rows_list', which should close the loop on this refactor!
                            granule_to_move = current_db_chunk_granule_list.pop()   # Remove Item from the chunked list
                            current_granule_rows_list.append(granule_to_move)       # Adding the removed item from the chunked list to the original current_granule_rows_list. 

                # Fix for when out of granules (can't handle lenght of None)
                len___current_granule_rows_list = len(current_granule_rows_list)

                # Print how many total granules are left, and how many were selected.
                current_num_of_granules_selected = 0
                #if(current_granule_rows_list == None):
                if(len___current_granule_rows_list == 0):
                    print(f'    No granules selected this iteration... Maybe there are no remaining granules in our local database?')
                    current_num_of_granules_selected = 0
                    current_granule_rows_list = []        # Setting from None to empty list to prevent a for loop error below.
                else:
                    current_num_of_granules_selected = len(current_granule_rows_list)
                    len_4__remaining_chunk_granules = len(current_db_chunk_granule_list)
                    #print(f'    Selected {current_num_of_granules_selected} out of (estimated) {current_granule_rows_remaining_count} remaining Granules')
                    print(f'    Pulled in {current_num_of_granules_selected} out of (estimated) {current_granule_rows_remaining_count} remaining Granules from the current selected chunk.  Selected Chunk Granules Remaining {len_4__remaining_chunk_granules}')
                    #
                    # Setting up the estimate for the next time around the loop.
                    current_granule_rows_remaining_count = current_granule_rows_remaining_count - current_num_of_granules_selected
                    if(current_granule_rows_remaining_count < 0):
                        current_granule_rows_remaining_count = 0

                # If we need Granule Update objects.  This is the place for it.
                #
                # Line 331 (main_interface.py)

                # Force Terminal Output (helps with monitoring progress) # Forces all buffered print statements above to output right now
                sys.stdout.flush()

                # # Actually Process and Try to Delete the granule for the whole batch right here.
                # Only run this part of the loop if we actually selected at least 1 granule from the local database.
                if(current_num_of_granules_selected > 0):
                    try:
                        # Test the AWS Connection
                        is_connected_to_aws_with_valid_creds = test_aws_credentials(is_silent=True)

                        if(is_connected_to_aws_with_valid_creds == True):
                            print("    Connected to AWS:  Proceeding with DynamoDB + S3 operations...")

                            # # REFACTOR - Adding Batch Delete Params
                            # is_delete_granules_in_batches=True, max_num_of_granules_per_delete_batch=25
                            # Somewhere here, we need to fork the paths and either delete one at a time, or collect and do a batch delete.
                            #
                            # delete_in_batches_message = f'  To be deleted one S3 File and one DynamoDB Row at a time.'
                            # if(is_delete_granules_in_batches == True):
                            #     delete_in_batches_message = f'  To be deleted in batches of {max_num_of_granules_per_delete_batch} granules.'

                            #print(f'    About to iterate {current_num_of_granules_selected} granules.{delete_in_batches_message}')
                            print(f'    About to iterate {current_num_of_granules_selected} granules.')
                            if(is_delete_granules_in_batches == True):
                                # Collect batches of granules (if there are any granules to collect) and perform delete operations at once on the group
                                print(f'      To be collected and deleted in batches of {max_num_of_granules_per_delete_batch} granules.')
                                
                                # Collect Granules
                                granule_collector__dynamo_db_rows       = []  # This one can only grow to max size of 25 before being reset.
                                granule_collector__s3_file_keypaths     = []  # This one can only grow to max size of 1000.
                                granule_collector__local_db_granule_ids = []  # This one can only grow to max size of ???  // Not limited by either of the two above items
                                #
                                # Iterate all granules in the selection chunk fraction (selection batch)
                                #for current_granule in current_granule_rows_list:
                                for idx, current_granule in enumerate(current_granule_rows_list):

                                    # Will need to know later if this is the last element in the list.
                                    is_last_granule = (idx == len(current_granule_rows_list) - 1)

                                    # Get the DynamoDB file_path (which is also the primary key)
                                    current_granule__DynamoDB_Key__file_path = current_granule.DynamoDB_Key__file_path
                                    dynamoDB_key = {"file_path": f'{current_granule__DynamoDB_Key__file_path}'}

                                    # Get the Granule ID, to be used to provide some validation to the s3 file paths function
                                    current_granule__granule_id = current_granule.granule_id

                                    if(highly_detailed_logging == True):
                                        print(f'      current_granule__granule_id: {current_granule__granule_id}')
                                        print(f'        dynamoDB_key: {dynamoDB_key}')

                                    # Use the 'file_path' value to rebuild the files. 
                                    s3_file_paths, is_error__get_s3_file_paths, error_message__get_s3_file_paths = get_s3_file_paths__from__dynamo_db_file_path_value(DynamoDB_Key__file_path=current_granule__DynamoDB_Key__file_path, granule_id_validate_string=current_granule__granule_id)

                                    # log errors if any so far.
                                    if(is_error__get_s3_file_paths == True):
                                        # In here, there are no attempts to delete being made.
                                        report__num_of_errors = report__num_of_errors + 1
                                        report__error_log.append(error_message__get_s3_file_paths)

                                    # Now add the dynamo_db row and the s3_file_paths to the granule collector arrays.
                                    granule_collector__dynamo_db_rows.append(dynamoDB_key)                          # Adding DynamoDB Primary Keys (1 per granule): [{"file_path": "<path/to/granule/root>/wv01././././<granule_id>"}, {} ]
                                    granule_collector__local_db_granule_ids.append(current_granule__granule_id)     # Adding Granule ID string "<granule_id>".
                                    for s3_file_path in s3_file_paths:
                                        granule_collector__s3_file_keypaths.append(s3_file_path)  # Adding individual s3 key paths (multiple files per granule) "<path/to/granule/root>/wv01././././<granule_id>.<ext>"  # Suffix file names on the granule, sometimes more than just the extension.

                                    #
                                    # If the collector has reached it's max size, it is time to execute the deletes, if not, then just keep looping.
                                    #

                                    # Track if we have filled up the granule collector.
                                    is_granule_collector_full = False

                                    len__granule_collector__dynamo_db_rows = len(granule_collector__dynamo_db_rows)
                                    if(len__granule_collector__dynamo_db_rows < max_num_of_granules_per_delete_batch):
                                        is_granule_collector_full = False

                                        # Now just make extra sure we are not passed the DynamoDB AWS Limit
                                        if(len__granule_collector__dynamo_db_rows == aws_dynamoDB_Max_rows_per_delete):  # 25
                                            # The collector is full if we are at a value that is equal to the AWS Maximum (aws_dynamoDB_Max_rows_per_delete)
                                            is_granule_collector_full = True

                                        # Is this the very last element in the current_granule_rows_list?
                                        if (is_last_granule == True):
                                            # If we are on the last element in the list, the collector is not really full, but we will need to go ahead and do the deletes since there will not be another iteration with the current data in the collectors.
                                            is_granule_collector_full = True

                                    else:
                                        # The collector is full if we are at a value that is equal to the max_num_of_granules_per_delete_batch
                                        is_granule_collector_full = True


                                    # If the granule collector is full,
                                    if(is_granule_collector_full == True):
                                        # Time to do a batch delete and update statements.
                                        
                                        # Control Variables to determine the Update Statement Below
                                        did_any_s3_file_deletes_fail_to_delete  = False
                                        is_any_s3_errors                        = False
                                        is_any_dynamo_db_errors                 = False
                                        is_dynamo_db_record_deleted             = False

                                        # Delete Block for S3
                                        try:
                                            #is_deleted__delete_s3_key,  is_error__delete_s3_key,   error_message__delete_s3_key   = delete_s3_file(bucket= s3_bucket_name, key= s3_file_path)
                                            is_deleted__s3_batch_delete, is_error__s3_batch_delete, error_message__s3_batch_delete = delete_s3_files(bucket=s3_bucket_name, keys=granule_collector__s3_file_keypaths)  # [...]

                                            # Now process if there was an error,
                                            if(is_error__s3_batch_delete == True):
                                                is_any_s3_errors = True
                                                did_any_s3_file_deletes_fail_to_delete = True 
                                                report__error_log.append(error_message__s3_batch_delete)
                                                report__num_of_errors = report__num_of_errors + 1
                                                print(error_message__s3_batch_delete)
                                                sys.stdout.flush()
                                            else:
                                                # If there were no errors, but the file failed to delete somehow.
                                                if(is_deleted__s3_batch_delete == False):
                                                    is_any_s3_errors = True
                                                    did_any_s3_file_deletes_fail_to_delete = True 
                                                    custom_error_message = f'ERROR: No Errors when attempting to batch delete, but the files were not actually deleted.  Further Debuging required here'
                                                    report__error_log.append(custom_error_message)
                                                    report__num_of_errors = report__num_of_errors + 1
                                                    print(custom_error_message)
                                                    sys.stdout.flush()

                                        except:
                                            is_any_s3_errors = True
                                            did_any_s3_file_deletes_fail_to_delete = True 
                                            # Here would be an error deleting an individual specific S3 file path.  (In this block, it's single batch delete operation, so about 150 key paths, not single s3key)
                                            error_message = f'ERROR: There was an unexpected Error while attempting batch delete these s3_file_paths: {granule_collector__s3_file_keypaths}, Batch Number: {i}  Error Info: {e}'
                                            report__error_log.append(error_message)
                                            print(f'    {error_message}')
                                            report__num_of_errors = report__num_of_errors + 1
                                            sys.stdout.flush()


                                        # Similar logic to single s3 key delete, but works for batch deletes as well.
                                        # If ANY of the s3 deletes above failed or all the files were not deleted, then we flip this flag.  Start off assuming everything worked, and then check for the summerized conditions
                                        is_s3_files_all_gone    = True
                                        if(did_any_s3_file_deletes_fail_to_delete == True):
                                            # At least 1 file failed to delete
                                            is_s3_files_all_gone = False
                                        if(is_any_s3_errors == True):
                                            # At least 1 file delete attempt threw an error.
                                            is_s3_files_all_gone = False


                                        # Delete Block for DynamoDB
                                        #
                                        # # Nested In here is: # Delete Block for DynamoDB
                                        # If at this point, there are no S3 errors, than we are good.
                                        # Only proceed if S3 files had no errors and were deleted
                                        if(is_any_s3_errors == False):
                                            if(is_s3_files_all_gone == True):

                                                # Delete Block for DynamoDB
                                                try:
                                                    # Now delete the batch of DynamoDB Records from the server
                                                    #is_deleted__dynamoDB_Row_Delete, is_error__dynamoDB_Row_Delete,  error_message__dynamoDB_Row_Delete  = delete_dynamoDB_row(dynamoDB_table_name= dynamoDB_table_name, dynamoDB_key=dynamoDB_key)
                                                    is_deleted__dynamoDB_BatchDelete, is_error__dynamoDB_BatchDelete, error_message__dynamoDB_BatchDelete = delete_dynamoDB_rows(dynamoDB_table_name=dynamoDB_table_name, dynamoDB_keys=granule_collector__dynamo_db_rows)   # [{...}, {...}, ...]

                                                    # Simulate DynamoDB Errors and/or Success here.  This is for Debug if needed (See run_tests_delete_actions.py for how to set that up right here)

                                                    # Setting the Update Control Variables based on the function return
                                                    is_any_dynamo_db_errors     = is_error__dynamoDB_BatchDelete
                                                    is_dynamo_db_record_deleted = is_deleted__dynamoDB_BatchDelete

                                                    # Capturing the error for the log
                                                    if(is_error__dynamoDB_BatchDelete == True):
                                                        report__error_log.append(error_message__dynamoDB_BatchDelete)
                                                        report__num_of_errors = report__num_of_errors + 1
                                                        print(error_message__dynamoDB_BatchDelete)
                                                        sys.stdout.flush()

                                                except Exception as e:
                                                    # Here would be an error deleting the dynamoDB record
                                                    error_message = f'ERROR: There was an unexpected Error while attempting batch delete DynamoDB rows: {granule_collector__dynamo_db_rows}, Batch Number: {i}  Error Info: {e}'
                                                    report__error_log.append(error_message)
                                                    print(f'    {error_message}')
                                                    report__num_of_errors = report__num_of_errors + 1
                                                    sys.stdout.flush() 

                                        # Update Block for Local SQLite DB
                                        # Update Block
                                        #
                                        # This part is tricky.  
                                        # Since we are treating all the update statements as a single entity during batch deletes (we need this major optimization), then we will just look at the last granule in the batch and use that retry number to set the whole group.
                                        # This also has the added benefit of keeping the logic similar to the single granule delete operation elsewhere in the code (easier to debug).
                                        current_granule_id                      = current_granule.granule_id 
                                        #
                                        current__num_of_attempts_MCP_s3_delete  = current_granule.num_of_attempts_MCP_s3_delete
                                        new__num_of_attempts_MCP_s3_delete      = current__num_of_attempts_MCP_s3_delete + 1
                                        #
                                        current__num_of_attempts_MCP_dynamoDB_delete  = current_granule.num_of_attempts_MCP_dynamoDB_delete
                                        new__num_of_attempts_MCP_dynamoDB_delete      = current__num_of_attempts_MCP_dynamoDB_delete + 1

                                        # DB Reference in Single Granule Delete Area
                                        #
                                        # Update Statment - Including the timing of the function call
                                        time__db_update__start   = time.time()
                                        len__granule_collector__local_db_granule_ids = len(granule_collector__local_db_granule_ids)
                                        if(len__granule_collector__local_db_granule_ids > 0):
                                            rows_updated = DatabaseManager.update__granule__was_attempted_to_delete(db_name_key=db_name_key, granule_id_list=granule_collector__local_db_granule_ids, is_deleted__from_s3=is_s3_files_all_gone, is_deleted__from_dynamo_db=is_dynamo_db_record_deleted, new_num_attempts__s3=new__num_of_attempts_MCP_s3_delete, new_num_attempts__dynamoDB=new__num_of_attempts_MCP_dynamoDB_delete)
                                        #rows_updated = DatabaseManager.update__granule__was_attempted_to_delete(db_name_key=db_name_key, granule_id_list=granule_collector__local_db_granule_ids, is_deleted__from_s3=is_s3_files_all_gone, is_deleted__from_dynamo_db=is_dynamo_db_record_deleted, new_num_attempts__s3=new__num_of_attempts_MCP_s3_delete, new_num_attempts__dynamoDB=new__num_of_attempts_MCP_dynamoDB_delete)
                                        #rows_updated = DatabaseManager.update__granule__was_attempted_to_delete(db_name_key=db_name_key, granule_id_list=[current_granule_id], is_deleted__from_s3=is_s3_files_all_gone, is_deleted__from_dynamo_db=is_dynamo_db_record_deleted, new_num_attempts__s3=new__num_of_attempts_MCP_s3_delete, new_num_attempts__dynamoDB=new__num_of_attempts_MCP_dynamoDB_delete)
                                        #rows_updated = DatabaseManager.update__granule__was_attempted_to_delete(db_name_key=db_name_key, granule_id=current_granule_id, is_deleted__from_s3=is_s3_files_all_gone, is_deleted__from_dynamo_db=is_dynamo_db_record_deleted, new_num_attempts__s3=new__num_of_attempts_MCP_s3_delete, new_num_attempts__dynamoDB=new__num_of_attempts_MCP_dynamoDB_delete)
                                        #print(f'MOCK: DB Update HERE.. Would call Update function with these params: DatabaseManager.update__granule__was_attempted_to_delete(db_name_key={db_name_key}, granule_id={current_granule_id}, is_deleted__from_s3={is_s3_files_all_gone}, is_deleted__from_dynamo_db={is_dynamo_db_record_deleted}, new_num_attempts__s3={new__num_of_attempts_MCP_s3_delete}, new_num_attempts__dynamoDB={new__num_of_attempts_MCP_dynamoDB_delete})')
                                        #
                                        # Time Tracking End
                                        time__db_update__end     = time.time()
                                        time__db_update__elapsed = time__db_update__end - time__db_update__start
                                        time__db_update__elapsed__LIST.append(time__db_update__elapsed)

                                        # Reporting Stuff
                                        # Reporting Paths
                                        # report__num_of_updates_made__localDB_granules_deleted
                                        # report__num_of_updates_made__localDB_granules_NOT_deleted
                                        if(is_s3_files_all_gone == True):
                                            if(is_dynamo_db_record_deleted == True):
                                                # The only path that counts as fully deleted for each run's count.
                                                report__num_of_updates_made__localDB_granules_deleted = report__num_of_updates_made__localDB_granules_deleted + rows_updated # 1
                                            else:
                                                report__num_of_updates_made__localDB_granules_NOT_deleted = report__num_of_updates_made__localDB_granules_NOT_deleted + rows_updated # 1
                                        else:
                                            report__num_of_updates_made__localDB_granules_NOT_deleted = report__num_of_updates_made__localDB_granules_NOT_deleted + rows_updated # 1


                                        # Time to reset the granule collector arrays to prepare for the next delete batch.
                                        if(highly_detailed_logging == True):
                                            len__granule_collector__local_db_granule_ids = len(granule_collector__local_db_granule_ids)
                                            print(f'      Updated {len__granule_collector__local_db_granule_ids} local DB items.')
                                            print(f'        About to reset the granule collector for the next batch')
                                        granule_collector__dynamo_db_rows       = []
                                        granule_collector__s3_file_keypaths     = []
                                        granule_collector__local_db_granule_ids = [] 

                                        # END

                                    else:
                                        # Do nothing, just iterate again so we can add more granules and file paths to the collectors.
                                        pass

                                # END OF:       for idx, current_granule in enumerate(current_granule_rows_list):

                                pass
                                



                            else:
                                # Delete individual files and individual DynamoDB rows
                                print(f'      To be deleted one S3 File and one DynamoDB Row at a time.')

                                # Iterate all granules in the selection chunk fraction (selection batch)
                                for current_granule in current_granule_rows_list:

                                    # Get the DynamoDB file_path (which is also the primary key)
                                    current_granule__DynamoDB_Key__file_path = current_granule.DynamoDB_Key__file_path
                                    dynamoDB_key = {"file_path": f'{current_granule__DynamoDB_Key__file_path}'}

                                    # Get the Granule ID, to be used to provide some validation to the s3 file paths function
                                    current_granule__granule_id = current_granule.granule_id

                                    if(highly_detailed_logging == True):
                                        print(f'      current_granule__granule_id: {current_granule__granule_id}')
                                        print(f'        dynamoDB_key: {dynamoDB_key}')

                                    # Use the 'file_path' value to rebuild the files. 
                                    s3_file_paths, is_error__get_s3_file_paths, error_message__get_s3_file_paths = get_s3_file_paths__from__dynamo_db_file_path_value(DynamoDB_Key__file_path=current_granule__DynamoDB_Key__file_path, granule_id_validate_string=current_granule__granule_id)
                                    if(is_error__get_s3_file_paths == True):
                                        # In here, there are no attempts to delete being made.
                                        report__num_of_errors = report__num_of_errors + 1
                                        report__error_log.append(error_message__get_s3_file_paths)
                                    else:
                                        # Now Iterate each s3 file path
                                        did_any_s3_file_deletes_fail_to_delete = False
                                        is_any_s3_errors        = False
                                        #
                                        #is_s3_files_all_gone    = False   
                                        
                                        is_any_dynamo_db_errors = False
                                        is_dynamo_db_record_deleted = False

                                        # Delete Block for S3
                                        for s3_file_path in s3_file_paths:
                                            try:
                                                # This is where to run the actual S3 Delete function
                                                is_deleted__delete_s3_key, is_error__delete_s3_key, error_message__delete_s3_key = delete_s3_file(bucket=s3_bucket_name, key=s3_file_path)
                                                #print(f'MOCK: DELETE S3 Key Path:  This is where the function call goes for: is_deleted, is_error, error_message = delete_s3_file(bucket={s3_bucket_name}, key={s3_file_path})')

                                                # Simulate S3 Errors and/or Success here.  This is for Debug if needed (See run_tests_delete_actions.py for how to set that up right here)

                                                # Now process if there was an error,
                                                if(is_error__delete_s3_key == True):
                                                    is_any_s3_errors = True
                                                    did_any_s3_file_deletes_fail_to_delete = True 
                                                    report__error_log.append(error_message__delete_s3_key)
                                                    report__num_of_errors = report__num_of_errors + 1
                                                    print(error_message__delete_s3_key)
                                                    sys.stdout.flush()
                                                    #
                                                    # Do not break out of loop on error.  So we at least attempt all requested deletes for this granule.
                                                    # Break out of the loop
                                                    #break;
                                                else:
                                                    # If there were no errors, but the file failed to delete somehow.
                                                    if(is_deleted__delete_s3_key == False):
                                                        is_any_s3_errors = True
                                                        did_any_s3_file_deletes_fail_to_delete = True 
                                                        custom_error_message = f'ERROR: No Errors when attempting to delete, but the file was not actually deleted.  Further Debuging required here'
                                                        report__error_log.append(custom_error_message)
                                                        report__num_of_errors = report__num_of_errors + 1
                                                        print(custom_error_message)
                                                        sys.stdout.flush()
                                                        #
                                                        # Do not break out of loop on error.  So we at least attempt all requested deletes for this granule.
                                                        # Break out of the loop
                                                        #break;


                                            except Exception as e:
                                                is_any_s3_errors = True
                                                did_any_s3_file_deletes_fail_to_delete = True 
                                                # Here would be an error deleting an individual specific S3 file path.
                                                error_message = f'ERROR: There was an unexpected Error while attempting delete s3_file_path: {s3_file_path}, Batch Number: {i}  Error Info: {e}'
                                                report__error_log.append(error_message)
                                                print(f'    {error_message}')
                                                report__num_of_errors = report__num_of_errors + 1
                                                sys.stdout.flush()

                                        # If ANY of the s3 deletes above failed or all the files were not deleted, then we flip this flag.  Start off assuming everything worked, and then check for the summerized conditions
                                        is_s3_files_all_gone    = True
                                        if(did_any_s3_file_deletes_fail_to_delete == True):
                                            # At least 1 file failed to delete
                                            is_s3_files_all_gone = False
                                        if(is_any_s3_errors == True):
                                            # At least 1 file delete attempt threw an error.
                                            is_s3_files_all_gone = False

                                        # # Nested In here is: # Delete Block for DynamoDB
                                        # If at this point, there are no S3 errors, than we are good.
                                        # Only proceed if S3 files had no errors and were deleted
                                        if(is_any_s3_errors == False):
                                            if(is_s3_files_all_gone == True):

                                                # Delete Block for DynamoDB
                                                try:
                                                    # Now delete DynamoDB Record from the server
                                                    is_deleted__dynamoDB_Row_Delete, is_error__dynamoDB_Row_Delete, error_message__dynamoDB_Row_Delete = delete_dynamoDB_row(dynamoDB_table_name=dynamoDB_table_name, dynamoDB_key=dynamoDB_key)                                                
                                                    #print(f'MOCK DELETE DyanmoDB Record:  This is the function call goes for: is_deleted__dynamoDB_Row_Delete, is_error__dynamoDB_Row_Delete, error_message__dynamoDB_Row_Delete = delete_dynamoDB_row(dynamoDB_table_name={dynamoDB_table_name}, dynamoDB_key={dynamoDB_key})')

                                                    # Simulate DynamoDB Errors and/or Success here.  This is for Debug if needed (See run_tests_delete_actions.py for how to set that up right here)

                                                    # Setting the Update Control Variables based on the function return
                                                    is_any_dynamo_db_errors     = is_error__dynamoDB_Row_Delete
                                                    is_dynamo_db_record_deleted = is_deleted__dynamoDB_Row_Delete

                                                    # Capturing the error for the log
                                                    if(is_error__dynamoDB_Row_Delete == True):
                                                        report__error_log.append(error_message__dynamoDB_Row_Delete)
                                                        report__num_of_errors = report__num_of_errors + 1
                                                        print(error_message__dynamoDB_Row_Delete)
                                                        sys.stdout.flush()

                                                except Exception as e:
                                                    # Here would be an error deleting the dynamoDB record
                                                    error_message = f'ERROR: There was an unexpected Error while attempting delete DynamoDB: {dynamoDB_key}, Batch Number: {i}  Error Info: {e}'
                                                    report__error_log.append(error_message)
                                                    print(f'    {error_message}')
                                                    report__num_of_errors = report__num_of_errors + 1
                                                    sys.stdout.flush()

                                        # Update Block
                                        current_granule_id                      = current_granule.granule_id
                                        #
                                        current__num_of_attempts_MCP_s3_delete  = current_granule.num_of_attempts_MCP_s3_delete
                                        new__num_of_attempts_MCP_s3_delete      = current__num_of_attempts_MCP_s3_delete + 1
                                        #
                                        current__num_of_attempts_MCP_dynamoDB_delete  = current_granule.num_of_attempts_MCP_dynamoDB_delete
                                        new__num_of_attempts_MCP_dynamoDB_delete      = current__num_of_attempts_MCP_dynamoDB_delete + 1


                                        # DB Records
                                        # is_deleted_from_MCP_delivery    = Column(DateTime, nullable=True, index=True)
                                        # is_deleted_from_MCP_dynamoDB    = Column(DateTime, nullable=True, index=True)
                                        #
                                        # last_attempt_MCP_delete             = Column(DateTime, nullable=True, index=True)
                                        # last_attempt_MCP_dynamoDB_delete    = Column(DateTime, nullable=True, index=True)
                                        # #
                                        # num_of_attempts_MCP_s3_delete           = Column(Integer, nullable=False, server_default="0", index=True)
                                        # num_of_attempts_MCP_dynamoDB_delete     = Column(Integer, nullable=False, server_default="0", index=True)
                                        #

                                        # Update Statment - Including the timing of the function call
                                        time__db_update__start   = time.time()
                                        rows_updated = DatabaseManager.update__granule__was_attempted_to_delete(db_name_key=db_name_key, granule_id_list=[current_granule_id], is_deleted__from_s3=is_s3_files_all_gone, is_deleted__from_dynamo_db=is_dynamo_db_record_deleted, new_num_attempts__s3=new__num_of_attempts_MCP_s3_delete, new_num_attempts__dynamoDB=new__num_of_attempts_MCP_dynamoDB_delete)
                                        #rows_updated = DatabaseManager.update__granule__was_attempted_to_delete(db_name_key=db_name_key, granule_id=current_granule_id, is_deleted__from_s3=is_s3_files_all_gone, is_deleted__from_dynamo_db=is_dynamo_db_record_deleted, new_num_attempts__s3=new__num_of_attempts_MCP_s3_delete, new_num_attempts__dynamoDB=new__num_of_attempts_MCP_dynamoDB_delete)
                                        #print(f'MOCK: DB Update HERE.. Would call Update function with these params: DatabaseManager.update__granule__was_attempted_to_delete(db_name_key={db_name_key}, granule_id={current_granule_id}, is_deleted__from_s3={is_s3_files_all_gone}, is_deleted__from_dynamo_db={is_dynamo_db_record_deleted}, new_num_attempts__s3={new__num_of_attempts_MCP_s3_delete}, new_num_attempts__dynamoDB={new__num_of_attempts_MCP_dynamoDB_delete})')
                                        #
                                        # Time Tracking End
                                        time__db_update__end     = time.time()
                                        time__db_update__elapsed = time__db_update__end - time__db_update__start
                                        time__db_update__elapsed__LIST.append(time__db_update__elapsed)

                                        # Reporting Paths
                                        # report__num_of_updates_made__localDB_granules_deleted
                                        # report__num_of_updates_made__localDB_granules_NOT_deleted
                                        if(is_s3_files_all_gone == True):
                                            if(is_dynamo_db_record_deleted == True):
                                                # The only path that counts as fully deleted for each run's count.
                                                report__num_of_updates_made__localDB_granules_deleted = report__num_of_updates_made__localDB_granules_deleted + 1
                                            else:
                                                report__num_of_updates_made__localDB_granules_NOT_deleted = report__num_of_updates_made__localDB_granules_NOT_deleted + 1
                                        else:
                                            report__num_of_updates_made__localDB_granules_NOT_deleted = report__num_of_updates_made__localDB_granules_NOT_deleted + 1
                                    # END OF:   if(is_error__get_s3_file_paths == True):        else:
                                # END OF:   for current_granule in current_granule_rows_list:
                            # END OF:       if(is_delete_granules_in_batches == True):          else:

                        else:
                            #print("Stopping because AWS credentials are not valid.")
                            error_message = f'ERROR: AWS Credentials Check Failed: Stopping because AWS credentials are not valid.  If running locally, do you have working Short Term Keys?  Unlikely, but is AWS Down?  Batch Number: {i}'
                            report__error_log.append(error_message)
                            print(f'    {error_message}')
                            report__num_of_errors = report__num_of_errors + 1
                            sys.stdout.flush()
                        # END OF:       if(is_connected_to_aws_with_valid_creds == True):       else:

                    except Exception as e:
                        #print(f'    ERROR: There was an unexpected Error while attempting the execute the delivery deletes for this batch.  This could be because of 1 or more individual items.  Is AWS (s3 or dynamoDB or <AWS_Region>) Down?  Batch Number: {i}  Error Info: {e}')
                        error_message = f'ERROR: There was an unexpected Error while attempting the execute the delivery deletes for this batch.  This could be because of 1 or more individual items.  If running locally, do you have working Short Term Keys?  Is AWS (s3 or dynamoDB or <AWS_Region>) Down?  Batch Number: {i}  Error Info: {e}'
                        report__error_log.append(error_message)
                        print(f'    {error_message}')
                        report__num_of_errors = report__num_of_errors + 1
                        sys.stdout.flush()

                else:
                    print(f'    Out of Granules to process for this batch!')
                # END OF:   if(current_num_of_granules_selected > 0):

                # Force Terminal Output (helps with monitoring progress) # Forces all buffered print statements above to output right now
                sys.stdout.flush()

                # # Simulating variable work
                # #time.sleep(3.1)  

                # End of the loop, if needed, wait before starting on the next batch.   (that was only for CMR Requests.  If the volume gets huge during autoamted operations, this part may be necessary for S3 read/writes cap)
                #num_of_seconds_to_sleep, time__loop__elapsed = get_sleep_seconds_to_wait(min_time_needed_to_wait=cmr_checking__min_delay_seconds_between_api_requests, time__start=time__loop__start)
                num_of_seconds_to_sleep = 0.0 # I can Override this with a calculation if a delay ever needs to be forced here.
                time__loop__elapsed = time.time() - time__loop__start   # time__elapsed = time.time() - time__start
                time__loop__elapsed__LIST.append(time__loop__elapsed)
                time__loop__elapsed__rounded_up = math.ceil(time__loop__elapsed)
                #
                current_total_loop_time     = sum(time__loop__elapsed__LIST)
                current_loop_time_count     = len(time__loop__elapsed__LIST)
                #
                print(f'    Total Seconds Elapsed for this Batch: Rounded Up: {time__loop__elapsed__rounded_up}.  Actual: {time__loop__elapsed}.  Total Accumulated Loop time for {current_loop_time_count} Loops: {current_total_loop_time} Seconds')
                if(num_of_seconds_to_sleep > 0.0):
                    print(f'    Batch: {current_batch_number} of {cmr_checking__num_of_batches_to_run}: ...Waiting {num_of_seconds_to_sleep} seconds before next API Request')
                    time.sleep(num_of_seconds_to_sleep)
                print(f'')
                
                # Increment the counter that tracks when a batch is completed
                report__num_of_batches_completed = report__num_of_batches_completed + 1

                print(f'  ------------------------------------------------------------------------')
                print(f'')
                # Force Terminal Output (helps with monitoring progress) # Forces all buffered print statements above to output right now
                sys.stdout.flush()

            except Exception as e:
                #print(f'    ERROR: There was an unexpected Error at the Batch Level.  Is there a problem selecting granules from the Local DB?  Batch Number: {i}  Error Info: {e}')
                error_message = f'ERROR: There was an unexpected Error at the Batch Level.  Is there a problem selecting granules from the Local DB?  Batch Number: {i}  Error Info: {e}'
                report__error_log.append(error_message)
                print(f'    {error_message}')
                report__num_of_errors = report__num_of_errors + 1
                sys.stdout.flush()
            # END OF:       try: single batch


        # END OF:       for i in range(delivery_deletes__num_of_batches_to_run):
    
    # END OF:   if(can_proceed_with_delete_attempts__TopLevel == False):    else:

    # Now get the counts AFTER  all is done.
    time__db_count__start   = time.time()
    total_remaining_count__AFTER = DatabaseManager.get_count__Granules_Ready_For_Delete(db_name_key=db_name_key, max_retries=delivery_deletes__max_retries)
    time__db_count__end     = time.time()
    time__db_count__elapsed = time__db_count__end - time__db_count__start
    time__db_count__elapsed__LIST.append(time__db_count__elapsed)

    # Calculate how roughly how many granules {report__num_of_chunks_selected} (x {max_db_chunk_size}
    max_db_chunk_capacity_this_run = report__num_of_chunks_selected * max_db_chunk_size


    # # DB Statements - Future, maybe move this repeat thing into a function!
    #
    # Reference lists (defined earlier in the code, near the top where report stuff is defined)
    #time__db_select__elapsed__LIST = []
    #time__db_update__elapsed__LIST = []
    #time__db_count__elapsed__LIST = []
    #time__loop__elapsed__LIST = []         # Not a DB thing, but the entire batch loop.
    #
    # Select Statements
    first_db_select_time    = 0.0
    last_db_select_time     = 0.0
    average_db_select_time  = 0.0
    total_db_select_time    = 0.0
    len__time__db_select__elapsed__LIST = len(time__db_select__elapsed__LIST)
    if(len__time__db_select__elapsed__LIST > 0):
        first_db_select_time    = time__db_select__elapsed__LIST[0]
        last_db_select_time     = time__db_select__elapsed__LIST[-1]
        total_db_select_time    = sum(time__db_select__elapsed__LIST)
        average_db_select_time  = total_db_select_time / len__time__db_select__elapsed__LIST
    #
    # Update Statements
    first_db_update_time    = 0.0
    last_db_update_time     = 0.0
    average_db_update_time  = 0.0
    total_db_update_time    = 0.0
    len__time__db_update__elapsed__LIST = len(time__db_update__elapsed__LIST)
    if(len__time__db_update__elapsed__LIST > 0):
        first_db_update_time    = time__db_update__elapsed__LIST[0]
        last_db_update_time     = time__db_update__elapsed__LIST[-1]
        total_db_update_time    = sum(time__db_update__elapsed__LIST)
        average_db_update_time  = total_db_update_time / len__time__db_update__elapsed__LIST
    #
    # Count Statements
    first_db_count_time     = 0.0
    last_db_count_time      = 0.0
    average_db_count_time   = 0.0
    total_db_count_time     = 0.0
    len__time__db_count__elapsed__LIST = len(time__db_count__elapsed__LIST)
    if(len__time__db_count__elapsed__LIST > 0):
        first_db_count_time     = time__db_count__elapsed__LIST[0]
        last_db_count_time      = time__db_count__elapsed__LIST[-1]
        total_db_count_time     = sum(time__db_count__elapsed__LIST)
        average_db_count_time   = total_db_count_time / len__time__db_count__elapsed__LIST
    #
    #
    # Batch Loop Time Tracking
    first_loop_time     = 0.0
    last_loop_time      = 0.0
    average_loop_time   = 0.0
    total_loop_time     = 0.0
    len__time__loop__elapsed__LIST = len(time__loop__elapsed__LIST)
    if(len__time__loop__elapsed__LIST > 0):
        first_loop_time     = time__loop__elapsed__LIST[0]
        last_loop_time      = time__loop__elapsed__LIST[-1]
        total_loop_time     = sum(time__loop__elapsed__LIST)
        average_loop_time   = total_loop_time / len__time__loop__elapsed__LIST
    #
    #
    print(f'')
    print(f'')
    print(f'# ####################################')
    print(f'###### Diagnostics ###### START ######')
    print(f'#')
    print(f'#   DB: {db_name_key}.  Going from: {total_remaining_count__BEFORE} --to-->: {total_remaining_count__AFTER} granules')
    print(f'#')
    print(f'# DB Statement Times')
    print(f'#')
    print(f'#   Select Statements')
    print(f'#     (total_db_select_time): {total_db_select_time} seconds (with {len__time__db_select__elapsed__LIST} total select statements)')
    print(f'#       (average_db_select_time): {average_db_select_time} seconds (per select statement)')
    print(f'#       (first_db_select_time):     1: {first_db_select_time} seconds')
    print(f'#       (last_db_select_time):    N-1: {last_db_select_time} seconds')
    print(f'#')
    print(f'#   Update Statements')
    print(f'#     (total_db_update_time): {total_db_update_time} seconds (with {len__time__db_update__elapsed__LIST} total update statements)')
    print(f'#       (average_db_update_time): {average_db_update_time} seconds (per update statement)')
    print(f'#       (first_db_update_time):     1: {first_db_update_time} seconds')
    print(f'#       (last_db_update_time):    N-1: {last_db_update_time} seconds')
    print(f'#')
    print(f'#   Count Statements')
    print(f'#     (total_db_count_time):  {total_db_count_time} seconds (with {len__time__db_count__elapsed__LIST} total count statements)')
    print(f'#       (average_db_count_time):  {average_db_count_time} seconds (per count statement)')
    print(f'#       (first_db_count_time):      1: {first_db_count_time} seconds')
    print(f'#       (last_db_count_time):     N-1: {last_db_count_time} seconds')
    print(f'#')
    print(f'#')
    print(f'# Batch Loop Times')
    print(f'#')
    print(f'#   Batch Loop')
    print(f'#     (total_loop_time): {total_loop_time} seconds (with {len__time__loop__elapsed__LIST} total batch loops)')
    print(f'#       (average_loop_time): {average_loop_time} seconds (per batch loop)')
    print(f'#       (first_loop_time):     1: {first_loop_time} seconds')
    print(f'#       (last_loop_time):    N-1: {last_loop_time} seconds')
    print(f'#')
    print(f'#')
    print(f'###### Diagnostics ###### END ######')
    print(f'# ##################################')
    print(f'')

    print(f'')
    print(f'  About to Output the report:  (Settings relisted here in context with the report) ')
    print(f'    Settings:')
    print(f'      is_just_do_all_remaining:                                   {is_just_do_all_remaining}')
    print(f'      delivery_deletes__num_of_batches_to_run:                    {delivery_deletes__num_of_batches_to_run}')
    print(f'      delivery_deletes__max_retries:                              {delivery_deletes__max_retries}')
    print(f'      delivery_deletes__max_num_of_granules_to_select_per_batch:  {delivery_deletes__max_num_of_granules_to_select_per_batch}')
    print(f'    Params:')
    print(f'      db_name_key:                 {db_name_key}')
    print(f'')
    print(f'      highly_detailed_logging:     {highly_detailed_logging}')
    print(f'')
    sys.stdout.flush()
    
    # Final Run Report
    print(f'')
    print(f'############################################################################################################')
    print(f'#')
    print(f'# Delivery Bucket and DynamoDB Deletes and Updating Report: DB: {db_name_key}')
    print(f'# total_remaining_count__BEFORE:    {total_remaining_count__BEFORE}')
    print(f'#')
    print(f'# Number of Chunks Selected:      {report__num_of_chunks_selected} (x {max_db_chunk_size} = Max Chunk Capacity this run: {max_db_chunk_capacity_this_run}).  Actual Granules Selected: {report__total_num_of_granules_selected}')
    print(f'# Number of Batches Attempted:    {report__num_of_batches_attempted}')
    print(f'# Number of Batches Completed:    {report__num_of_batches_completed}')
    print(f'#')
    #
    #
    print(f'# Number of Locally Tracked Granules Deleted or Already Deleted:                      {report__num_of_updates_made__localDB_granules_deleted}')
    print(f'# Number of Locally Tracked Granules NOT Deleted (Still exist S3 and/or DynamoDB):    {report__num_of_updates_made__localDB_granules_NOT_deleted}')
    #
    #
    print(f'#')
    print(f'#')
    print(f'# Number of Errors in the whole process:    {report__num_of_errors}')
    print(f'#  Error Log:')
    sys.stdout.flush()
    error_line_counter = 0
    for error_line in report__error_log:
        print(f'#    {error_line_counter}: {error_line}')
        error_line_counter = error_line_counter + 1
    print(f'#')
    print(f'# total_remaining_count__AFTER:     {total_remaining_count__AFTER}')
    print(f'#')
    print(f'############################################################################################################')

    sys.stdout.flush()


    # Put this at the begining of any of these processes
    # # Total Time Tracking - Start Time
    # time__total__start = time.time()
    #
    # Total Time Tracking - End Time
    time__total__end = time.time()
    #
    # Raw Seconds
    time__total__elapsed = time__total__end - time__total__start  
    #
    # Converting raw seconds into Days, Hours, Minutes, and Seconds
    time_delta = timedelta(seconds=time__total__elapsed)
    # Format the time_delta cleanly into a human-readable single line
    days = time_delta.days
    hours, remainder = divmod(time_delta.seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    #
    # Output the Time Elapsed
    print(f'')
    print(f'  Total Elapsed Time for this run: {time__total__elapsed:.2f} total Seconds ')
    print(f'    Human Readable Total Duration: {days} Days, {hours} Hours, {minutes} Minutes, {seconds} Seconds')
    print(f'      -- Original Time Estimates were: {est_total_hours} Total Hours (rounded up) | {est_total_seconds} Total Seconds')
    
     
    print(f'')

    print(f'')
    print(f'helper__Execute_CMR_Request_and_Update_Processing:      REACHED THE END')
    print(f'')

    sys.stdout.flush()
# END OF        helper__Execute_Delete_Granules_from_S3_and_DynamoDB_and_Update_Processing


# # Section END
# ####################################################################################################################################################################################
# # Section: Delete specific Granule files from S3 and DynamoDB rows            END
# ####################################################################################################################################################################################




# ####################################################################################################################################################################################
# # Helper Function for doing the Heavy Lifting of Selecting, and Requesting CMR API to verify granules, and then updating the local DB
# ####################################################################################################################################################################################

# # Delay Helper
# If I want to put a min number of seconds between API requests, this lets us calculate how long we need to sleep after running some code.
# Just pass in the time__start (which should have been captured BEFORE any api request was made (or other process that requires this min sleep duration))
def get_sleep_seconds_to_wait(min_time_needed_to_wait=2.5, time__start=time.time()):
    sleep_seconds = 0

    # Calculate elapsed time since the time that was passed in
    time__elapsed = time.time() - time__start

    # How much time do we need to sleep
    sleep_seconds_needed = min_time_needed_to_wait - time__elapsed
    if (sleep_seconds_needed < 0.0):
        sleep_seconds = 0.0
    else:
        sleep_seconds = sleep_seconds_needed

    return sleep_seconds, time__elapsed

# # Input Settings Explained
# db_name_key = "WV01"  # Which Local DB are these granules coming from?
# cmr_checking__num_of_batches_to_run                     = 5 #4 # 2          # How many times the outer loop will run.
# cmr_checking__min_delay_seconds_between_api_requests    = 3.5 #2.5          # How long we should delay between api reqeusts to the CMR.
# cmr_checking__max_retries                               = 3                 # Max Retries per granule for selecting from our local database.
# cmr_checking__max_num_of_granules_to_select_per_batch   = 500 #7 #4 #500    # Testing this with 4 at a time, 500 is what we will run in production.
# highly_detailed_logging                                 = False #True #     # Setting this to True outputs a large amount of info for every granule.  This should only be set to True on tiny test runs or for Debugging errors.
# is_just_do_all_remaining                                = False             # Setting this to True will overwrite 'cmr_checking__num_of_batches_to_run' based on a calculation of how many granules are remaining in our local DB!
#
# # Usage Example: Small Test Run for WV01 - With Highly Detailed Logging
# helper__Execute_CMR_Request_and_Update_Processing(db_name_key="WV01", cmr_checking__num_of_batches_to_run=5, cmr_checking__min_delay_seconds_between_api_requests=3.5, cmr_checking__max_retries=3, cmr_checking__max_num_of_granules_to_select_per_batch=7, is_just_do_all_remaining=False, highly_detailed_logging=True)
#
# # Usage Example: Large Run for WV01 (500 granules per batch, 2000 batches -- 1 million granules to check) -- This turns in to about 2 hours to check 1 million granules.  So 200 hours to check 100 million.
# helper__Execute_CMR_Request_and_Update_Processing(db_name_key="WV01", cmr_checking__num_of_batches_to_run=2000, cmr_checking__min_delay_seconds_between_api_requests=3.5, cmr_checking__max_retries=3, cmr_checking__max_num_of_granules_to_select_per_batch=500, is_just_do_all_remaining=False, highly_detailed_logging=False)
#
# # Usage Example: Large Run for WV01 (500 granules per batch, 2000 batches -- 1 million granules to check) -- This turns in to about 2 hours to check 1 million granules.  So 200 hours to check 100 million.
# helper__Execute_CMR_Request_and_Update_Processing(db_name_key="WV01", cmr_checking__num_of_batches_to_run=2000, cmr_checking__min_delay_seconds_between_api_requests=3.5, cmr_checking__max_retries=3, cmr_checking__max_num_of_granules_to_select_per_batch=500, is_just_do_all_remaining=False, highly_detailed_logging=False)
#
# # Usage Example: Remaining Large Run for WV01 (500 granules per batch, Number of batches are calculated based on how many unresoloved granules still exist in the DB! -- Num_of_Batches * 500 = granules to check) -- The timing is still the same with the 3.5 second delay between reqeusts. This turns in to about 2 hours to check 1 million granules.  So 200 hours to check 100 million.
# helper__Execute_CMR_Request_and_Update_Processing(db_name_key="WV01", cmr_checking__num_of_batches_to_run=5, cmr_checking__min_delay_seconds_between_api_requests=3.5, cmr_checking__max_retries=3, cmr_checking__max_num_of_granules_to_select_per_batch=500, is_just_do_all_remaining=True, highly_detailed_logging=False)
#
# Looking at 200 hours for 100 million granules (about 8 days) for doing 500 per batch.  If I up the batches to 2000 (the theoretical max), then this cuts us down to 2 days for 100 million granules.  If I cut the time from 3.5 seconds delay to 2.5 seconds delay, that brings the time down a bit more.
#
# # Usage Example: Fastest and largest Chunks Run for WV01 (2000 granules per batch, Batches are calculated)
# helper__Execute_CMR_Request_and_Update_Processing(db_name_key="WV01", cmr_checking__num_of_batches_to_run=100, cmr_checking__min_delay_seconds_between_api_requests=2.5, cmr_checking__max_retries=3, cmr_checking__max_num_of_granules_to_select_per_batch=2000, is_just_do_all_remaining=True, highly_detailed_logging=False)
#
# Defaults for these params are to do a small test batch (except for the DB name key value, the Default DB does not have anything in it).
def helper__Execute_CMR_Request_and_Update_Processing(db_name_key="DEFAULT", cmr_checking__num_of_batches_to_run=5, cmr_checking__min_delay_seconds_between_api_requests=3.5, cmr_checking__max_retries=3, cmr_checking__max_num_of_granules_to_select_per_batch=7, is_just_do_all_remaining=False, highly_detailed_logging=False):
    print(f'')
    print(f'helper__Execute_CMR_Request_and_Update_Processing:      STARTED')
    print(f'')

    # Total Time Tracking - Start Time
    time__total__start = time.time()

    # Setting for how many items we can get from the DB at one time (this is based on memory constraints balanced with performance gains)
    max_db_chunk_size = 100000  # 100k seems like a fair number to start with, at 2000 granules per batch, that would give us 50 batches per chunk query.

    # Inputs (Set these Before calling the actual cmr_wrapper function that does all this heavy lifting)
    #print(f'helper__Execute_CMR_Request_and_Update_Processing: WARN: HardCoding DB Name Key To WV01 and Concept ID for this test.  The real, live version needs to be dynamic or passed in as an external parameter. ')
    #db_name_key                 = "WV01"  # Moved out of the hardcoded version to become an input param.
    #
    # Get the Collection Concept Id list dynamically.  That list is definied in get_collection_concept_id_list and will not change often - for the Automated version of this, we will need to house this info in a database table and pull it down so we can more easily update it.
    collection_concept_id__LIST = CMRRequestManager.get_collection_concept_id_list()

    # Settings
    #print(f'helper__Execute_CMR_Request_and_Update_Processing: WARN: HardCoding Double check these settings before going to the live version.')
    #
    # Translate function inputs to CMR Settings
    # cmr_checking__num_of_batches_to_run                     = 5 #4 # 2          # How many times the outer loop will run.
    # cmr_checking__min_delay_seconds_between_api_requests    = 3.5 #2.5          # How long we should delay between api reqeusts to the CMR.
    # cmr_checking__max_retries                               = 3                 # Max Retries per granule for selecting from our local database.
    # cmr_checking__max_num_of_granules_to_select_per_batch   = 500 #7 #4 #500    # Testing this with 4 at a time, 500 is what we will run in production.
    
    # This shows detailed Granule Data from the CMR.  
    # # Turn this on if I need to debug something on the live server.
    #highly_detailed_logging                                 = False #True # False

    # Info for the report at the bottom of this function
    time__db_select__elapsed__LIST = []
    time__db_update__elapsed__LIST = []
    time__db_count__elapsed__LIST = []
    #
    time__loop__elapsed__LIST = [] # This one is a bit different and tracks loop time, but does the same analysis on it. # time__loop__elapsed  

    # Get the Count of how many Total Granules there are remaining
    #total_remaining_count__BEFORE = DatabaseManager.get_remaining_granule_count__for_cmr_API_call(db_name_key=db_name_key, max_retries=cmr_checking__max_retries)
    time__db_count__start   = time.time()
    total_remaining_count__BEFORE = DatabaseManager.get_remaining_granule_count__for_cmr_API_call(db_name_key=db_name_key, max_retries=cmr_checking__max_retries)
    time__db_count__end     = time.time()
    time__db_count__elapsed = time__db_count__end - time__db_count__start
    time__db_count__elapsed__LIST.append(time__db_count__elapsed)

    # This var current_granule_rows_remaining_count is really just a running estimate.. making the above query inside the batch destroys the efficiency on very large tables (instead of taking micro seconds, the query takes minutes).. so using this variable for estimates instead.
    current_granule_rows_remaining_count = total_remaining_count__BEFORE

    # This var is for keeping track of how many granules we are trying to chew through on this run.  It is initially calculated based on how many batches and how many granules per batch.
    total_estimated_granules_this_run = 0 # Defaults at 0, so if nothing changes, then nothing happens further below.

    # If we just want to do as many of the remaining granules as possible...
    print(f'')
    if(is_just_do_all_remaining == True):
        # Then calculate how many batches we would need to run and overwrite: cmr_checking__num_of_batches_to_run with that number.
        if(cmr_checking__max_num_of_granules_to_select_per_batch > 0):
            est_num_of_batches_to_run           = int(total_remaining_count__BEFORE / cmr_checking__max_num_of_granules_to_select_per_batch) + 2 # Adding two to account for int rounding down and an extra 1 for padding.
            print(f'  is_just_do_all_remaining: was set to {is_just_do_all_remaining}.  Calculating')
            print(f'    Estimated that about {est_num_of_batches_to_run} batches will be needed of size {cmr_checking__max_num_of_granules_to_select_per_batch} to complete processing for {total_remaining_count__BEFORE} Remaining Granules in DB {db_name_key}')
            print(f'    Overwriting original cmr_checking__num_of_batches_to_run value of: {cmr_checking__num_of_batches_to_run} batches to run, with new calculated value of: {est_num_of_batches_to_run} batches to run.')
            #cmr_checking__num_of_batches_to_run = est_num_of_batches_to_run * cmr_checking__max_num_of_granules_to_select_per_batch
            cmr_checking__num_of_batches_to_run = est_num_of_batches_to_run 
            #
            #total_estimated_granules_this_run = cmr_checking__num_of_batches_to_run
            total_estimated_granules_this_run = cmr_checking__num_of_batches_to_run * cmr_checking__max_num_of_granules_to_select_per_batch
            print(f'    Expected that about {total_estimated_granules_this_run} total granules will be run in {cmr_checking__num_of_batches_to_run} batches of size {cmr_checking__max_num_of_granules_to_select_per_batch} granules each.  Before this run begins, there are {total_remaining_count__BEFORE} Remaining Granules in the DB {db_name_key}')
    else:
        print(f'  is_just_do_all_remaining: was set to {is_just_do_all_remaining}.  Using input value for cmr_checking__num_of_batches_to_run of {cmr_checking__num_of_batches_to_run}')
        total_estimated_granules_this_run = cmr_checking__num_of_batches_to_run * cmr_checking__max_num_of_granules_to_select_per_batch
        #print(f'    Estimated that about {cmr_checking__num_of_batches_to_run} batches will be needed of size {cmr_checking__max_num_of_granules_to_select_per_batch} to complete processing for {total_remaining_count__BEFORE} Remaining Granules')
        print(f'    Expected that about {total_estimated_granules_this_run} total granules will be run in {cmr_checking__num_of_batches_to_run} batches of size {cmr_checking__max_num_of_granules_to_select_per_batch} granules each.  Before this run begins, there are {total_remaining_count__BEFORE} Remaining Granules in the DB {db_name_key}')

    # Calculate number of chunks
    number_of_db_chunks = 0
    if(total_estimated_granules_this_run > 0):
        if(max_db_chunk_size > 0):
            number_of_db_chunks = math.ceil(total_estimated_granules_this_run / max_db_chunk_size) # The last chunk will always select a smaller number of rows (rounding up catches the remainder)
            print(f'  number_of_db_chunks: {number_of_db_chunks}.  (Number times a select of max size {max_db_chunk_size} is done from the DB for this run).  Each Select Costs can cost minutes of processing time.')
        
    # Tracking the total number of time spent doing certain DB Queries.
    db_query_seconds__selects = 0
    db_query_seconds__updates = 0
    
    # Show the time estimate
    est_seconds_to_complete     = (cmr_checking__num_of_batches_to_run * cmr_checking__min_delay_seconds_between_api_requests)
    est_hours_to_complete       = math.ceil(est_seconds_to_complete / (60 * 60)) #int(est_seconds_to_complete / (60 * 60))
    #
    print(f'      Based on delay of {cmr_checking__min_delay_seconds_between_api_requests} per batch API Request, This process will take an estimated total {est_hours_to_complete} hours to complete (Total Estimated Seconds: {est_seconds_to_complete}). ')
    print(f'        (Note: This estimate does NOT include an accurate time to do Count or Selection Queries which can take several Minutes on DBs with more than 1 million rows.)')
    print(f'        (Note: Update Queries on large databases can take several seconds, rather than microseconds on very small databases)')
    print(f'')
    #
    # Calculate additional time for DB queries - Update after I know how long these things actually take.
    est_seconds_per_large_select_statement = float(10.0) # About 10 seconds average observed in GE01.  #int(5*60) # First estimate is 5 minutes per select statement
    est_seconds_added_for_all_select_statements     = est_seconds_per_large_select_statement * number_of_db_chunks
    est_hours_added_for_all_select_statements       = math.ceil(est_seconds_added_for_all_select_statements / (60 * 60)) #int(est_seconds_added_for_all_select_statements / (60 * 60))
    #
    est_seconds_per_small_update_statement = float(0.001) # 0.001 per update is actually pretty close to observed in GE01.   # First estimate is 1000 granules can be updated per second.  Will modify with real data.
    est_seconds_added_for_all_update_statements     = est_seconds_per_small_update_statement * total_estimated_granules_this_run
    est_hours_added_for_all_update_statements       = math.ceil(est_seconds_added_for_all_update_statements / (60 * 60)) #int(est_seconds_added_for_all_select_statements / (60 * 60))
    #
    est_seconds_per_count_statement = float(2.27)  # 2.27 seconds Observed in GE01 #float(5*60) # First estimate is 5 minutes per count statement
    est_seconds_added_for_all_count_statements     = est_seconds_per_count_statement * 2 # We only count twice, once before processing and once at the end of the run.
    est_hours_added_for_all_count_statements       = math.ceil(est_seconds_added_for_all_count_statements / (60 * 60)) #int(est_seconds_added_for_all_select_statements / (60 * 60))
    #
    print(f'      Additional Time Estimates for DB Queries')
    print(f'        All Large Chunk Select Statements: ({number_of_db_chunks} Large Select Statements) Totals: Est Total Hours: {est_hours_added_for_all_select_statements}.  Est Total Seconds: {est_seconds_added_for_all_select_statements}')
    print(f'        All Small Update Statements:       ({total_estimated_granules_this_run} Small Update Statements) Totals: Est Total Hours: {est_hours_added_for_all_update_statements}.  Est Total Seconds: {est_seconds_added_for_all_update_statements}')
    print(f'        All Count Statements:              (2 Count Statements) Totals: Est Total Hours: {est_hours_added_for_all_count_statements}.  Est Total Seconds: {est_seconds_added_for_all_count_statements}')
    print(f'')
    #
    est_total_seconds = est_seconds_to_complete + est_seconds_added_for_all_select_statements + est_seconds_added_for_all_update_statements + est_seconds_added_for_all_count_statements
    est_total_hours   = math.ceil(est_total_seconds / (60 * 60))
    print(f'      Total Execution Time, Including SQL Additions.')
    print(f'        Est. Total Hours (rounded up):   {est_total_hours}, Est. Total Seconds: {est_total_seconds}')
    
    # An Array to hold granules being poped out of the chunk select, and placed into the batch array to be processed in each batch.
    current_db_chunk_granule_list = []

    # Reference - defined earlier in the code
    #
    # # Info for the report at the bottom of this function
    # time__db_select__elapsed__LIST = []
    # time__db_update__elapsed__LIST = []
    # time__db_count__elapsed__LIST = []
    #
    report__num_of_chunks_selected = 0              # New Report Param, keeping track of how many Select Statements we ran
    report__total_num_of_granules_selected = 0      # New Report Param, keeping track of how many actual granules were selected (including the last chunk which will likely be smaller than the max size.)
    report__num_of_batches_attempted = 0
    report__num_of_batches_completed = 0
    report__num_of_updates_made__localDB_granules_not_found_in_cmr  = 0
    report__num_of_updates_made__localDB_granules_found_in_cmr      = 0
    report__num_of_updates_made__new_granules_found_in_cmr          = 0
    report__num_of_errors = 0
    report__error_log = []

    # Output for the log
    print(f'')
    print(f'  About to enter the Batch Granule Processing Loop: Params:')
    print(f'    Settings:')
    print(f'      is_just_do_all_remaining:                                   {is_just_do_all_remaining}')
    print(f'      cmr_checking__num_of_batches_to_run:                        {cmr_checking__num_of_batches_to_run}')
    print(f'      cmr_checking__min_delay_seconds_between_api_requests:       {cmr_checking__min_delay_seconds_between_api_requests}')
    print(f'      cmr_checking__max_retries:                                  {cmr_checking__max_retries}')
    print(f'      cmr_checking__max_num_of_granules_to_select_per_batch:      {cmr_checking__max_num_of_granules_to_select_per_batch}')
    print(f'      Expected Number of DB Chunks (Select Statements):           {number_of_db_chunks}')
    print(f'      Max DB Chunk Size (Max Num of Granules Selected per Chunk): {max_db_chunk_size}')
    print(f'    Params:')
    print(f'      db_name_key:                 {db_name_key}')
    print(f'      collection_concept_id__LIST: {collection_concept_id__LIST}')
    print(f'')
    print(f'      highly_detailed_logging:     {highly_detailed_logging}')
    print(f'')
    sys.stdout.flush()  # Force Terminal Output (helps with monitoring progress) # Forces all buffered print statements above to output right now

    
    # Each run through this loop is for a single batch.
    for i in range(cmr_checking__num_of_batches_to_run):
        try:
            # Start tracking the time inside the loop.  I am also using this as a mechanism for delaying the next API Request to the CMR
            time__loop__start = time.time()

            # When a batch is run, we get a datetime object to store the attempt time
            batch_date_time = datetime.now(timezone.utc)

            # Starting a batch, need to increment the attempt counter 
            report__num_of_batches_attempted = report__num_of_batches_attempted + 1

            # Count starts at 0, for logging, adding 1 to it for readability
            current_batch_number = i + 1
            print(f'')
            print(f'  ------------------------------------------------------------------------')
            print(f'    Batch: {current_batch_number} of {cmr_checking__num_of_batches_to_run}: Starting to process a new Batch of {cmr_checking__max_num_of_granules_to_select_per_batch} Granules at Datetime: {batch_date_time}')
            
            # Refactoring this out, this is the inefficient way of selecting.  This works great for small databases, but for 1 million rows plus it grinds to a really slow crawl..
            # # The fix here I came up with is to insert a chunking mechanism so that the select statements are selecting larger chunks and spread out.  The calculations are based on how many granules we are trying to process on this run and rounded up to catch the remainder on the last db chunk select
            ##
            ## Get the remaining number of granules during this run, Select a batch of granules.
            ## These values should change after each update near the end of this outer loop.
            ##current_granule_rows_remaining_count    = # EST.  For large tables, this query takes like 10 minutes!!!  #DatabaseManager.get_remaining_granule_count__for_cmr_API_call(db_name_key=db_name_key, max_retries=cmr_checking__max_retries)
            #current_granule_rows_list               = DatabaseManager.get_granules_for_cmr_API_call(db_name_key=db_name_key, max_num_of_granules=cmr_checking__max_num_of_granules_to_select_per_batch, max_retries=cmr_checking__max_retries) # max_retries=3 (max_retries is an Optional Param defaulted at 3)
            #current_granule_rows_list = None  # Default to None (which is what the DB returned previously when nothing was selected, so placing it here so the below code can still function properly)
            current_granule_rows_list = []
            #
            # Check the Current Length (how many rows are left in the db chunk list)
            current_length_of_db_chunk_list = len(current_db_chunk_granule_list)
            if(current_length_of_db_chunk_list == 0):
                # The chunk list is empty.  This is either the first time through the loop, or a middle time through the loop that needs refilling, or maybe the last time through the loop (where there are still batches, but no more granules to select)
                # Figure out which time through the loop (if we should be trying to reload the chunk selection or not)
                if(report__num_of_chunks_selected < number_of_db_chunks):
                    # Does not matter if this is the first time or middle time, at this point, we need to select the next chunk.
                    time__db_select__start   = time.time()
                    current_db_chunk_granule_list = DatabaseManager.get_granules_for_cmr_API_call(db_name_key=db_name_key, max_num_of_granules=max_db_chunk_size, max_retries=cmr_checking__max_retries) # max_retries=3 (max_retries is an Optional Param defaulted at 3)
                    # Fix for when out of granules (can't handle lenght of None)
                    if(current_db_chunk_granule_list == None):
                        print(f'   *Attempted New Chunk: {report__num_of_chunks_selected}, but it seems we are now out of granules to select!')
                        current_db_chunk_granule_list = []
                    time__db_select__end     = time.time()
                    time__db_select__elapsed = time__db_select__end - time__db_select__start
                    len__current_db_chunk_granule_list = len(current_db_chunk_granule_list)
                    print(f'   *** New Chunk: {report__num_of_chunks_selected}, Selected: {len__current_db_chunk_granule_list} Granules.  Seconds Elapsed: {time__db_select__elapsed}')
                    #
                    # Increment the trackers
                    time__db_select__elapsed__LIST.append(time__db_select__elapsed)
                    report__num_of_chunks_selected = report__num_of_chunks_selected + 1
                    report__total_num_of_granules_selected = report__total_num_of_granules_selected + len__current_db_chunk_granule_list
                else:
                    # We have reached the max number of chunks that we needed to select.  Do nothing here
                    print(f'      We have reached the max number of chunks ({report__num_of_chunks_selected} out of {number_of_db_chunks}) selected for this run.  No more selections for this run.  If this repeats, it might just be trying to finish the batch numbers.') #  If this message repeats more than once, that is an error, DEBUG IT!')
            # 
            # Now we have to put chunked granules in the 'current_granule_rows_list' variable.
            len_2__current_length_of_db_chunk_list = len(current_db_chunk_granule_list)
            if(len_2__current_length_of_db_chunk_list > 0):
                # Can only proceed with this if we actually have granules in the chunked list.
                current_granule_rows_list = [] # Have to be a list (not a 'None' for this to work)
                #
                # Always expecting this list to run something like 2000 times.
                for i in range(cmr_checking__max_num_of_granules_to_select_per_batch): 
                    # Now can only put something in the list if there is something to pop.  Can only pop if the list is NOT 0, or there will be an error!
                    # Since popping actually changes the array size while inside this first if statement, I have to do the if checking again.
                    len_3__current_length_of_db_chunk_list = len(current_db_chunk_granule_list)
                    if(len_3__current_length_of_db_chunk_list > 0):
                        # This bit of code actually will move the granule off the chunk list and then append it to the 'current_granule_rows_list', which should close the loop on this refactor!
                        granule_to_move = current_db_chunk_granule_list.pop()   # Remove Item from the chunked list
                        current_granule_rows_list.append(granule_to_move)       # Adding the removed item from the chunked list to the original current_granule_rows_list.
            #
            # The original one liner that got refactored out..
            #current_granule_rows_list               = DatabaseManager.get_granules_for_cmr_API_call(db_name_key=db_name_key, max_num_of_granules=cmr_checking__max_num_of_granules_to_select_per_batch, max_retries=cmr_checking__max_retries) # max_retries=3 (max_retries is an Optional Param defaulted at 3)
            #

            # Fix for when out of granules (can't handle lenght of None)
            len___current_granule_rows_list = len(current_granule_rows_list)

            # Print how many total granules are left, and how many were selected.
            current_num_of_granules_selected = 0
            #if(current_granule_rows_list == None):
            if(len___current_granule_rows_list == 0):
                print(f'    No granules selected this iteration... Maybe there are no remaining granules in our local database?')
                current_num_of_granules_selected = 0
                current_granule_rows_list = []        # Setting from None to empty list to prevent a for loop error below.
            else:
                current_num_of_granules_selected = len(current_granule_rows_list)
                len_4__remaining_chunk_granules = len(current_db_chunk_granule_list)
                #print(f'    Selected {current_num_of_granules_selected} out of (estimated) {current_granule_rows_remaining_count} remaining Granules')
                print(f'    Pulled in {current_num_of_granules_selected} out of (estimated) {current_granule_rows_remaining_count} remaining Granules from the current selected chunk.  Selected Chunk Granules Remaining {len_4__remaining_chunk_granules}')
                #
                # Setting up the estimate for the next time around the loop.
                current_granule_rows_remaining_count = current_granule_rows_remaining_count - current_num_of_granules_selected
                if(current_granule_rows_remaining_count < 0):
                    current_granule_rows_remaining_count = 0

            # Making an object that can be used to update the database.
            granule_id_update_objects_list = {}#[]
            #
            # Iterate to load up this update list with an initial keys and information.
            for selected_db_granule in current_granule_rows_list:

                # Setup the new object
                new_granule_update_obj = {}
                new_granule_update_obj['is__Create_New_Granule']    = False     # This is for when a granule is not already in our local database but comes back from CMR, this can happen if we run this process after ingesting new data but before processing manifests.
                new_granule_update_obj['num_of_attempts_cmr_check'] = selected_db_granule.num_of_attempts_cmr_check     # Piping in the number of checks from the existing DB Granule
                new_granule_update_obj['batch_date_time']           = batch_date_time
                #new_granule_update_obj['needs_update']             = False    # This value gets changed at the end
                new_granule_update_obj['needs_update']              = True      # Setting this to True now because if the rest is untouched, that means we have to log an attempt.  This saves an iteration later!
                new_granule_update_obj['is__CMR_Found']             = False     # If it's in this list, it should start as False until shown otherwise..
                new_granule_update_obj['is__CMR_Downloadbale']      = False     # If it's in this list, it should start as False until shown otherwise..

                # Using the granule's id as the key to let me reduce the look up from iterating a list to a direct string array call.
                # This means, that I can later process all updates in a kind of linear way and for all all update types rather than iterating the updates multiple times.
                object_key_name__granule_id = f'{selected_db_granule.granule_id}'
                can_add_this_granule = CMRRequestManager.check_granule_id_against_db_name_key(db_name_key=db_name_key, granule_id=object_key_name__granule_id)
                if(can_add_this_granule == True):
                    granule_id_update_objects_list[object_key_name__granule_id] = new_granule_update_obj
                else:
                    print(f'    WARNING: The DB Name Key: {db_name_key} and Granule ID: {object_key_name__granule_id}. Did not match')

            # Force Terminal Output (helps with monitoring progress) # Forces all buffered print statements above to output right now
            sys.stdout.flush()

            # # Actually Make the API Request for the whole batch right here.
            # Only run this part of the loop if we actually selected at least 1 granule from the local database.
            if(current_num_of_granules_selected > 0):
                try:
                    # Output for the log
                    print(f'    Making an API Request to the CMR for {current_num_of_granules_selected} selected granules and all of our known collection concept ids...')

                    # Run the CMR API Reqeust
                    cmr_response_JSON, has_api_error = CMRRequestManager.send_CMR_API_Post_Request_For_Granule_Batch(granule_rows_list=current_granule_rows_list, collection_concept_id_list=collection_concept_id__LIST)
                    
                    # Defaults
                    hits = 0
                    items = []
                    if not cmr_response_JSON:
                        print(f'      The response JSON was completely blank.')
                    else:
                        # Getting some of the props and parsing them out
                        hits    = cmr_response_JSON.get('hits', 0)
                        items   = cmr_response_JSON.get('items', [])

                    # Output for the log
                    print(f'    CMR API Request got {hits} hits out of {current_num_of_granules_selected} Granules from our DB selection.')


                    # This is where parsing the granule response from CMR starts.
                    # Only proceed if we got hits (returned results from the CMR), if not, then output a message to the log saying this.
                    if(hits == 0):
                        print(f'    No Granule Search Hits to process from CMR for this batch.  Batch: {current_batch_number} of {cmr_checking__num_of_batches_to_run}')
                    else:
                        # Output for the log
                        print(f'    Iterating through and reading each Granule result hit from the CMR...')

                        # Iterate through each granule result that came from the CMR
                        for cmr_response_item in items:
                            try:
                                # # Guide for processing this JSON - Possibly slightly out dated
                                #
                                # "items[].meta",                   // Item Top Level object, holds top level info
                                # "items[].meta.concept-type",      // Verify this is granule.  Value should be: "granule"
                                # "items[].meta.concept-id",        // The Granule's Concept ID, starts with letter "G" Example: "G2744189394-CSDA"
                                #
                                # "items[].umm",                    // Item Top Level object, holds most of the Granule Metadata 
                                # "items[].umm.GranuleUR",          // Holds the Granule ID (as we know it).  Example: "WV01_20171119060932_102001006BB20B00_17NOV19060932-P1BS-501699587090_03_P033"
                                # "items[].umm.RelatedUrls,"        // Holds a list of Download URLs // To verify if this granule is downloadlable: items[0].umm.RelatedUrls    must exist AND must not be a blank array (have at least one URL property that is not blank AND have a 'Type': that is equal to: 'GET DATA')
                                #
                                # # Extra Stuff
                                # If we want to go deeper, we can analyze the files
                                # This tells us if there is actual file size content
                                # "items[].umm.DataGranule.ArchiveAndDistributionInformation[].SizeInBytes",
                                # # In these keys, we can also get the list of files as well.

                                # Gather all required info.  If any of this fails, we do not have a granule to update (maybe something on the CMR side did not process this granule correctly?)
                                item__meta              = cmr_response_item.get('meta', {})
                                item__concept_type      = item__meta.get('concept-type', "")
                                item__concept_id        = item__meta.get('concept-id', "")
                                #
                                item__umm               = cmr_response_item.get('umm', {})
                                item__GranuleUR         = item__umm.get('GranuleUR', "")
                                #
                                item__RelatedUrls       = item__umm.get('RelatedUrls', [])
                                #
                                # # Getting these down inside of the loop. -- Iterate all URLs to check this stuff, stop when constraint is satisfied.
                                # item__RelatedUrls_URL   = item__RelatedUrls[0].get('URL', "")
                                # item__RelatedUrls_Type  = item__RelatedUrls[0].get('Type', "")

                                # Stringify the expected strings so we don't get mess in the DB (Santizing)
                                item__concept_id   = f'{item__concept_id}'
                                item__concept_type = f'{item__concept_type}'
                                item__GranuleUR    = f'{item__GranuleUR}'

                                # Need to pipe in existing granule attempts count
                                #new_granule_update_obj['num_of_attempts_cmr_check'] = selected_db_granule.num_of_attempts_cmr_check     # Piping in the number of checks from the existing DB Granule
                                current_granule__num_of_attempts_cmr_check = 0 # Default is 0 for new granules.  We assume this is a new granule until shown that it is not.

                                # Is this a newly seen granule? (Granule that only exists in CMR and not yet in the local database?)
                                # Checking the existing keys to see if it is present.
                                #new_granule_update_obj['is__Create_New_Granule']  = False     # This is for when a granule is not already in our local database but comes back from CMR, this can happen if we run this process after ingesting new data but before processing manifests.
                                is_new_granule = True  # Default to True until proven false (until we know otherwise)
                                selected_granule_keys = granule_id_update_objects_list.keys()
                                for key in selected_granule_keys:
                                    if(key == item__GranuleUR):
                                        is_new_granule = False # Found this granule ID in the list, that means it is NOT new.. setting to False
                                        current_granule__num_of_attempts_cmr_check = granule_id_update_objects_list[key]["num_of_attempts_cmr_check"] # Bringing over the existing granule's number of attempts
                                        break;

                                if(highly_detailed_logging == True):
                                    print(f'')
                                    print(f'      DEBUG:: selected_granule_keys: {selected_granule_keys} ')
                                    print(f'      DEBUG:: is_new_granule:        {is_new_granule} ')
                                    print(f'')

                                if(highly_detailed_logging == True):
                                    # Output for the Log
                                    #print(f'      (Highly Detailed Logging): {highly_detailed_logging} ')
                                    print(f'      Current Granule from CMR, Observed Data: ')
                                    print(f'        item__concept_type:  {item__concept_type}')
                                    print(f'        item__concept_id:    {item__concept_id}')
                                    print(f'        item__GranuleUR:     {item__GranuleUR}')

                                sys.stdout.flush()

                                # In this section, I'm verifying that we are looking at a granule and then checking to see if at least one download URL is present (a 'GET DATA' url type).
                                # The updates later will be one of two paths for granules from the CMR, and a third path for granules not found in CMR
                                # This bit checks for the two paths for found granules from the CMR                                
                                is_granule_found                = False     # This variable controls if we even found the granule or not (also controls which update specific DB update should happen based on finding the granule)
                                to_save__granule_concept_id     = ""
                                to_save__granule_id             = ""        # This is NOT an update, but I am using what CMR says the granule UR is to update our local DB, this lets me skip doing a whole bunch of costly checkpoints in the code after recieving the data... also, the missed granules will get updated in a later step blindly, so both lists should get handled with no problems.  
                                is_downloadable                 = False

                                # Does the CMR response object say that this part is a granule?
                                if(item__concept_type == "granule"):
                                    to_save__granule_concept_id = item__concept_id      # Value like: "G2744189394-CSDA"
                                    if(item__GranuleUR != ""):
                                        to_save__granule_id = item__GranuleUR
                                        is_granule_found = True

                                        # Now the sub check to see if the granules are downloadable
                                        # For a granule to be downloadable: # items[].umm.RelatedUrls    must exist AND must not be a blank array (have at least one URL property that is not blank AND have a 'Type': that is equal to: 'GET DATA')
                                        for related_url in item__RelatedUrls:
                                            related_url_URL   = related_url.get('URL', "")
                                            related_url_Type  = related_url.get('Type', "")

                                            if(related_url_Type == "GET DATA"):
                                                if(related_url_URL != ""):
                                                    is_downloadable = True
                                                    # Exit the loop so we don't check any more after we already found an existing one.
                                                    break;


                                # # Important: Standarize the Update Object so we can process it in a linear way.
                                # We've got all the info.. now to save the granule to the big update list.
                                # Remember, We are only looking at a singl granule from the CMR.
                                # This part of the code creates a new update object and adds it to 'granule_id_update_objects_list' by granule id key
                                # # The cool part about using it's id as the key is that if the granule is in the initial update objects list, then it should get overwritten with new information found in the CMR, if it is not in the list, it gets added and processed anyway!
                                current_CMR_Granule__update_obj = {}
                                if(is_granule_found == True):
                                    # At this point, we know we have a granule that was found in the CMR and needs an update
                                    current_CMR_Granule__update_obj['is__Create_New_Granule']           = is_new_granule               # False     # This is for when a granule is not already in our local database but comes back from CMR, this can happen if we run this process after ingesting new data but before processing manifests. 
                                    current_CMR_Granule__update_obj['num_of_attempts_cmr_check']        = current_granule__num_of_attempts_cmr_check  # This was handled earlier in the code and already accounts for a new granule VS bringing in data from an existing granule.
                                    current_CMR_Granule__update_obj['batch_date_time']                  = batch_date_time
                                    current_CMR_Granule__update_obj['needs_update']                     = True
                                    current_CMR_Granule__update_obj['is__CMR_Found']                    = True
                                    current_CMR_Granule__update_obj['is__CMR_Downloadbale']             = is_downloadable
                                    current_CMR_Granule__update_obj['to_save__granule_concept_id']      = to_save__granule_concept_id

                                    # Use the Granule ID that came from the CMR (if it matches, it will overwrite the update object correctly)
                                    to_save__granule_id = f'{to_save__granule_id}'

                                    # Make sure this granule belongs in the current local database (we do not want duplicate granules scattered across different local databases.)
                                    can_add_this_granule = CMRRequestManager.check_granule_id_against_db_name_key(db_name_key=db_name_key, granule_id=to_save__granule_id)

                                    if(can_add_this_granule == True):
                                        granule_id_update_objects_list[to_save__granule_id] = current_CMR_Granule__update_obj
                                    else:
                                        print(f'    WARNING: CMR Returned a Granule ID that does not match the DB Name Key!: The DB Name Key: {db_name_key} and Granule ID: {to_save__granule_id}. Skipping the Update Object.')

                                # End of Parsing CMR Reqeust infos

                            except Exception as e:
                                #print(f'      ERROR: There was an error when parsing through the item key from an individual granule returned from the CMR API Request.  cmr_response_item: {cmr_response_item}.  Error Info: {e}')
                                error_message = f'ERROR: There was an error when parsing through the item key from an individual granule returned from the CMR API Request.  Batch Number: {i}.  cmr_response_item: {cmr_response_item}.  Error Info: {e}'
                                report__error_log.append(error_message)
                                print(f'      {error_message}')
                                report__num_of_errors = report__num_of_errors + 1
                                sys.stdout.flush()

                        # END OF:       for cmr_response_item in items:

                    # END OF:       if(hits == 0):      else:

                    # ############################################################
                    # # UPDATE BLOCK #
                    # ############################################################
                    #
                    # Keeping track of the update paths - Initializing data
                    update_paths_log_obj = {}
                    update_paths_log_obj['update_path_count__Local_Granule_Found_in_CMR']       = 0
                    update_paths_log_obj['update_path_count__Local_Granule_NOT_Found_in_CMR']   = 0
                    update_paths_log_obj['update_path_count__NEW_Granule_Found_in_CMR']         = 0


                    # Get the keys
                    granule_update_object_keys = granule_id_update_objects_list.keys()
                    len__granule_update_object_keys = len(granule_update_object_keys)

                    #current_batch_number
                    # Doing an Output to the console that this batch made it to the update phase
                    print(f'')
                    print(f'    Batch: {current_batch_number} of {cmr_checking__num_of_batches_to_run}: About to process updates on {len__granule_update_object_keys} objects')

                    if(has_api_error == True):
                        print(f'      There was an API Error when attempting to get this batch from the CMR.  No Updates to be done, so we can automatically retry this batch later.')
                    else:
                        # Actually iterate and do the updates
                        for granule_update_object_key in granule_update_object_keys:
                            
                            #print(f'')
                            if(highly_detailed_logging == True):
                                print(f'  About to process granule_update_object_key: {granule_update_object_key}')

                            # Getting the current object from the granule ID (used as the key)
                            current_update_obj = granule_id_update_objects_list[granule_update_object_key]

                            # First off, does this object actually need an update:
                            needs_update = current_update_obj["needs_update"]

                            # Only proceed if this object DOES need an update
                            if(needs_update == True):

                                # Time Tracking Start (Assuming the logic checks here are very tiny.. If this update cycle actually consumes a large amount of time, I'll put the time calc stuff around only the actual DB calls, but for now, I'll just wrap this whole block since only 1 of the 3 paths execute for every single granule.
                                time__db_update__start   = time.time()
                                
                                # Which Update path is this one on?
                                is__CMR_Found = current_update_obj["is__CMR_Found"]
                                if(is__CMR_Found == True):
                                    
                                    # Is this a new Granule, or confirming an existing Granule?
                                    is__Create_New_Granule = current_update_obj['is__Create_New_Granule']
                                    if(is__Create_New_Granule == True):
                                        # Update Path Confirmed:  This is a NEW Granule that was seen in the CMR but not known in the current local DB.
                                        # update_path_count__NEW_Granule_Found_in_CMR
                                        #
                                        # Get Data Needed to do this update.
                                        is__CMR_Downloadbale            = current_update_obj['is__CMR_Downloadbale']
                                        to_save__granule_concept_id     = current_update_obj['to_save__granule_concept_id']
                                        #
                                        # Do the Update
                                        rows_affected = DatabaseManager.create__new_granule__from_found_in_CMR(db_name_key=db_name_key, granule_id=granule_update_object_key, cmr_concept_id=to_save__granule_concept_id, is__cmr_downloadable=is__CMR_Downloadbale)
                                        #
                                        # Increment the Update Counter
                                        update_paths_log_obj['update_path_count__NEW_Granule_Found_in_CMR']   = update_paths_log_obj['update_path_count__NEW_Granule_Found_in_CMR'] + rows_affected

                                    else:
                                        # Update Path Confirmed:  This existing Granule was found in the CMR Response, store the new info!
                                        # update_path_count__Local_Granule_Found_in_CMR
                                        #
                                        # Get Data Needed to do this update.
                                        is__CMR_Downloadbale            = current_update_obj['is__CMR_Downloadbale']
                                        to_save__granule_concept_id     = current_update_obj['to_save__granule_concept_id']
                                        #
                                        # Do the Update
                                        rows_affected = DatabaseManager.update__granule__was_found_in_CMR(db_name_key=db_name_key, granule_id=granule_update_object_key, cmr_concept_id=to_save__granule_concept_id, is__cmr_downloadable=is__CMR_Downloadbale)
                                        #
                                        # Increment the Update Counter
                                        update_paths_log_obj['update_path_count__Local_Granule_Found_in_CMR']   = update_paths_log_obj['update_path_count__Local_Granule_Found_in_CMR'] + rows_affected

                                else:
                                    # Update Path Confirmed:  This Granule was NOT found in the CMR Response, increment the attempt
                                    # update_path_count__Local_Granule_NOT_Found_in_CMR
                                    #
                                    # Get Data Needed to do this update.
                                    num_of_attempts_cmr_check           = current_update_obj['num_of_attempts_cmr_check']
                                    new__num_of_attempts_cmr_check      = num_of_attempts_cmr_check + 1 # Just incrementing the value
                                    #
                                    # Do the Update
                                    rows_affected = DatabaseManager.update__existing_granule__was_NOT_found_in_CMR(db_name_key=db_name_key, granule_id=granule_update_object_key, num_of_attempts_cmr_check=new__num_of_attempts_cmr_check)

                                    # Increment the Update Counter
                                    update_paths_log_obj['update_path_count__Local_Granule_NOT_Found_in_CMR']   = update_paths_log_obj['update_path_count__Local_Granule_NOT_Found_in_CMR'] + rows_affected

                                # Time Tracking End
                                time__db_update__end     = time.time()
                                time__db_update__elapsed = time__db_update__end - time__db_update__start
                                time__db_update__elapsed__LIST.append(time__db_update__elapsed)

                    # Now let's print out the update report

                    # Outputting stuff so I can verify what happened in the DB
                    update_path_count__Local_Granule_Found_in_CMR       = update_paths_log_obj['update_path_count__Local_Granule_Found_in_CMR']
                    update_path_count__Local_Granule_NOT_Found_in_CMR   = update_paths_log_obj['update_path_count__Local_Granule_NOT_Found_in_CMR']
                    update_path_count__NEW_Granule_Found_in_CMR         = update_paths_log_obj['update_path_count__NEW_Granule_Found_in_CMR'] 

                    # Incrementing the total report counters
                    report__num_of_updates_made__localDB_granules_found_in_cmr      = report__num_of_updates_made__localDB_granules_found_in_cmr     + update_path_count__Local_Granule_Found_in_CMR
                    report__num_of_updates_made__localDB_granules_not_found_in_cmr  = report__num_of_updates_made__localDB_granules_not_found_in_cmr + update_path_count__Local_Granule_NOT_Found_in_CMR
                    report__num_of_updates_made__new_granules_found_in_cmr          = report__num_of_updates_made__new_granules_found_in_cmr         + update_path_count__NEW_Granule_Found_in_CMR

                    # Outputting stuff so I can verify what happened in the DB
                    if(highly_detailed_logging == True):
                        print(f'')
                        print(f'    REPORT for Batch: {current_batch_number} of {cmr_checking__num_of_batches_to_run}')
                        print(f'')
                        print(f'      db_name_key:                             {db_name_key}')
                        print(f'      has_api_error:                           {has_api_error}')
                        print(f'      granule_id_update_objects_list:          {granule_id_update_objects_list}')
                        #
                        print(f'')
                        print(f'      update_path_count__Local_Granule_Found_in_CMR:     {update_path_count__Local_Granule_Found_in_CMR}')
                        print(f'      update_path_count__Local_Granule_NOT_Found_in_CMR: {update_path_count__Local_Granule_NOT_Found_in_CMR}')
                        print(f'      update_path_count__NEW_Granule_Found_in_CMR:       {update_path_count__NEW_Granule_Found_in_CMR}')
                        print(f'')
                    else:
                        print(f'')
                        print(f'    REPORT for Batch: {current_batch_number} of {cmr_checking__num_of_batches_to_run}, Local DB: {db_name_key}, API Errors? {has_api_error}')
                        print(f'      THIS_BATCH:     Local Granules Found in CMR: {update_path_count__Local_Granule_Found_in_CMR} , Local Granules NOT Found in CMR: {update_path_count__Local_Granule_NOT_Found_in_CMR} , New Granules Found in CMR: {update_path_count__NEW_Granule_Found_in_CMR}')
                        print(f'      RUNNING_TOTALS: Local Granules Found in CMR: {report__num_of_updates_made__localDB_granules_found_in_cmr} , Local Granules NOT Found in CMR: {report__num_of_updates_made__localDB_granules_not_found_in_cmr} , New Granules Found in CMR: {report__num_of_updates_made__new_granules_found_in_cmr}')
                        print(f'')

                    # Force Terminal Output (helps with monitoring progress) # Forces all buffered print statements above to output right now
                    sys.stdout.flush() 

                except Exception as e:
                    #print(f'    ERROR: There was an unexpected Error making the CMR API Request.  Is the CMR Down?  Error Info: {e}')
                    error_message = f'ERROR: There was an unexpected Error making the CMR API Request.  Is the CMR Down?  Batch Number: {i}  Error Info: {e}'
                    report__error_log.append(error_message)
                    print(f'    {error_message}')
                    report__num_of_errors = report__num_of_errors + 1
                    sys.stdout.flush()

            # END OF:   if(current_num_of_granules_selected > 0):

            # Force Terminal Output (helps with monitoring progress) # Forces all buffered print statements above to output right now
            sys.stdout.flush()

            # # Simulating variable work
            # #time.sleep(3.1)  

            # End of the loop, if needed, wait before starting on the next batch. 
            num_of_seconds_to_sleep, time__loop__elapsed = get_sleep_seconds_to_wait(min_time_needed_to_wait=cmr_checking__min_delay_seconds_between_api_requests, time__start=time__loop__start)
            time__loop__elapsed__LIST.append(time__loop__elapsed)
            time__loop__elapsed__rounded_up = math.ceil(time__loop__elapsed)
            #
            current_total_loop_time     = sum(time__loop__elapsed__LIST)
            current_loop_time_count     = len(time__loop__elapsed__LIST)
            #
            print(f'    Total Seconds Elapsed for this Batch: Rounded Up: {time__loop__elapsed__rounded_up}.  Actual: {time__loop__elapsed}.  Total Accumulated Loop time for {current_loop_time_count} Loops: {current_total_loop_time} Seconds')
            if(num_of_seconds_to_sleep > 0.0):
                print(f'    Batch: {current_batch_number} of {cmr_checking__num_of_batches_to_run}: ...Waiting {num_of_seconds_to_sleep} seconds before next API Request')
                time.sleep(num_of_seconds_to_sleep)
            print(f'')
            
            # Increment the counter that tracks when a batch is completed
            report__num_of_batches_completed = report__num_of_batches_completed + 1

            print(f'  ------------------------------------------------------------------------')
            print(f'')
            # Force Terminal Output (helps with monitoring progress) # Forces all buffered print statements above to output right now
            sys.stdout.flush()

        except Exception as e:
            #print(f'    ERROR: There was an unexpected Error at the Batch Level.  Is there a problem selecting granules from the Local DB?  Batch Number: {i}  Error Info: {e}')
            error_message = f'ERROR: There was an unexpected Error at the Batch Level.  Is there a problem selecting granules from the Local DB?  Batch Number: {i}  Error Info: {e}'
            report__error_log.append(error_message)
            print(f'    {error_message}')
            report__num_of_errors = report__num_of_errors + 1
            sys.stdout.flush()
        # END OF:   try: single batch

        # END OF: Single Batch For Loop
    # END OF:   for i in range(cmr_checking__num_of_batches_to_run):

    # Now get the counts AFTER  all is done.
    time__db_count__start   = time.time()
    total_remaining_count__AFTER = DatabaseManager.get_remaining_granule_count__for_cmr_API_call(db_name_key=db_name_key, max_retries=cmr_checking__max_retries)
    time__db_count__end     = time.time()
    time__db_count__elapsed = time__db_count__end - time__db_count__start
    time__db_count__elapsed__LIST.append(time__db_count__elapsed)

    # Calculate how roughly how many granules {report__num_of_chunks_selected} (x {max_db_chunk_size}
    max_db_chunk_capacity_this_run = report__num_of_chunks_selected * max_db_chunk_size


    # # DB Statements - Future, maybe move this repeat thing into a function!
    #
    # Reference lists (defined earlier in the code, near the top where report stuff is defined)
    #time__db_select__elapsed__LIST = []
    #time__db_update__elapsed__LIST = []
    #time__db_count__elapsed__LIST = []
    #time__loop__elapsed__LIST = []         # Not a DB thing, but the entire batch loop.
    #
    # Select Statements
    first_db_select_time    = 0.0
    last_db_select_time     = 0.0
    average_db_select_time  = 0.0
    total_db_select_time    = 0.0
    len__time__db_select__elapsed__LIST = len(time__db_select__elapsed__LIST)
    if(len__time__db_select__elapsed__LIST > 0):
        first_db_select_time    = time__db_select__elapsed__LIST[0]
        last_db_select_time     = time__db_select__elapsed__LIST[-1]
        total_db_select_time    = sum(time__db_select__elapsed__LIST)
        average_db_select_time  = total_db_select_time / len__time__db_select__elapsed__LIST
    #
    # Update Statements
    first_db_update_time    = 0.0
    last_db_update_time     = 0.0
    average_db_update_time  = 0.0
    total_db_update_time    = 0.0
    len__time__db_update__elapsed__LIST = len(time__db_update__elapsed__LIST)
    if(len__time__db_update__elapsed__LIST > 0):
        first_db_update_time    = time__db_update__elapsed__LIST[0]
        last_db_update_time     = time__db_update__elapsed__LIST[-1]
        total_db_update_time    = sum(time__db_update__elapsed__LIST)
        average_db_update_time  = total_db_update_time / len__time__db_update__elapsed__LIST
    #
    # Count Statements
    first_db_count_time     = 0.0
    last_db_count_time      = 0.0
    average_db_count_time   = 0.0
    total_db_count_time     = 0.0
    len__time__db_count__elapsed__LIST = len(time__db_count__elapsed__LIST)
    if(len__time__db_count__elapsed__LIST > 0):
        first_db_count_time     = time__db_count__elapsed__LIST[0]
        last_db_count_time      = time__db_count__elapsed__LIST[-1]
        total_db_count_time     = sum(time__db_count__elapsed__LIST)
        average_db_count_time   = total_db_count_time / len__time__db_count__elapsed__LIST
    #
    #
    # Batch Loop Time Tracking
    first_loop_time     = 0.0
    last_loop_time      = 0.0
    average_loop_time   = 0.0
    total_loop_time     = 0.0
    len__time__loop__elapsed__LIST = len(time__loop__elapsed__LIST)
    if(len__time__loop__elapsed__LIST > 0):
        first_loop_time     = time__loop__elapsed__LIST[0]
        last_loop_time      = time__loop__elapsed__LIST[-1]
        total_loop_time     = sum(time__loop__elapsed__LIST)
        average_loop_time   = total_loop_time / len__time__loop__elapsed__LIST
    #
    #
    print(f'')
    print(f'')
    print(f'# ####################################')
    print(f'###### Diagnostics ###### START ######')
    print(f'#')
    print(f'#   DB: {db_name_key}.  Going from: {total_remaining_count__BEFORE} --to-->: {total_remaining_count__AFTER} granules')
    print(f'#')
    print(f'# DB Statement Times')
    print(f'#')
    print(f'#   Select Statements')
    print(f'#     (total_db_select_time): {total_db_select_time} seconds (with {len__time__db_select__elapsed__LIST} total select statements)')
    print(f'#       (average_db_select_time): {average_db_select_time} seconds (per select statement)')
    print(f'#       (first_db_select_time):     1: {first_db_select_time} seconds')
    print(f'#       (last_db_select_time):    N-1: {last_db_select_time} seconds')
    print(f'#')
    print(f'#   Update Statements')
    print(f'#     (total_db_update_time): {total_db_update_time} seconds (with {len__time__db_update__elapsed__LIST} total update statements)')
    print(f'#       (average_db_update_time): {average_db_update_time} seconds (per update statement)')
    print(f'#       (first_db_update_time):     1: {first_db_update_time} seconds')
    print(f'#       (last_db_update_time):    N-1: {last_db_update_time} seconds')
    print(f'#')
    print(f'#   Count Statements')
    print(f'#     (total_db_count_time):  {total_db_count_time} seconds (with {len__time__db_count__elapsed__LIST} total count statements)')
    print(f'#       (average_db_count_time):  {average_db_count_time} seconds (per count statement)')
    print(f'#       (first_db_count_time):      1: {first_db_count_time} seconds')
    print(f'#       (last_db_count_time):     N-1: {last_db_count_time} seconds')
    print(f'#')
    print(f'#')
    print(f'# Batch Loop Times')
    print(f'#')
    print(f'#   Batch Loop')
    print(f'#     (total_loop_time): {total_loop_time} seconds (with {len__time__loop__elapsed__LIST} total batch loops)')
    print(f'#       (average_loop_time): {average_loop_time} seconds (per batch loop)')
    print(f'#       (first_loop_time):     1: {first_loop_time} seconds')
    print(f'#       (last_loop_time):    N-1: {last_loop_time} seconds')
    print(f'#')
    print(f'#')
    print(f'###### Diagnostics ###### END ######')
    print(f'# ##################################')
    print(f'')

    print(f'')
    print(f'  About to Output the report:  (Settings relisted here in context with the report) ')
    print(f'    Settings:')
    print(f'      is_just_do_all_remaining:                                {is_just_do_all_remaining}')
    print(f'      cmr_checking__num_of_batches_to_run:                     {cmr_checking__num_of_batches_to_run}')
    print(f'      cmr_checking__min_delay_seconds_between_api_requests:    {cmr_checking__min_delay_seconds_between_api_requests}')
    print(f'      cmr_checking__max_retries:                               {cmr_checking__max_retries}')
    print(f'      cmr_checking__max_num_of_granules_to_select_per_batch:   {cmr_checking__max_num_of_granules_to_select_per_batch}')
    print(f'    Params:')
    print(f'      db_name_key:                 {db_name_key}')
    print(f'      collection_concept_id__LIST: {collection_concept_id__LIST}')
    print(f'')
    print(f'      highly_detailed_logging:     {highly_detailed_logging}')
    print(f'')
    sys.stdout.flush()
    
    # Final Run Report
    print(f'')
    print(f'############################################################################################################')
    print(f'#')
    print(f'# CMR Validation and Updating Report: DB: {db_name_key}')
    print(f'# total_remaining_count__BEFORE:    {total_remaining_count__BEFORE}')
    print(f'#')
    print(f'# Number of Chunks Selected:      {report__num_of_chunks_selected} (x {max_db_chunk_size} = Max Chunk Capacity this run: {max_db_chunk_capacity_this_run}).  Actual Granules Selected: {report__total_num_of_granules_selected}')
    print(f'# Number of Batches Attempted:    {report__num_of_batches_attempted}')
    print(f'# Number of Batches Completed:    {report__num_of_batches_completed}')
    print(f'#')
    print(f'# Number of Locally Tracked Granules Found in CMR (Already Ingested):          {report__num_of_updates_made__localDB_granules_found_in_cmr}')
    print(f'# Number of Locally Tracked Granules NOT found in CMR (Needs to be ingested):  {report__num_of_updates_made__localDB_granules_not_found_in_cmr}')
    print(f'# Number of New Granules Found in CMR (Needs Manifest Verifications):          {report__num_of_updates_made__new_granules_found_in_cmr}')
    print(f'#')
    print(f'# Number of Errors in the whole process:    {report__num_of_errors}')
    print(f'#  Error Log:')
    sys.stdout.flush()
    error_line_counter = 0
    for error_line in report__error_log:
        print(f'#    {error_line_counter}: {error_line}')
        error_line_counter = error_line_counter + 1
    print(f'#')
    print(f'# total_remaining_count__AFTER:     {total_remaining_count__AFTER}')
    print(f'#')
    print(f'############################################################################################################')

    sys.stdout.flush()


    # Put this at the begining of any of these processes
    # # Total Time Tracking - Start Time
    # time__total__start = time.time()
    #
    # Total Time Tracking - End Time
    time__total__end = time.time()
    #
    # Raw Seconds
    time__total__elapsed = time__total__end - time__total__start  
    #
    # Converting raw seconds into Days, Hours, Minutes, and Seconds
    time_delta = timedelta(seconds=time__total__elapsed)
    # Format the time_delta cleanly into a human-readable single line
    days = time_delta.days
    hours, remainder = divmod(time_delta.seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    #
    # Output the Time Elapsed
    print(f'')
    print(f'  Total Elapsed Time for this run: {time__total__elapsed:.2f} total Seconds ')
    print(f'    Human Readable Total Duration: {days} Days, {hours} Hours, {minutes} Minutes, {seconds} Seconds')
    print(f'      -- Original Time Estimates were: {est_total_hours} Total Hours (rounded up) | {est_total_seconds} Total Seconds')
    
     
    print(f'')

    print(f'')
    print(f'helper__Execute_CMR_Request_and_Update_Processing:      REACHED THE END')
    print(f'')

    sys.stdout.flush()



# ##########################
# # Work Flow Functions
# ##########################

# get_count_num_of_rows_in_table(sqlite_db_name_key)

# 101: "Output SQLite Table Stats for WV04",
# elif(option_selection_number == 101):
#     workflow__Output_SQLite_Table_Stats_for__WV04()
def workflow__Output_SQLite_Table_Stats_for__WV04():
    print(f'Starting workflow__Output_SQLite_Table_Stats_for__WV04()')
    SQLiteDB_name_key   = 'WV04'
    num_of_rows = DatabaseManager.get_count_num_of_rows_in_table(SQLiteDB_name_key)
    print(f'In DB: {SQLiteDB_name_key}, Found {num_of_rows} granule rows')

# 102: "Output SQLite Table Stats for WV03",
# elif(option_selection_number == 102):
#     workflow__Output_SQLite_Table_Stats_for__WV03()
def workflow__Output_SQLite_Table_Stats_for__WV03():
    print(f'Starting workflow__Output_SQLite_Table_Stats_for__WV03()')
    SQLiteDB_name_key   = 'WV03'
    num_of_rows = DatabaseManager.get_count_num_of_rows_in_table(SQLiteDB_name_key)
    print(f'In DB: {SQLiteDB_name_key}, Found {num_of_rows} granule rows')

# 103: "Output SQLite Table Stats for WV02",
# elif(option_selection_number == 103):
#     workflow__Output_SQLite_Table_Stats_for__WV02()
def workflow__Output_SQLite_Table_Stats_for__WV02():
    print(f'Starting workflow__Output_SQLite_Table_Stats_for__WV02()')
    SQLiteDB_name_key   = 'WV02'
    num_of_rows = DatabaseManager.get_count_num_of_rows_in_table(SQLiteDB_name_key)
    print(f'In DB: {SQLiteDB_name_key}, Found {num_of_rows} granule rows')

# 104: "Output SQLite Table Stats for WV01",
# elif(option_selection_number == 104):
#     workflow__Output_SQLite_Table_Stats_for__WV01()
def workflow__Output_SQLite_Table_Stats_for__WV01():
    print(f'Starting workflow__Output_SQLite_Table_Stats_for__WV01()')
    SQLiteDB_name_key   = 'WV01'
    num_of_rows = DatabaseManager.get_count_num_of_rows_in_table(SQLiteDB_name_key)
    print(f'In DB: {SQLiteDB_name_key}, Found {num_of_rows} granule rows')

# 105: "Output SQLite Table Stats for GE01"
# elif(option_selection_number == 105):
#   workflow__Output_SQLite_Table_Stats_for__GE01()
def workflow__Output_SQLite_Table_Stats_for__GE01():
    print(f'Starting workflow__Output_SQLite_Table_Stats_for__GE01()')
    SQLiteDB_name_key   = 'GE01'
    num_of_rows = DatabaseManager.get_count_num_of_rows_in_table(SQLiteDB_name_key)
    print(f'In DB: {SQLiteDB_name_key}, Found {num_of_rows} granule rows')

# 109: "Output SQLite Table Stats for All DBs"
# elif(option_selection_number == 109):
#   workflow__Output_SQLite_Table_Stats_for__All_DBs()
def workflow__Output_SQLite_Table_Stats_for__All_DBs():
    print(f'Starting workflow__Output_SQLite_Table_Stats_for__All_DBs()')
    num_of_rows__WV04 = DatabaseManager.get_count_num_of_rows_in_table("WV04")
    num_of_rows__WV03 = DatabaseManager.get_count_num_of_rows_in_table("WV03")
    num_of_rows__WV02 = DatabaseManager.get_count_num_of_rows_in_table("WV02")
    num_of_rows__WV01 = DatabaseManager.get_count_num_of_rows_in_table("WV01")
    num_of_rows__GE01 = DatabaseManager.get_count_num_of_rows_in_table("GE01")

    print(f'')
    print(f'Table Stats for All DBs')
    print(f'  WV04:  Granule Table Row Count: {num_of_rows__WV04}')
    print(f'  WV03:  Granule Table Row Count: {num_of_rows__WV03}')
    print(f'  WV02:  Granule Table Row Count: {num_of_rows__WV02}')
    print(f'  WV01:  Granule Table Row Count: {num_of_rows__WV01}')
    print(f'  GE01:  Granule Table Row Count: {num_of_rows__GE01}')
    print(f'')


def workflow__Do_Full_DynamoDB_Scan_And_Write_All_To_SQLite_for_WV04():
    print(f'Starting workflow__Do_Full_DynamoDB_Scan_And_Write_All_To_SQLite_for_WV04()')

    # Settings Needed
    dynamoDB_Table_Name = 'WV04<dynamodb_table_name>'
    SQLiteDB_name_key   = 'WV04'

    # Just incase the DB does not exist.  Calling this after a DB is created should not effect the DB
    DatabaseManager.initialize_databases()

    # Setup the Callback function - that actually inserts a record into SQLite
    write_dynamoDB_item_to_sqlite_callback_func = DatabaseManager.write_dynamoDB_item_to_sqlite

    # Call the function which scans the entire DynamoDB Table and writes it's rows to the local sqlite table.
    utils.scan_dynamoDB_and_save_to_SQLite__single_threaded(dynamodb_table_name=dynamoDB_Table_Name, sqlite_db_name_key=SQLiteDB_name_key, write_dynamoDB_item_to_sqlite_callback_func=write_dynamoDB_item_to_sqlite_callback_func)

    print(f'Now validating a small sample of the data with a small number of DB outputs (as a table, then as details).')
    print(f'')
    DatabaseManager.test__output_6_rows_of_DB_Contents_by_DB_Name__ShowAllContents(db_name_key=SQLiteDB_name_key)
    DatabaseManager.test__output_6_rows_of_DB_Contents_by_DB_Name(db_name_key=SQLiteDB_name_key)

    print(f'')

def workflow__Do_Full_DynamoDB_Scan_And_Write_All_To_SQLite_for_WV03():
    print(f'Starting workflow__Do_Full_DynamoDB_Scan_And_Write_All_To_SQLite_for_WV03()')

    # Settings Needed
    dynamoDB_Table_Name = 'WV03<dynamodb_table_name>'
    SQLiteDB_name_key   = 'WV03'

    # Just incase the DB does not exist.  Calling this after a DB is created should not effect the DB
    DatabaseManager.initialize_databases()

    # Setup the Callback function - that actually inserts a record into SQLite
    write_dynamoDB_item_to_sqlite_callback_func = DatabaseManager.write_dynamoDB_item_to_sqlite

    # Call the function which scans the entire DynamoDB Table and writes it's rows to the local sqlite table.
    utils.scan_dynamoDB_and_save_to_SQLite__single_threaded(dynamodb_table_name=dynamoDB_Table_Name, sqlite_db_name_key=SQLiteDB_name_key, write_dynamoDB_item_to_sqlite_callback_func=write_dynamoDB_item_to_sqlite_callback_func)

    print(f'Now validating a small sample of the data with a small number of DB outputs (as a table, then as details).')
    print(f'')
    DatabaseManager.test__output_6_rows_of_DB_Contents_by_DB_Name__ShowAllContents(db_name_key=SQLiteDB_name_key)
    DatabaseManager.test__output_6_rows_of_DB_Contents_by_DB_Name(db_name_key=SQLiteDB_name_key)

    print(f'')

def workflow__Do_Full_DynamoDB_Scan_And_Write_All_To_SQLite_for_WV02():
    print(f'Starting workflow__Do_Full_DynamoDB_Scan_And_Write_All_To_SQLite_for_WV02()')
    
    # Settings Needed
    dynamoDB_Table_Name = 'WV02<dynamodb_table_name>'
    SQLiteDB_name_key   = 'WV02'

    # Just incase the DB does not exist.  Calling this after a DB is created should not effect the DB
    DatabaseManager.initialize_databases()

    # Setup the Callback function - that actually inserts a record into SQLite
    write_dynamoDB_item_to_sqlite_callback_func = DatabaseManager.write_dynamoDB_item_to_sqlite

    # Call the function which scans the entire DynamoDB Table and writes it's rows to the local sqlite table.
    utils.scan_dynamoDB_and_save_to_SQLite__single_threaded(dynamodb_table_name=dynamoDB_Table_Name, sqlite_db_name_key=SQLiteDB_name_key, write_dynamoDB_item_to_sqlite_callback_func=write_dynamoDB_item_to_sqlite_callback_func)

    print(f'Now validating a small sample of the data with a small number of DB outputs (as a table, then as details).')
    print(f'')
    DatabaseManager.test__output_6_rows_of_DB_Contents_by_DB_Name__ShowAllContents(db_name_key=SQLiteDB_name_key)
    DatabaseManager.test__output_6_rows_of_DB_Contents_by_DB_Name(db_name_key=SQLiteDB_name_key)

    print(f'')

def workflow__Do_Full_DynamoDB_Scan_And_Write_All_To_SQLite_for_WV01():
    print(f'Starting workflow__Do_Full_DynamoDB_Scan_And_Write_All_To_SQLite_for_WV01()')
    
    # Settings Needed
    dynamoDB_Table_Name = 'WV01<dynamodb_table_name>'
    SQLiteDB_name_key   = 'WV01'

    # Just incase the DB does not exist.  Calling this after a DB is created should not effect the DB
    DatabaseManager.initialize_databases()

    # Setup the Callback function - that actually inserts a record into SQLite
    write_dynamoDB_item_to_sqlite_callback_func = DatabaseManager.write_dynamoDB_item_to_sqlite

    # Call the function which scans the entire DynamoDB Table and writes it's rows to the local sqlite table.
    utils.scan_dynamoDB_and_save_to_SQLite__single_threaded(dynamodb_table_name=dynamoDB_Table_Name, sqlite_db_name_key=SQLiteDB_name_key, write_dynamoDB_item_to_sqlite_callback_func=write_dynamoDB_item_to_sqlite_callback_func)

    print(f'Now validating a small sample of the data with a small number of DB outputs (as a table, then as details).')
    print(f'')
    DatabaseManager.test__output_6_rows_of_DB_Contents_by_DB_Name__ShowAllContents(db_name_key=SQLiteDB_name_key)
    DatabaseManager.test__output_6_rows_of_DB_Contents_by_DB_Name(db_name_key=SQLiteDB_name_key)

    print(f'')

def workflow__Do_Full_DynamoDB_Scan_And_Write_All_To_SQLite_for_GE01():
    print(f'Starting workflow__Do_Full_DynamoDB_Scan_And_Write_All_To_SQLite_for_GE01()')
    
    # Settings Needed
    dynamoDB_Table_Name = 'GE01<dynamodb_table_name>'
    SQLiteDB_name_key   = 'GE01'

    # Just incase the DB does not exist.  Calling this after a DB is created should not effect the DB
    DatabaseManager.initialize_databases()

    # Setup the Callback function - that actually inserts a record into SQLite
    write_dynamoDB_item_to_sqlite_callback_func = DatabaseManager.write_dynamoDB_item_to_sqlite

    # Call the function which scans the entire DynamoDB Table and writes it's rows to the local sqlite table.
    utils.scan_dynamoDB_and_save_to_SQLite__single_threaded(dynamodb_table_name=dynamoDB_Table_Name, sqlite_db_name_key=SQLiteDB_name_key, write_dynamoDB_item_to_sqlite_callback_func=write_dynamoDB_item_to_sqlite_callback_func)

    print(f'Now validating a small sample of the data with a small number of DB outputs (as a table, then as details).')
    print(f'')
    DatabaseManager.test__output_6_rows_of_DB_Contents_by_DB_Name__ShowAllContents(db_name_key=SQLiteDB_name_key)
    DatabaseManager.test__output_6_rows_of_DB_Contents_by_DB_Name(db_name_key=SQLiteDB_name_key)

    print(f'')



# 21: "Do Full Manifest Download and Extraction To Files List for PROD",
# elif(option_selection_number == 21):
#     workflow__Do_Full_Manifest_Download_And_Extraction_To_Files_List_For_PROD()
def workflow__Do_Full_Manifest_Download_And_Extraction_To_Files_List_For_PROD():
    print(f'Starting workflow__Do_Full_Manifest_Download_And_Extraction_To_Files_List_For_PROD()')
    #
    # Run the first step of manifest processing -- download the manifest, download, extract and convert to a list of Buckets and Key Paths - For PROD
    is_new_run, run_dir_path = ManifestProcessing.continue_existing__or__start_new_run()
    ManifestProcessing.download_manifest_to_run_dir__PROD(run_dir_path=run_dir_path)
    #
    print(f'Workflow: workflow__Do_Full_Manifest_Download_And_Extraction_To_Files_List_For_PROD() is completed')

# 31: "Do Full Manifest Download and Extraction To Files List for PROD DR",
# elif(option_selection_number == 31):
#     workflow__Do_Full_Manifest_Download_And_Extraction_To_Files_List_For_PROD_DR()
def workflow__Do_Full_Manifest_Download_And_Extraction_To_Files_List_For_PROD_DR():
    print(f'Starting workflow__Do_Full_Manifest_Download_And_Extraction_To_Files_List_For_PROD_DR()')
    #
    # Run the first step of manifest processing -- download the manifest, download, extract and convert to a list of Buckets and Key Paths - For PROD DR
    is_new_run, run_dir_path = ManifestProcessing.continue_existing__or__start_new_run()
    ManifestProcessing.download_manifest_to_run_dir__PROD_DR(run_dir_path=run_dir_path)
    #
    print(f'Workflow: workflow__Do_Full_Manifest_Download_And_Extraction_To_Files_List_For_PROD_DR() is completed')



# Make the Granule IDs List File from the Large Manifests


# 22: "Do Convert Manifest Files List To GranuleIDs for PROD",
# workflow__Do_Convert_Manifest_Files_List_To_GranuleIDs_For_PROD()
# convert_manifest_list_to_granule_ids__PROD
def workflow__Do_Convert_Manifest_Files_List_To_GranuleIDs_For_PROD():
    print(f'Starting workflow__Do_Convert_Manifest_Files_List_To_GranuleIDs_For_PROD()')
    #
    # Run the first step of manifest processing -- download the manifest, download, extract and convert to a list of Buckets and Key Paths - For PROD
    is_new_run, run_dir_path = ManifestProcessing.continue_existing__or__start_new_run()
    ManifestProcessing.convert_manifest_list_to_granule_ids__PROD(run_dir_path=run_dir_path)
    #
    print(f'Workflow: workflow__Do_Convert_Manifest_Files_List_To_GranuleIDs_For_PROD() is completed')

    
# 32: "Do Convert Manifest Files List To GranuleIDs for PROD DR",
# workflow__Do_Convert_Manifest_Files_List_To_GranuleIDs_For_PROD_DR
# convert_manifest_list_to_granule_ids__PROD_DR
def workflow__Do_Convert_Manifest_Files_List_To_GranuleIDs_For_PROD_DR():
    print(f'Starting workflow__Do_Convert_Manifest_Files_List_To_GranuleIDs_For_PROD_DR()')
    #
    # Run the first step of manifest processing -- download the manifest, download, extract and convert to a list of Buckets and Key Paths - For PROD
    is_new_run, run_dir_path = ManifestProcessing.continue_existing__or__start_new_run()
    ManifestProcessing.convert_manifest_list_to_granule_ids__PROD_DR(run_dir_path=run_dir_path)
    #
    print(f'Workflow: workflow__Do_Convert_Manifest_Files_List_To_GranuleIDs_For_PROD_DR() is completed')


# UPDATE THE LOCAL DB with Found Granules

# This is the part that actually reads the granule ids file and then updates the DB to say that these granule IDs are seen in the PROD DR Manifest.
# 23: "Do Update Local DB Flag For Manifest Files Found For PROD",
# workflow__Do_Update_Local_DB_Flag_For_Manifest_Files_Found_For_PROD
# update_database_for_each_granule_id__PROD
def workflow__Do_Update_Local_DB_Flag_For_Manifest_Files_Found_For_PROD():
    print(f'Starting workflow__Do_Update_Local_DB_Flag_For_Manifest_Files_Found_For_PROD()')
    #
    # Setup the Callback function - that actually does the update (or create) of a record into SQLite
    # DatabaseManager.update_or_create__manifest_column__by_granule_id(manifest_column_name, granule_id)
    update_dynamoDB__callback_func = DatabaseManager.update_or_create__manifest_column__by_granule_id 
    manifest_column_name = 'is_in_NGAP_PROD'
    # 
    #write_dynamoDB_item_to_sqlite_callback_func = DatabaseManager.write_dynamoDB_item_to_sqlite
    #
    # Run the first step of manifest processing -- download the manifest, download, extract and convert to a list of Buckets and Key Paths - For PROD
    is_new_run, run_dir_path = ManifestProcessing.continue_existing__or__start_new_run()
    ManifestProcessing.update_database_for_each_granule_id__PROD(run_dir_path=run_dir_path, manifest_column_name=manifest_column_name, update_dynamoDB__callback_func=update_dynamoDB__callback_func)
    #
    print(f'Workflow: workflow__Do_Update_Local_DB_Flag_For_Manifest_Files_Found_For_PROD() is completed')


# This is the part that actually reads the granule ids file and then updates the DB to say that these granule IDs are seen in the PROD DR Manifest.
# 33: "Do Update Local DB Flag For Manifest Files Found For PROD DR",
# workflow__Do_Update_Local_DB_Flag_For_Manifest_Files_Found_For_PROD_DR
# update_database_for_each_granule_id__PROD_DR
def workflow__Do_Update_Local_DB_Flag_For_Manifest_Files_Found_For_PROD_DR():
    print(f'Starting workflow__Do_Update_Local_DB_Flag_For_Manifest_Files_Found_For_PROD_DR()')
    #
    # Setup the Callback function - that actually does the update (or create) of a record into SQLite
    # DatabaseManager.update_or_create__manifest_column__by_granule_id(manifest_column_name, granule_id)
    update_dynamoDB__callback_func = DatabaseManager.update_or_create__manifest_column__by_granule_id 
    manifest_column_name = 'is_in_NGAP_DR_PROD'
    #
    # Run the first step of manifest processing -- download the manifest, download, extract and convert to a list of Buckets and Key Paths - For PROD
    is_new_run, run_dir_path = ManifestProcessing.continue_existing__or__start_new_run()
    ManifestProcessing.update_database_for_each_granule_id__PROD_DR(run_dir_path=run_dir_path, manifest_column_name=manifest_column_name, update_dynamoDB__callback_func=update_dynamoDB__callback_func)
    #
    print(f'Workflow: workflow__Do_Update_Local_DB_Flag_For_Manifest_Files_Found_For_PROD_DR() is completed')



#
# This is the Function that pipes the code to Select the local DB granules, make a CMR API request with those granules, and then parse the results, and then Update the Local DB.  3 Update Paths exist (1) Local Granules Found in CMR, (2) Local Granules NOT Found in CMR, (3) New Granules that are not in the local DB but were found in CMR (that last set gets added to the DB).
# 35, 36, 37, 38, 39, (and the test version is number 85)

# # 35: "Run CMR API Request Verification for WV04",
# elif(option_selection_number == 35):
# workflow__Do_CMR_API_request_verification_for_WV04()
def workflow__Do_CMR_API_request_verification_for_WV04():
    print(f'Starting workflow__Do_CMR_API_request_verification_for_WV04()')
    #
    db_name_key = "WV04"
    print(f'')
    print(f'********************************************************************************************************')
    print(f'* Calling helper__Execute_CMR_Request_and_Update_Processing for {db_name_key}')
    # Earliest tiny test just to see the detailed logging
    #helper__Execute_CMR_Request_and_Update_Processing(db_name_key=db_name_key, cmr_checking__num_of_batches_to_run=3, cmr_checking__min_delay_seconds_between_api_requests=3.5, cmr_checking__max_retries=3, cmr_checking__max_num_of_granules_to_select_per_batch=2, is_just_do_all_remaining=False, highly_detailed_logging=True)
    #
    # Do not use this one
    #helper__Execute_CMR_Request_and_Update_Processing(db_name_key=db_name_key, cmr_checking__num_of_batches_to_run=500, cmr_checking__min_delay_seconds_between_api_requests=3.5, cmr_checking__max_retries=3, cmr_checking__max_num_of_granules_to_select_per_batch=2000, is_just_do_all_remaining=True, highly_detailed_logging=False)
    #
    # Test with this one first
    helper__Execute_CMR_Request_and_Update_Processing(db_name_key=db_name_key, cmr_checking__num_of_batches_to_run=100, cmr_checking__min_delay_seconds_between_api_requests=3.5, cmr_checking__max_retries=3, cmr_checking__max_num_of_granules_to_select_per_batch=2000, is_just_do_all_remaining=False, highly_detailed_logging=False)
    #helper__Execute_CMR_Request_and_Update_Processing(db_name_key=db_name_key, cmr_checking__num_of_batches_to_run=500, cmr_checking__min_delay_seconds_between_api_requests=3.5, cmr_checking__max_retries=3, cmr_checking__max_num_of_granules_to_select_per_batch=2000, is_just_do_all_remaining=False, highly_detailed_logging=False)
    #
    # Test with this one second
    #helper__Execute_CMR_Request_and_Update_Processing(db_name_key=db_name_key, cmr_checking__num_of_batches_to_run=500, cmr_checking__min_delay_seconds_between_api_requests=3.5, cmr_checking__max_retries=3, cmr_checking__max_num_of_granules_to_select_per_batch=2000, is_just_do_all_remaining=False, highly_detailed_logging=False)
    #
    # If the above tests work, then Just do them ALL! - Max Settings! 
    #helper__Execute_CMR_Request_and_Update_Processing(db_name_key=db_name_key, cmr_checking__num_of_batches_to_run=500, cmr_checking__min_delay_seconds_between_api_requests=3.5, cmr_checking__max_retries=3, cmr_checking__max_num_of_granules_to_select_per_batch=2000, is_just_do_all_remaining=True, highly_detailed_logging=False)
    #
    print(f'********************************************************************************************************')
    print(f'')
    #
    print(f'Workflow: workflow__Do_CMR_API_request_verification_for_WV04() is completed')

# # 36: "Run CMR API Request Verification for WV03",
# elif(option_selection_number == 36):
# workflow__Do_CMR_API_request_verification_for_WV03()
def workflow__Do_CMR_API_request_verification_for_WV03():
    print(f'Starting workflow__Do_CMR_API_request_verification_for_WV03()')
    #
    db_name_key = "WV03"
    print(f'')
    print(f'********************************************************************************************************')
    print(f'* Calling helper__Execute_CMR_Request_and_Update_Processing for {db_name_key}')
    # Earliest tiny test just to see the detailed logging
    #helper__Execute_CMR_Request_and_Update_Processing(db_name_key=db_name_key, cmr_checking__num_of_batches_to_run=3, cmr_checking__min_delay_seconds_between_api_requests=3.5, cmr_checking__max_retries=3, cmr_checking__max_num_of_granules_to_select_per_batch=2, is_just_do_all_remaining=False, highly_detailed_logging=True)
    #
    # Do not use this one
    #helper__Execute_CMR_Request_and_Update_Processing(db_name_key=db_name_key, cmr_checking__num_of_batches_to_run=500, cmr_checking__min_delay_seconds_between_api_requests=3.5, cmr_checking__max_retries=3, cmr_checking__max_num_of_granules_to_select_per_batch=2000, is_just_do_all_remaining=True, highly_detailed_logging=False)
    #
    # Test with this one first
    helper__Execute_CMR_Request_and_Update_Processing(db_name_key=db_name_key, cmr_checking__num_of_batches_to_run=100, cmr_checking__min_delay_seconds_between_api_requests=3.5, cmr_checking__max_retries=3, cmr_checking__max_num_of_granules_to_select_per_batch=2000, is_just_do_all_remaining=False, highly_detailed_logging=False)
    #helper__Execute_CMR_Request_and_Update_Processing(db_name_key=db_name_key, cmr_checking__num_of_batches_to_run=500, cmr_checking__min_delay_seconds_between_api_requests=3.5, cmr_checking__max_retries=3, cmr_checking__max_num_of_granules_to_select_per_batch=2000, is_just_do_all_remaining=False, highly_detailed_logging=False)
    #helper__Execute_CMR_Request_and_Update_Processing(db_name_key=db_name_key, cmr_checking__num_of_batches_to_run=500, cmr_checking__min_delay_seconds_between_api_requests=3.5, cmr_checking__max_retries=3, cmr_checking__max_num_of_granules_to_select_per_batch=2000, is_just_do_all_remaining=False, highly_detailed_logging=False)
    #
    # Test with this one second
    #helper__Execute_CMR_Request_and_Update_Processing(db_name_key=db_name_key, cmr_checking__num_of_batches_to_run=500, cmr_checking__min_delay_seconds_between_api_requests=3.5, cmr_checking__max_retries=3, cmr_checking__max_num_of_granules_to_select_per_batch=2000, is_just_do_all_remaining=False, highly_detailed_logging=False)
    #
    # If the above tests work, then Just do them ALL! - Max Settings! 
    #helper__Execute_CMR_Request_and_Update_Processing(db_name_key=db_name_key, cmr_checking__num_of_batches_to_run=500, cmr_checking__min_delay_seconds_between_api_requests=3.5, cmr_checking__max_retries=3, cmr_checking__max_num_of_granules_to_select_per_batch=2000, is_just_do_all_remaining=True, highly_detailed_logging=False)
    #
    print(f'********************************************************************************************************')
    print(f'')
    #
    print(f'Workflow: workflow__Do_CMR_API_request_verification_for_WV03() is completed')

# # 37: "Run CMR API Request Verification for WV02",
# elif(option_selection_number == 37):
# workflow__Do_CMR_API_request_verification_for_WV02()
def workflow__Do_CMR_API_request_verification_for_WV02():
    print(f'Starting workflow__Do_CMR_API_request_verification_for_WV02()')
    #
    db_name_key = "WV02"
    print(f'')
    print(f'********************************************************************************************************')
    print(f'* Calling helper__Execute_CMR_Request_and_Update_Processing for {db_name_key}')
    # Earliest tiny test just to see the detailed logging
    #helper__Execute_CMR_Request_and_Update_Processing(db_name_key=db_name_key, cmr_checking__num_of_batches_to_run=3, cmr_checking__min_delay_seconds_between_api_requests=3.5, cmr_checking__max_retries=3, cmr_checking__max_num_of_granules_to_select_per_batch=2, is_just_do_all_remaining=False, highly_detailed_logging=True)
    #
    # Do not use this one
    #helper__Execute_CMR_Request_and_Update_Processing(db_name_key=db_name_key, cmr_checking__num_of_batches_to_run=500, cmr_checking__min_delay_seconds_between_api_requests=3.5, cmr_checking__max_retries=3, cmr_checking__max_num_of_granules_to_select_per_batch=2000, is_just_do_all_remaining=True, highly_detailed_logging=False)
    #
    # Test with this one first
    helper__Execute_CMR_Request_and_Update_Processing(db_name_key=db_name_key, cmr_checking__num_of_batches_to_run=100, cmr_checking__min_delay_seconds_between_api_requests=3.5, cmr_checking__max_retries=3, cmr_checking__max_num_of_granules_to_select_per_batch=2000, is_just_do_all_remaining=False, highly_detailed_logging=False)
    #
    # Test with this one second
    #helper__Execute_CMR_Request_and_Update_Processing(db_name_key=db_name_key, cmr_checking__num_of_batches_to_run=500, cmr_checking__min_delay_seconds_between_api_requests=3.5, cmr_checking__max_retries=3, cmr_checking__max_num_of_granules_to_select_per_batch=2000, is_just_do_all_remaining=False, highly_detailed_logging=False)
    #
    # If the above tests work, then Just do them ALL! - Max Settings! 
    #helper__Execute_CMR_Request_and_Update_Processing(db_name_key=db_name_key, cmr_checking__num_of_batches_to_run=500, cmr_checking__min_delay_seconds_between_api_requests=3.5, cmr_checking__max_retries=3, cmr_checking__max_num_of_granules_to_select_per_batch=2000, is_just_do_all_remaining=True, highly_detailed_logging=False)
    #
    print(f'********************************************************************************************************')
    print(f'')
    #
    print(f'Workflow: workflow__Do_CMR_API_request_verification_for_WV02() is completed')

# # 38: "Run CMR API Request Verification for WV01",
# elif(option_selection_number == 38):
# workflow__Do_CMR_API_request_verification_for_WV01()
def workflow__Do_CMR_API_request_verification_for_WV01():
    print(f'Starting workflow__Do_CMR_API_request_verification_for_WV01()')
    #
    db_name_key = "WV01"
    print(f'')
    print(f'********************************************************************************************************')
    print(f'* Calling helper__Execute_CMR_Request_and_Update_Processing for {db_name_key}')
    # Earliest tiny test just to see the detailed logging
    #helper__Execute_CMR_Request_and_Update_Processing(db_name_key=db_name_key, cmr_checking__num_of_batches_to_run=3, cmr_checking__min_delay_seconds_between_api_requests=3.5, cmr_checking__max_retries=3, cmr_checking__max_num_of_granules_to_select_per_batch=2, is_just_do_all_remaining=False, highly_detailed_logging=True)
    #
    # Do not use this one
    #helper__Execute_CMR_Request_and_Update_Processing(db_name_key=db_name_key, cmr_checking__num_of_batches_to_run=500, cmr_checking__min_delay_seconds_between_api_requests=3.5, cmr_checking__max_retries=3, cmr_checking__max_num_of_granules_to_select_per_batch=2000, is_just_do_all_remaining=True, highly_detailed_logging=False)
    #
    # Test with this one first
    helper__Execute_CMR_Request_and_Update_Processing(db_name_key=db_name_key, cmr_checking__num_of_batches_to_run=100, cmr_checking__min_delay_seconds_between_api_requests=3.5, cmr_checking__max_retries=3, cmr_checking__max_num_of_granules_to_select_per_batch=2000, is_just_do_all_remaining=False, highly_detailed_logging=False)
    #helper__Execute_CMR_Request_and_Update_Processing(db_name_key=db_name_key, cmr_checking__num_of_batches_to_run=500, cmr_checking__min_delay_seconds_between_api_requests=3.5, cmr_checking__max_retries=3, cmr_checking__max_num_of_granules_to_select_per_batch=2000, is_just_do_all_remaining=False, highly_detailed_logging=False)
    #
    # Test with this one second
    #helper__Execute_CMR_Request_and_Update_Processing(db_name_key=db_name_key, cmr_checking__num_of_batches_to_run=500, cmr_checking__min_delay_seconds_between_api_requests=3.5, cmr_checking__max_retries=3, cmr_checking__max_num_of_granules_to_select_per_batch=2000, is_just_do_all_remaining=False, highly_detailed_logging=False)
    #
    # If the above tests work, then Just do them ALL! - Max Settings! 
    #helper__Execute_CMR_Request_and_Update_Processing(db_name_key=db_name_key, cmr_checking__num_of_batches_to_run=500, cmr_checking__min_delay_seconds_between_api_requests=3.5, cmr_checking__max_retries=3, cmr_checking__max_num_of_granules_to_select_per_batch=2000, is_just_do_all_remaining=True, highly_detailed_logging=False)
    #
    print(f'********************************************************************************************************')
    print(f'')
    #
    print(f'Workflow: workflow__Do_CMR_API_request_verification_for_WV01() is completed')

# # 39: "Run CMR API Request Verification for GE01",
# elif(option_selection_number == 39):
# workflow__Do_CMR_API_request_verification_for_GE01()
def workflow__Do_CMR_API_request_verification_for_GE01():
    print(f'Starting workflow__Do_CMR_API_request_verification_for_GE01()')
    #
    db_name_key = "GE01"
    print(f'')
    print(f'********************************************************************************************************')
    print(f'* Calling helper__Execute_CMR_Request_and_Update_Processing for {db_name_key}')
    #helper__Execute_CMR_Request_and_Update_Processing(db_name_key=db_name_key, cmr_checking__num_of_batches_to_run=3, cmr_checking__min_delay_seconds_between_api_requests=3.5, cmr_checking__max_retries=3, cmr_checking__max_num_of_granules_to_select_per_batch=2, is_just_do_all_remaining=False, highly_detailed_logging=True)
    #helper__Execute_CMR_Request_and_Update_Processing(db_name_key=db_name_key, cmr_checking__num_of_batches_to_run=500, cmr_checking__min_delay_seconds_between_api_requests=3.5, cmr_checking__max_retries=3, cmr_checking__max_num_of_granules_to_select_per_batch=2000, is_just_do_all_remaining=False, highly_detailed_logging=False)
    
    # Test with this one first
    helper__Execute_CMR_Request_and_Update_Processing(db_name_key=db_name_key, cmr_checking__num_of_batches_to_run=100, cmr_checking__min_delay_seconds_between_api_requests=3.5, cmr_checking__max_retries=3, cmr_checking__max_num_of_granules_to_select_per_batch=2000, is_just_do_all_remaining=False, highly_detailed_logging=False)
    #helper__Execute_CMR_Request_and_Update_Processing(db_name_key=db_name_key, cmr_checking__num_of_batches_to_run=515, cmr_checking__min_delay_seconds_between_api_requests=3.5, cmr_checking__max_retries=3, cmr_checking__max_num_of_granules_to_select_per_batch=2000, is_just_do_all_remaining=False, highly_detailed_logging=False)
    #
    # Test with this one second
    #helper__Execute_CMR_Request_and_Update_Processing(db_name_key=db_name_key, cmr_checking__num_of_batches_to_run=500, cmr_checking__min_delay_seconds_between_api_requests=3.5, cmr_checking__max_retries=3, cmr_checking__max_num_of_granules_to_select_per_batch=2000, is_just_do_all_remaining=False, highly_detailed_logging=False)
    #
    # If the above tests work, then Just do them ALL! - Max Settings! 
    #helper__Execute_CMR_Request_and_Update_Processing(db_name_key=db_name_key, cmr_checking__num_of_batches_to_run=500, cmr_checking__min_delay_seconds_between_api_requests=3.5, cmr_checking__max_retries=3, cmr_checking__max_num_of_granules_to_select_per_batch=2000, is_just_do_all_remaining=True, highly_detailed_logging=False)
    #
    print(f'********************************************************************************************************')
    print(f'')
    #
    print(f'Workflow: workflow__Do_CMR_API_request_verification_for_GE01() is completed')





# # 45: "Run S3 and DynamoDB Deletes for WV04",
# elif(option_selection_number == 45):
# workflow__Do_S3_and_DynamoDB_Deletes_for_WV04()
def workflow__Do_S3_and_DynamoDB_Deletes_for_WV04():
    print(f'Starting workflow__Do_S3_and_DynamoDB_Deletes_for_WV04()')
    #
    db_name_key = "WV04"
    print(f'')
    print(f'********************************************************************************************************')
    print(f'* Calling helper__Execute_Delete_Granules_from_S3_and_DynamoDB_and_Update_Processing for {db_name_key}')
    
    # 1 batch, 1 granule per batch, 1 granule total - Detailed logging True
    #helper__Execute_Delete_Granules_from_S3_and_DynamoDB_and_Update_Processing(db_name_key=db_name_key, delivery_deletes__num_of_batches_to_run=1, delivery_deletes__max_num_of_granules_to_select_per_batch=1, max_db_chunk_size=100000, delivery_deletes__max_retries=3, is_just_do_all_remaining=False, highly_detailed_logging=True, is_delete_granules_in_batches=False, max_num_of_granules_per_delete_batch=25)
    #
    # 2 batches, 3 granule per batch, 6 granules total - Detailed logging True
    #helper__Execute_Delete_Granules_from_S3_and_DynamoDB_and_Update_Processing(db_name_key=db_name_key, delivery_deletes__num_of_batches_to_run=2, delivery_deletes__max_num_of_granules_to_select_per_batch=3, max_db_chunk_size=100000, delivery_deletes__max_retries=3, is_just_do_all_remaining=False, highly_detailed_logging=True, is_delete_granules_in_batches=True, max_num_of_granules_per_delete_batch=25)
    helper__Execute_Delete_Granules_from_S3_and_DynamoDB_and_Update_Processing(db_name_key=db_name_key, delivery_deletes__num_of_batches_to_run=2, delivery_deletes__max_num_of_granules_to_select_per_batch=47, max_db_chunk_size=100000, delivery_deletes__max_retries=3, is_just_do_all_remaining=False, highly_detailed_logging=True, is_delete_granules_in_batches=True, max_num_of_granules_per_delete_batch=25)
    #
    # Do a large number of batches and granules, and do them all! (Calculate from counts) - Detailed logging False
    #helper__Execute_Delete_Granules_from_S3_and_DynamoDB_and_Update_Processing(db_name_key=db_name_key, delivery_deletes__num_of_batches_to_run=100, delivery_deletes__max_num_of_granules_to_select_per_batch=5000, max_db_chunk_size=100000, delivery_deletes__max_retries=3, is_just_do_all_remaining=False, highly_detailed_logging=False, is_delete_granules_in_batches=True, max_num_of_granules_per_delete_batch=25)
    #helper__Execute_Delete_Granules_from_S3_and_DynamoDB_and_Update_Processing(db_name_key=db_name_key, delivery_deletes__num_of_batches_to_run=1000, delivery_deletes__max_num_of_granules_to_select_per_batch=5000, max_db_chunk_size=100000, delivery_deletes__max_retries=3, is_just_do_all_remaining=False, highly_detailed_logging=False, is_delete_granules_in_batches=True, max_num_of_granules_per_delete_batch=25)
    #
    print(f'********************************************************************************************************')
    print(f'')
    #
    print(f'Workflow: workflow__Do_S3_and_DynamoDB_Deletes_for_WV04() is completed')

# # 46: "Run S3 and DynamoDB Deletes for WV03",
# elif(option_selection_number == 46):
# workflow__Do_S3_and_DynamoDB_Deletes_for_WV03()
def workflow__Do_S3_and_DynamoDB_Deletes_for_WV03():
    print(f'Starting workflow__Do_S3_and_DynamoDB_Deletes_for_WV03()')
    #
    db_name_key = "WV03"
    print(f'')
    print(f'********************************************************************************************************')
    print(f'* Calling helper__Execute_Delete_Granules_from_S3_and_DynamoDB_and_Update_Processing for {db_name_key}')
    
    # 1 batch, 1 granule per batch, 1 granule total - Detailed logging True
    helper__Execute_Delete_Granules_from_S3_and_DynamoDB_and_Update_Processing(db_name_key=db_name_key, delivery_deletes__num_of_batches_to_run=1, delivery_deletes__max_num_of_granules_to_select_per_batch=1, max_db_chunk_size=100000, delivery_deletes__max_retries=3, is_just_do_all_remaining=False, highly_detailed_logging=True, is_delete_granules_in_batches=False, max_num_of_granules_per_delete_batch=25)
    #
    # 2 batches, 3 granule per batch, 6 granules total - Detailed logging True
    #helper__Execute_Delete_Granules_from_S3_and_DynamoDB_and_Update_Processing(db_name_key=db_name_key, delivery_deletes__num_of_batches_to_run=2, delivery_deletes__max_num_of_granules_to_select_per_batch=3, max_db_chunk_size=100000, delivery_deletes__max_retries=3, is_just_do_all_remaining=False, highly_detailed_logging=True, is_delete_granules_in_batches=True, max_num_of_granules_per_delete_batch=25)
    #
    # Do a large number of batches and granules, and do them all! (Calculate from counts) - Detailed logging False
    #helper__Execute_Delete_Granules_from_S3_and_DynamoDB_and_Update_Processing(db_name_key=db_name_key, delivery_deletes__num_of_batches_to_run=100, delivery_deletes__max_num_of_granules_to_select_per_batch=5000, max_db_chunk_size=100000, delivery_deletes__max_retries=3, is_just_do_all_remaining=False, highly_detailed_logging=False, is_delete_granules_in_batches=True, max_num_of_granules_per_delete_batch=25)
    #helper__Execute_Delete_Granules_from_S3_and_DynamoDB_and_Update_Processing(db_name_key=db_name_key, delivery_deletes__num_of_batches_to_run=1000, delivery_deletes__max_num_of_granules_to_select_per_batch=5000, max_db_chunk_size=100000, delivery_deletes__max_retries=3, is_just_do_all_remaining=False, highly_detailed_logging=False, is_delete_granules_in_batches=True, max_num_of_granules_per_delete_batch=25)
    #
    print(f'********************************************************************************************************')
    print(f'')
    #
    print(f'Workflow: workflow__Do_S3_and_DynamoDB_Deletes_for_WV03() is completed')

# # 47: "Run S3 and DynamoDB Deletes for WV02",
# elif(option_selection_number == 47):
# workflow__Do_S3_and_DynamoDB_Deletes_for_WV02()
def workflow__Do_S3_and_DynamoDB_Deletes_for_WV02():
    print(f'Starting workflow__Do_S3_and_DynamoDB_Deletes_for_WV02()')
    #
    db_name_key = "WV02"
    print(f'')
    print(f'********************************************************************************************************')
    print(f'* Calling helper__Execute_Delete_Granules_from_S3_and_DynamoDB_and_Update_Processing for {db_name_key}')
    
    # 1 batch, 1 granule per batch, 1 granule total - Detailed logging True
    helper__Execute_Delete_Granules_from_S3_and_DynamoDB_and_Update_Processing(db_name_key=db_name_key, delivery_deletes__num_of_batches_to_run=1, delivery_deletes__max_num_of_granules_to_select_per_batch=1, max_db_chunk_size=100000, delivery_deletes__max_retries=3, is_just_do_all_remaining=False, highly_detailed_logging=True, is_delete_granules_in_batches=False, max_num_of_granules_per_delete_batch=25)
    #
    # 2 batches, 3 granule per batch, 6 granules total - Detailed logging True
    #helper__Execute_Delete_Granules_from_S3_and_DynamoDB_and_Update_Processing(db_name_key=db_name_key, delivery_deletes__num_of_batches_to_run=2, delivery_deletes__max_num_of_granules_to_select_per_batch=3, max_db_chunk_size=100000, delivery_deletes__max_retries=3, is_just_do_all_remaining=False, highly_detailed_logging=True, is_delete_granules_in_batches=True, max_num_of_granules_per_delete_batch=25)
    #
    # Do a large number of batches and granules, and do them all! (Calculate from counts) - Detailed logging False
    #helper__Execute_Delete_Granules_from_S3_and_DynamoDB_and_Update_Processing(db_name_key=db_name_key, delivery_deletes__num_of_batches_to_run=100, delivery_deletes__max_num_of_granules_to_select_per_batch=5000, max_db_chunk_size=100000, delivery_deletes__max_retries=3, is_just_do_all_remaining=False, highly_detailed_logging=False, is_delete_granules_in_batches=True, max_num_of_granules_per_delete_batch=25)
    #helper__Execute_Delete_Granules_from_S3_and_DynamoDB_and_Update_Processing(db_name_key=db_name_key, delivery_deletes__num_of_batches_to_run=1000, delivery_deletes__max_num_of_granules_to_select_per_batch=5000, max_db_chunk_size=100000, delivery_deletes__max_retries=3, is_just_do_all_remaining=False, highly_detailed_logging=False, is_delete_granules_in_batches=True, max_num_of_granules_per_delete_batch=25)
    #
    print(f'********************************************************************************************************')
    print(f'')
    #
    print(f'Workflow: workflow__Do_S3_and_DynamoDB_Deletes_for_WV02() is completed')

# # 48: "Run S3 and DynamoDB Deletes for WV01",
# elif(option_selection_number == 48):
# workflow__Do_S3_and_DynamoDB_Deletes_for_WV01()
def workflow__Do_S3_and_DynamoDB_Deletes_for_WV01():
    print(f'Starting workflow__Do_S3_and_DynamoDB_Deletes_for_WV01()')
    #
    db_name_key = "WV01"
    print(f'')
    print(f'********************************************************************************************************')
    print(f'* Calling helper__Execute_Delete_Granules_from_S3_and_DynamoDB_and_Update_Processing for {db_name_key}')
    
    # 1 batch, 1 granule per batch, 1 granule total - Detailed logging True
    #helper__Execute_Delete_Granules_from_S3_and_DynamoDB_and_Update_Processing(db_name_key=db_name_key, delivery_deletes__num_of_batches_to_run=1, delivery_deletes__max_num_of_granules_to_select_per_batch=1, max_db_chunk_size=100000, delivery_deletes__max_retries=3, is_just_do_all_remaining=False, highly_detailed_logging=True, is_delete_granules_in_batches=False, max_num_of_granules_per_delete_batch=25)
    #
    # 2 batches, 3 granule per batch, 6 granules total - Detailed logging True
    helper__Execute_Delete_Granules_from_S3_and_DynamoDB_and_Update_Processing(db_name_key=db_name_key, delivery_deletes__num_of_batches_to_run=2, delivery_deletes__max_num_of_granules_to_select_per_batch=3, max_db_chunk_size=100000, delivery_deletes__max_retries=3, is_just_do_all_remaining=False, highly_detailed_logging=True, is_delete_granules_in_batches=True, max_num_of_granules_per_delete_batch=25)
    #
    # Do a large number of batches and granules, and do them all! (Calculate from counts) - Detailed logging False
    #helper__Execute_Delete_Granules_from_S3_and_DynamoDB_and_Update_Processing(db_name_key=db_name_key, delivery_deletes__num_of_batches_to_run=100, delivery_deletes__max_num_of_granules_to_select_per_batch=5000, max_db_chunk_size=100000, delivery_deletes__max_retries=3, is_just_do_all_remaining=False, highly_detailed_logging=False, is_delete_granules_in_batches=True, max_num_of_granules_per_delete_batch=25)
    #helper__Execute_Delete_Granules_from_S3_and_DynamoDB_and_Update_Processing(db_name_key=db_name_key, delivery_deletes__num_of_batches_to_run=1000, delivery_deletes__max_num_of_granules_to_select_per_batch=5000, max_db_chunk_size=100000, delivery_deletes__max_retries=3, is_just_do_all_remaining=False, highly_detailed_logging=False, is_delete_granules_in_batches=True, max_num_of_granules_per_delete_batch=25)
    #
    print(f'********************************************************************************************************')
    print(f'')
    #
    print(f'Workflow: workflow__Do_S3_and_DynamoDB_Deletes_for_WV01() is completed')

# # 49: "Run S3 and DynamoDB Deletes for GE01",
# elif(option_selection_number == 49):
# workflow__Do_S3_and_DynamoDB_Deletes_for_GE01()
def workflow__Do_S3_and_DynamoDB_Deletes_for_GE01():
    print(f'Starting workflow__Do_S3_and_DynamoDB_Deletes_for_GE01()')
    #
    db_name_key = "GE01"
    print(f'')
    print(f'********************************************************************************************************')
    print(f'* Calling helper__Execute_Delete_Granules_from_S3_and_DynamoDB_and_Update_Processing for {db_name_key}')
    
    # 1 batch, 1 granule per batch, 1 granule total - Detailed logging True
    helper__Execute_Delete_Granules_from_S3_and_DynamoDB_and_Update_Processing(db_name_key=db_name_key, delivery_deletes__num_of_batches_to_run=1, delivery_deletes__max_num_of_granules_to_select_per_batch=1, max_db_chunk_size=100000, delivery_deletes__max_retries=3, is_just_do_all_remaining=False, highly_detailed_logging=True, is_delete_granules_in_batches=False, max_num_of_granules_per_delete_batch=25)
    #
    # 2 batches, 3 granule per batch, 6 granules total - Detailed logging True
    #helper__Execute_Delete_Granules_from_S3_and_DynamoDB_and_Update_Processing(db_name_key=db_name_key, delivery_deletes__num_of_batches_to_run=2, delivery_deletes__max_num_of_granules_to_select_per_batch=3, max_db_chunk_size=100000, delivery_deletes__max_retries=3, is_just_do_all_remaining=False, highly_detailed_logging=True, is_delete_granules_in_batches=True, max_num_of_granules_per_delete_batch=25)
    #
    # Do a large number of batches and granules, and do them all! (Calculate from counts) - Detailed logging False
    #helper__Execute_Delete_Granules_from_S3_and_DynamoDB_and_Update_Processing(db_name_key=db_name_key, delivery_deletes__num_of_batches_to_run=100, delivery_deletes__max_num_of_granules_to_select_per_batch=5000, max_db_chunk_size=100000, delivery_deletes__max_retries=3, is_just_do_all_remaining=False, highly_detailed_logging=False, is_delete_granules_in_batches=True, max_num_of_granules_per_delete_batch=25)
    #helper__Execute_Delete_Granules_from_S3_and_DynamoDB_and_Update_Processing(db_name_key=db_name_key, delivery_deletes__num_of_batches_to_run=1000, delivery_deletes__max_num_of_granules_to_select_per_batch=5000, max_db_chunk_size=100000, delivery_deletes__max_retries=3, is_just_do_all_remaining=False, highly_detailed_logging=False, is_delete_granules_in_batches=True, max_num_of_granules_per_delete_batch=25)
    #
    print(f'********************************************************************************************************')
    print(f'')
    #
    print(f'Workflow: workflow__Do_S3_and_DynamoDB_Deletes_for_GE01() is completed')




# This is the Function that pipes the code to Select the local DB granules, make a CMR API request with those granules, and then parse the results, and then Update the Local DB.  3 Update Paths exist (1) Local Granules Found in CMR, (2) Local Granules NOT Found in CMR, (3) New Granules that are not in the local DB but were found in CMR (that last set gets added to the DB).
# # Specifically, this function runs small batches for ALL existing Datasets and outputs more info than the actual functions that do the work.
# IMPORTANT: Ensure Detailed Logging gets passed in to the operator functions.
# 85, this is the test function for numbers 35, 36, 37, 38, 39
#
# 85: "Test Run CMR API Request Verification for All Types - Small Batch of data",
# elif(option_selection_number == 85):
# workflow__test_run_CMR_API_request_verification_for_all_types__small_batch_of_data()
# helper__Execute_CMR_Request_and_Update_Processing(params)
def workflow__test_run_CMR_API_request_verification_for_all_types__small_batch_of_data():
    print(f'Starting workflow__test_run_CMR_API_request_verification_for_all_types__small_batch_of_data()')
    #
    # Testing Area
    # # Usage Example: Small Test Run for WV01 - With Highly Detailed Logging
    print(f'')
    print(f'********************************************************************************************************')
    print(f'Calling helper__Execute_CMR_Request_and_Update_Processing for small test use case, WV04')
    helper__Execute_CMR_Request_and_Update_Processing(db_name_key="WV04", cmr_checking__num_of_batches_to_run=3, cmr_checking__min_delay_seconds_between_api_requests=3.5, cmr_checking__max_retries=3, cmr_checking__max_num_of_granules_to_select_per_batch=2, is_just_do_all_remaining=False, highly_detailed_logging=True)
    print(f'********************************************************************************************************')
    print(f'')
    print(f'********************************************************************************************************')
    print(f'Calling helper__Execute_CMR_Request_and_Update_Processing for small test use case, WV03')
    helper__Execute_CMR_Request_and_Update_Processing(db_name_key="WV03", cmr_checking__num_of_batches_to_run=3, cmr_checking__min_delay_seconds_between_api_requests=3.5, cmr_checking__max_retries=3, cmr_checking__max_num_of_granules_to_select_per_batch=2, is_just_do_all_remaining=False, highly_detailed_logging=True)
    print(f'********************************************************************************************************')
    print(f'')
    print(f'********************************************************************************************************')
    print(f'Calling helper__Execute_CMR_Request_and_Update_Processing for small test use case, WV02')
    helper__Execute_CMR_Request_and_Update_Processing(db_name_key="WV02", cmr_checking__num_of_batches_to_run=3, cmr_checking__min_delay_seconds_between_api_requests=3.5, cmr_checking__max_retries=3, cmr_checking__max_num_of_granules_to_select_per_batch=2, is_just_do_all_remaining=False, highly_detailed_logging=True)
    print(f'********************************************************************************************************')
    print(f'')
    print(f'********************************************************************************************************')
    print(f'Calling helper__Execute_CMR_Request_and_Update_Processing for small test use case, WV01')
    helper__Execute_CMR_Request_and_Update_Processing(db_name_key="WV01", cmr_checking__num_of_batches_to_run=3, cmr_checking__min_delay_seconds_between_api_requests=3.5, cmr_checking__max_retries=3, cmr_checking__max_num_of_granules_to_select_per_batch=2, is_just_do_all_remaining=False, highly_detailed_logging=True)
    print(f'********************************************************************************************************')
    print(f'')
    print(f'********************************************************************************************************')
    print(f'Calling helper__Execute_CMR_Request_and_Update_Processing for small test use case, GE01')
    helper__Execute_CMR_Request_and_Update_Processing(db_name_key="GE01", cmr_checking__num_of_batches_to_run=3, cmr_checking__min_delay_seconds_between_api_requests=3.5, cmr_checking__max_retries=3, cmr_checking__max_num_of_granules_to_select_per_batch=2, is_just_do_all_remaining=False, highly_detailed_logging=True)
    print(f'********************************************************************************************************')
    print(f'')
    #print(f'Calling helper__Execute_CMR_Request_and_Update_Processing for All remaining granules use case, WV01')
    ## # Usage Example: Fastest and largest Chunks Run for WV01 (2000 granules per batch, Batches are calculated)
    #helper__Execute_CMR_Request_and_Update_Processing(db_name_key="WV01", cmr_checking__num_of_batches_to_run=100, cmr_checking__min_delay_seconds_between_api_requests=2.5, cmr_checking__max_retries=3, cmr_checking__max_num_of_granules_to_select_per_batch=2000, is_just_do_all_remaining=True, highly_detailed_logging=False)
    print(f'')

    #
    print(f'Workflow: workflow__test_run_CMR_API_request_verification_for_all_types__small_batch_of_data() is completed')


# # 86: "Output All Counts for Remaining CMR Granules to check from All DBs",
# elif(option_selection_number == 86):
# workflow__Output_All_Counts_For_Remaining_CMR_Granules_To_Check_from_All_DBs()
def workflow__Output_All_Counts_For_Remaining_CMR_Granules_To_Check_from_All_DBs():
    print(f'Starting workflow__Output_All_Counts_For_Remaining_CMR_Granules_To_Check_from_All_DBs()')
    #
    cmr_checking__max_retries = 3
    print(f'  Using {cmr_checking__max_retries} for cmr_checking__max_retries')
    total_remaining_count__WV04 = DatabaseManager.get_remaining_granule_count__for_cmr_API_call(db_name_key="WV04", max_retries=cmr_checking__max_retries)
    total_remaining_count__WV03 = DatabaseManager.get_remaining_granule_count__for_cmr_API_call(db_name_key="WV03", max_retries=cmr_checking__max_retries)
    total_remaining_count__WV02 = DatabaseManager.get_remaining_granule_count__for_cmr_API_call(db_name_key="WV02", max_retries=cmr_checking__max_retries)
    total_remaining_count__WV01 = DatabaseManager.get_remaining_granule_count__for_cmr_API_call(db_name_key="WV01", max_retries=cmr_checking__max_retries)
    total_remaining_count__GE01 = DatabaseManager.get_remaining_granule_count__for_cmr_API_call(db_name_key="GE01", max_retries=cmr_checking__max_retries)
    print(f'')
    print(f'  Total Remaining CMR Granules to Check Counts:')
    print(f'    total_remaining_count__WV04: {total_remaining_count__WV04}')
    print(f'    total_remaining_count__WV03: {total_remaining_count__WV03}')
    print(f'    total_remaining_count__WV02: {total_remaining_count__WV02}')
    print(f'    total_remaining_count__WV01: {total_remaining_count__WV01}')
    print(f'    total_remaining_count__GE01: {total_remaining_count__GE01}')
    print(f'')
    #
    print(f'Workflow: workflow__Output_All_Counts_For_Remaining_CMR_Granules_To_Check_from_All_DBs() is completed')



# 95: "Test S3 and DynamoDB Deletes for All Types - Small Batch of data",
# elif(option_selection_number == 95):
# workflow__test_run_S3_and_DynamoDB_Deletes_for_all_types__small_batch_of_data()
def workflow__test_run_S3_and_DynamoDB_Deletes_for_all_types__small_batch_of_data():
    print(f'Starting workflow__test_run_S3_and_DynamoDB_Deletes_for_all_types__small_batch_of_data()')
    #

    # Testing Area
    print(f'')
    print(f'********************************************************************************************************')
    print(f'Calling helper__Execute_Delete_Granules_from_S3_and_DynamoDB_and_Update_Processing for small test use case, WV04')
    helper__Execute_Delete_Granules_from_S3_and_DynamoDB_and_Update_Processing(db_name_key="WV04", delivery_deletes__num_of_batches_to_run=3, delivery_deletes__max_num_of_granules_to_select_per_batch=5, max_db_chunk_size=100000, delivery_deletes__max_retries=3, is_just_do_all_remaining=False, highly_detailed_logging=True)
    print(f'********************************************************************************************************')
    print(f'')
    print(f'********************************************************************************************************')
    print(f'Calling helper__Execute_Delete_Granules_from_S3_and_DynamoDB_and_Update_Processing for small test use case, WV03')
    helper__Execute_Delete_Granules_from_S3_and_DynamoDB_and_Update_Processing(db_name_key="WV03", delivery_deletes__num_of_batches_to_run=3, delivery_deletes__max_num_of_granules_to_select_per_batch=5, max_db_chunk_size=100000, delivery_deletes__max_retries=3, is_just_do_all_remaining=False, highly_detailed_logging=True)
    print(f'********************************************************************************************************')
    print(f'')
    print(f'********************************************************************************************************')
    print(f'Calling helper__Execute_Delete_Granules_from_S3_and_DynamoDB_and_Update_Processing for small test use case, WV02')
    helper__Execute_Delete_Granules_from_S3_and_DynamoDB_and_Update_Processing(db_name_key="WV02", delivery_deletes__num_of_batches_to_run=3, delivery_deletes__max_num_of_granules_to_select_per_batch=5, max_db_chunk_size=100000, delivery_deletes__max_retries=3, is_just_do_all_remaining=False, highly_detailed_logging=True)
    print(f'********************************************************************************************************')
    print(f'')
    print(f'********************************************************************************************************')
    print(f'Calling helper__Execute_Delete_Granules_from_S3_and_DynamoDB_and_Update_Processing for small test use case, WV01')
    helper__Execute_Delete_Granules_from_S3_and_DynamoDB_and_Update_Processing(db_name_key="WV01", delivery_deletes__num_of_batches_to_run=3, delivery_deletes__max_num_of_granules_to_select_per_batch=5, max_db_chunk_size=100000, delivery_deletes__max_retries=3, is_just_do_all_remaining=False, highly_detailed_logging=True)
    print(f'********************************************************************************************************')
    print(f'')
    print(f'********************************************************************************************************')
    print(f'Calling helper__Execute_Delete_Granules_from_S3_and_DynamoDB_and_Update_Processing for small test use case, GE01')
    helper__Execute_Delete_Granules_from_S3_and_DynamoDB_and_Update_Processing(db_name_key="GE01", delivery_deletes__num_of_batches_to_run=3, delivery_deletes__max_num_of_granules_to_select_per_batch=5, max_db_chunk_size=100000, delivery_deletes__max_retries=3, is_just_do_all_remaining=False, highly_detailed_logging=True)
    print(f'********************************************************************************************************')
    print(f'')

    #
    print(f'Workflow: workflow__test_run_S3_and_DynamoDB_Deletes_for_all_types__small_batch_of_data() is completed')


# # 96: "Output All Counts for Remaining S3 and DynamoDB Granule Deletes to try from All DBs",
# elif(option_selection_number == 96):
# workflow__Output_All_Counts_For_Remaining_S3_and_DynamoDB_Granule_Deletes_To_Try_from_All_DBs()
def workflow__Output_All_Counts_For_Remaining_S3_and_DynamoDB_Granule_Deletes_To_Try_from_All_DBs():
    print(f'Starting workflow__Output_All_Counts_For_Remaining_S3_and_DynamoDB_Granule_Deletes_To_Try_from_All_DBs()')
    #
    delivery_deletes__max_retries = 3
    print(f'  Using {delivery_deletes__max_retries} for delivery_deletes__max_retries')
    total_remaining_count__WV04 = DatabaseManager.get_count__Granules_Ready_For_Delete(db_name_key="WV04", max_retries=delivery_deletes__max_retries)
    total_remaining_count__WV03 = DatabaseManager.get_count__Granules_Ready_For_Delete(db_name_key="WV03", max_retries=delivery_deletes__max_retries)
    total_remaining_count__WV02 = DatabaseManager.get_count__Granules_Ready_For_Delete(db_name_key="WV02", max_retries=delivery_deletes__max_retries)
    total_remaining_count__WV01 = DatabaseManager.get_count__Granules_Ready_For_Delete(db_name_key="WV01", max_retries=delivery_deletes__max_retries)
    total_remaining_count__GE01 = DatabaseManager.get_count__Granules_Ready_For_Delete(db_name_key="GE01", max_retries=delivery_deletes__max_retries)
    print(f'')
    print(f'  Total Remaining Granules Ready for Delete Counts:')
    print(f'    total_remaining_count__WV04: {total_remaining_count__WV04}')
    print(f'    total_remaining_count__WV03: {total_remaining_count__WV03}')
    print(f'    total_remaining_count__WV02: {total_remaining_count__WV02}')
    print(f'    total_remaining_count__WV01: {total_remaining_count__WV01}')
    print(f'    total_remaining_count__GE01: {total_remaining_count__GE01}')
    print(f'')
    #
    print(f'Workflow: workflow__Output_All_Counts_For_Remaining_S3_and_DynamoDB_Granule_Deletes_To_Try_from_All_DBs() is completed')



def workflow__create_local_sqlite_tables():
    print(f'Starting workflow__create_local_sqlite_tables()')
    
    # The granule table and list of columns is defined inside the SQLite wrapper!
    DatabaseManager.initialize_databases()


# 61: "Create a snapshot backup of Code and SQLite DBs",
# elif(option_selection_number == 61):
#     workflow__create_snapshot_backup_of_code_and_sqlite_DBs()
def workflow__create_snapshot_backup_of_code_and_sqlite_DBs():
    print(f'Starting workflow__create_snapshot_backup_of_code_and_sqlite_DBs()')
    #
    # Backup the Source code and the Databases to a snapshot
    BackupSystem.backup_code_and_databases()
    #
    print(f'Workflow: workflow__create_snapshot_backup_of_code_and_sqlite_DBs() is completed')


# 62: "Create a snapshot backup of just the Code",
# elif(option_selection_number == 62):
#     workflow__create_snapshot_backup_of_code_only()
def workflow__create_snapshot_backup_of_code_only():
    print(f'Starting workflow__create_snapshot_backup_of_code_only()')
    #
    # Backup ONLY the Source code to a snapshot
    BackupSystem.backup_code()
    #
    print(f'Workflow: workflow__create_snapshot_backup_of_code_only() is completed')


# 63: "Create a snapshot backup of just the DBs",
# elif(option_selection_number == 63):
#     workflow__create_snapshot_backup_of_sqlite_DBs_only()
def workflow__create_snapshot_backup_of_sqlite_DBs_only():
    print(f'Starting workflow__create_snapshot_backup_of_sqlite_DBs_only()')
    #
    # Backup ONLY the Source code to a snapshot
    BackupSystem.backup_databases()
    #
    print(f'Workflow: workflow__create_snapshot_backup_of_sqlite_DBs_only() is completed')




def workflow__test_sqlite_granule_table():
    print(f'Starting workflow__test_sqlite_granule_table()')

    # num_of_rows_affected = DatabaseManager.update_string_granule_field_by_granule_id(db_name_key="WV04", granule_id="abcdefg_1234567", column_name=DynamoDB_Key__file_path,            new_value="DynamoDB primary key value here")
    db_name_key = "DEFAULT" # "WV04"
    new_granule_id = "abcdefg_1234567"

    # Create Databases if they have not already been created.
    workflow__create_local_sqlite_tables()

    # Insert a new granule
    #DatabaseManager.add_new_granule(db_name_key="DEFAULT", granule_id="default_granule_id")
    DatabaseManager.add_new_granule(db_name_key=db_name_key, granule_id=new_granule_id)

    # Output the State of the Default DB - Again
    print(f'')
    print(f'BEFORE modifying the initial granule (but after inserting it:')
    print(f'')
    #
    DatabaseManager.test__output_6_rows_of_DB_Contents_by_DB_Name(db_name_key="DEFAULT")

    # Update Usage Instructions
    # To Update String type Rows
    num_of_rows_affected = DatabaseManager.update_string_granule_field_by_granule_id(db_name_key="DEFAULT", granule_id=new_granule_id, column_name="DynamoDB_Key__file_path",            new_value="The DynamoDB primary key value here")
    num_of_rows_affected = DatabaseManager.update_string_granule_field_by_granule_id(db_name_key="DEFAULT", granule_id=new_granule_id, column_name="DynamoDB_Contents",                  new_value="The DynamoDB json string contents")
    num_of_rows_affected = DatabaseManager.update_string_granule_field_by_granule_id(db_name_key="DEFAULT", granule_id=new_granule_id, column_name="MCP_Rep_Granule_KeyPath",            new_value="The MCP key path here")
    num_of_rows_affected = DatabaseManager.update_string_granule_field_by_granule_id(db_name_key="DEFAULT", granule_id=new_granule_id, column_name="NGAP_CBA_PROD_Rep_Granule_KeyPath",  new_value="The NGAP CBA PROD key path here")
    #
    # To Update DateTime type flag rows here.
    num_of_rows_affected = DatabaseManager.update_datetime_granule_field_by_granule_id(db_name_key="DEFAULT", granule_id=new_granule_id, column_name="is_in_NGAP_PROD")
    num_of_rows_affected = DatabaseManager.update_datetime_granule_field_by_granule_id(db_name_key="DEFAULT", granule_id=new_granule_id, column_name="is_in_NGAP_DR_PROD")
    num_of_rows_affected = DatabaseManager.update_datetime_granule_field_by_granule_id(db_name_key="DEFAULT", granule_id=new_granule_id, column_name="is_found_at_EarthData_PROD")
    num_of_rows_affected = DatabaseManager.update_datetime_granule_field_by_granule_id(db_name_key="DEFAULT", granule_id=new_granule_id, column_name="is_in_metrics_PROD")
    #
    num_of_rows_affected = DatabaseManager.update_datetime_granule_field_by_granule_id(db_name_key="DEFAULT", granule_id=new_granule_id, column_name="is_deleted_from_MCP_delivery")
    num_of_rows_affected = DatabaseManager.update_datetime_granule_field_by_granule_id(db_name_key="DEFAULT", granule_id=new_granule_id, column_name="is_deleted_from_MCP_dynamoDB")

    # Output the State of the Default DB - Again
    print(f'')
    print(f'AFTER modifying the initial granule:')
    print(f'')
    #
    DatabaseManager.test__output_6_rows_of_DB_Contents_by_DB_Name(db_name_key="DEFAULT")

def workflow__test_get_small_dynamoDB_samples():
    print(f'Starting workflow__test_get_small_dynamoDB_samples()')
    utils.test_get_sample_dynamoDB_Data(dynamodb_table_name='WV04<dynamodb_table_name>')

def workflow__test_get_small_dynamoDB_samples_AS_JSON():
    print(f'Starting workflow__test_get_small_dynamoDB_samples_AS_JSON()')
    items = utils.test_get_sample_dynamoDB_Data_AS_JSON(dynamodb_table_name='WV04<dynamodb_table_name>')
    print(f'Items returned with lenght: len(items): {len(items)}')


def workflow__test_convert_a_few_dynamoDB_rows_into_SQLite_DB_Rows():
    print(f'Starting workflow__test_convert_a_few_dynamoDB_rows_into_SQLite_DB_Rows()')

    # Settings Needed
    dynamoDB_Table_Name = 'WV04<dynamodb_table_name>'
    SQLiteDB_name_key   = 'WV04'

    # Grab Data from Specified Table (WV04<dynamodb_table_name>), Scan for first few rows ()
    dynamo_db_items = utils.test_get_sample_dynamoDB_Data_AS_JSON(dynamodb_table_name='WV04<dynamodb_table_name>')

    # Iterate the DynamoDB Rows and convert them into new SQLite Rows.
    for dynamo_db_item in dynamo_db_items:
        pass
        # The file_path
        dynamo_db_item__file_path = dynamo_db_item.get('file_path', '')
        
        # Entire contents of the DynamoDB Row
        # We are really just preserving this info in case it is needed later..
        #dynamo_db_item__JSON_STRING = json.dumps(dynamo_db_item)  # Stringifying some JSON
        dynamo_db_item__JSON_STRING = json.dumps(dynamo_db_item, cls= utils.DecimalEncoder)  # Stringifying some JSON -- But the numbers need some help being formatted.
        

        # Get the Granule ID by doing the string conversion (try/catch)
        granule_id = utils.get_granule_id__from__dynamodb_file_path_field_value(dynamodb_file_path_field_value=dynamo_db_item__file_path)

        # Insert a new Granule: Create SQLiteDB Record for this row (check validation - must have an actual row of data)
        print(f'Test: About to write new granule from DynamoDB Data {dynamoDB_Table_Name}, to SQLite Table: {SQLiteDB_name_key} ')
        print(f'  New Data: SQLiteDB_name_key: {SQLiteDB_name_key}: granule_id: {granule_id}')

        # Important Note, it would be more efficient to do this in a single database transaction (instead of 3) -- doing it like this in this spot to ensure each step all works correctly.
        DatabaseManager.add_new_granule(db_name_key=SQLiteDB_name_key, granule_id=granule_id)
        print(f'  New Row Created.  ')
        print(f'  Now about to update 2 columns of that new SQLite row with the contents from DymamoDB Row')
        print(f'    Column: DynamoDB_Key__file_path with value dynamo_db_item__file_path:   {dynamo_db_item__file_path}')
        print(f'    Column: DynamoDB_Contents       with value dynamo_db_item__JSON_STRING: {dynamo_db_item__JSON_STRING}')

        # Update the new SQLiteDB record to include the DynamoDB contents
        num_of_rows_affected = DatabaseManager.update_string_granule_field_by_granule_id(db_name_key=SQLiteDB_name_key, granule_id=granule_id, column_name="DynamoDB_Key__file_path",            new_value=dynamo_db_item__file_path)
        num_of_rows_affected = DatabaseManager.update_string_granule_field_by_granule_id(db_name_key=SQLiteDB_name_key, granule_id=granule_id, column_name="DynamoDB_Contents",                  new_value=dynamo_db_item__JSON_STRING)

    # Output the first few rows of the WV04 SQLite Table -- Note: After running the above lines for the first time, we should have some new data in the SQlite Table that matches what is in DynamoDB
    print(f'')
    print(f'Completed adding new rows test.  Now it is time to verify the SQLite DB output for: {SQLiteDB_name_key}')
    DatabaseManager.test__output_6_rows_of_DB_Contents_by_DB_Name(db_name_key=SQLiteDB_name_key)
    print(f'')

    print(f'')
    print(f'Now viewing data in a more expanded form (so we can see more detail)')
    DatabaseManager.test__output_6_rows_of_DB_Contents_by_DB_Name__ShowAllContents(db_name_key=SQLiteDB_name_key)
    print(f'')

    pass

def workflow__test_view_local_SQLite_WV04_top_few_rows():
    print(f'Starting workflow__test_view_local_SQLite_WV04_top_few_rows()')
    SQLiteDB_name_key = "WV04"
    DatabaseManager.test__output_6_rows_of_DB_Contents_by_DB_Name(db_name_key=SQLiteDB_name_key)
    print(f'')


# 81: "Test Various Manifest Processing Helper Functions",
# elif(option_selection_number == 81):
#     workflow__test_various_manifest_processing_helper_functions()
def workflow__test_various_manifest_processing_helper_functions():
    print(f'Starting workflow__test_various_manifest_processing_helper_functions()')

    print(f'')
    print(f'  Test - Creating a new run directory.')
    new_run_sub_dir_name, new_run__sub_dir_path = ManifestProcessing.create_new_run_directory()
    print(f'    New Run dir: {new_run_sub_dir_name}')

    print(f'')
    print(f'  Test - Getting the latest run directory without knowing it\'s name (so you can resume processing easier)')
    is_found_subdir, most_recent_run_directory_path = ManifestProcessing.get_most_recent_run_directory_path()
    print(f'    is_found_subdir:                {is_found_subdir}')
    print(f'    most_recent_run_directory_path: {most_recent_run_directory_path}')
    print(f'')

    #print(f'  Test - Removing all run directories:  Cleaning up, deleting all subdirectories in the manifest processing area')
    #ManifestProcessing.delete_temp_manifest_processing_files()

    print(f'  Test - Get (or create) the run to cotinue (or start) without knowing the run id')
    current_run_dir_path = ManifestProcessing.continue_existing__or__start_new_run()
    print(f'    current_run_dir_path: {current_run_dir_path}')
    print(f'')


# # # Time Example code
# # Put this at the begining of any of these processes
# # # Total Time Tracking - Start Time
# time__total__start = time.time()
# #
# # # DO THINGS
# #
# # Total Time Tracking - End Time
# time__total__end = time.time()
# #
# # Raw Seconds
# time__total__elapsed = time__total__end - time__total__start  
# #
# # Converting raw seconds into Days, Hours, Minutes, and Seconds
# time_delta = timedelta(seconds=time__total__elapsed)
# # Format the time_delta cleanly into a human-readable single line
# days = time_delta.days
# hours, remainder = divmod(time_delta.seconds, 3600)
# minutes, seconds = divmod(remainder, 60)
# #
# # Output the Time Elapsed
# print(f'')
# print(f'  Total Elapsed Time for this run: {time__total__elapsed:.2f} total Seconds ')
# print(f'    Human Readable Total Duration: {days} Days, {hours} Hours, {minutes} Minutes, {seconds} Seconds')

# Other Reporting and Diagnnostics
#
# Helper Function for displaying Granule Data (I may already have this in the SQLite Wrapper class.)
#
# #121: "Output Number of CMR Unresolved Granules for All DBs"            # Hint (These granules likely need ingestion or reingestion) # Granules that failed CMR check including retries (new SQL needed)
# elif(option_selection_number == 121):
#   workflow__Output_Num_of_CMR_Unresolved_Granules_for__All_DBs()
def workflow__Output_Num_of_CMR_Unresolved_Granules_for__All_DBs():
    print(f'Starting workflow__Output_Num_of_CMR_Unresolved_Granules_for__All_DBs()')
    #
    #
    cmr_checking__max_retries = 3
    print(f'  Using {cmr_checking__max_retries} for cmr_checking__max_retries')
    print(f'    These queries may many minutes to process depending on how large the databases are.')
    print(f'')
    print(f'  Total CMR Unresolved Granules to Check Counts:')
    print(f'    Hint (These granules likely need ingestion or reingestion) # Granules that failed CMR check including retries.')
    print(f'')
    sys.stdout.flush()
    #
    db_keys = ['WV04', 'WV03', 'WV02', 'WV01', 'GE01']
    for db_key in db_keys:
        time__q__start = time.time()
        total_remaining_count = DatabaseManager.get_remaining_granule_count__for_cmr_API_call(db_name_key=db_key, max_retries=cmr_checking__max_retries)
        time__q__end = time.time()
        #
        # Raw Seconds
        time__total__elapsed = time__q__end - time__q__start
        #
        # Converting raw seconds into Days, Hours, Minutes, and Seconds
        time_delta = timedelta(seconds=time__total__elapsed)
        # Format the time_delta cleanly into a human-readable single line
        days = time_delta.days
        hours, remainder = divmod(time_delta.seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        #
        print(f'    Num_of_CMR_Unresolved_Granules {db_key}: {total_remaining_count}      | Query Time: Total Duration: {days} Days, {hours} Hours, {minutes} Minutes, {seconds} Seconds')
        sys.stdout.flush()
    print(f'')
    #
    # # Hard Coded version (the loop above just does each of these and outputs as it goes.  This is so I don't have to wait on all of them to finish at once before seeing the output)
    # total_remaining_count__WV04 = DatabaseManager.get_remaining_granule_count__for_cmr_API_call(db_name_key="WV04", max_retries=cmr_checking__max_retries)
    # total_remaining_count__WV03 = DatabaseManager.get_remaining_granule_count__for_cmr_API_call(db_name_key="WV03", max_retries=cmr_checking__max_retries)
    # total_remaining_count__WV02 = DatabaseManager.get_remaining_granule_count__for_cmr_API_call(db_name_key="WV02", max_retries=cmr_checking__max_retries)
    # total_remaining_count__WV01 = DatabaseManager.get_remaining_granule_count__for_cmr_API_call(db_name_key="WV01", max_retries=cmr_checking__max_retries)
    # total_remaining_count__GE01 = DatabaseManager.get_remaining_granule_count__for_cmr_API_call(db_name_key="GE01", max_retries=cmr_checking__max_retries)
    # print(f'')
    # print(f'  Total Remaining CMR Granules to Check Counts:')
    # print(f'    Num_of_CMR_Unresolved_Granules WV04: {total_remaining_count__WV04}')
    # print(f'    Num_of_CMR_Unresolved_Granules WV03: {total_remaining_count__WV03}')
    # print(f'    Num_of_CMR_Unresolved_Granules WV02: {total_remaining_count__WV02}')
    # print(f'    Num_of_CMR_Unresolved_Granules WV01: {total_remaining_count__WV01}')
    # print(f'    Num_of_CMR_Unresolved_Granules GE01: {total_remaining_count__GE01}')
    # print(f'')
    #
    #
    print(f'Workflow: workflow__Output_Num_of_CMR_Unresolved_Granules_for__All_DBs() is completed')

# #122: "Output Sample of CMR Unresolved Granules for All DBs"
# elif(option_selection_number == 122):
#   workflow__Output_Sample_of_CMR_Unresolved_Granules_for__All_DBs()
def workflow__Output_Sample_of_CMR_Unresolved_Granules_for__All_DBs():
    print(f'Starting workflow__Output_Sample_of_CMR_Unresolved_Granules_for__All_DBs()')
    #
    #
    num_of_granules_to_select = 3
    cmr_checking__max_retries = 3
    print(f'  Using {cmr_checking__max_retries} for cmr_checking__max_retries')
    print(f'  These queries may many minutes to process depending on how large the databases are.')
    print(f'')
    print(f'  Sample of {num_of_granules_to_select} Granules from each database That were not yet found in CMR:')
    print(f'    Hint (These granules likely need ingestion or reingestion) # Granules that failed CMR check including retries.')
    print(f'')
    sys.stdout.flush()
    #
    db_keys = ['WV04', 'WV03', 'WV02', 'WV01', 'GE01']
    for db_key in db_keys:
        time__q__start = time.time()
        granule_samples = DatabaseManager.get_granules_for_cmr_API_call(db_name_key=db_key, max_num_of_granules=num_of_granules_to_select, max_retries=cmr_checking__max_retries)
        time__q__end = time.time()
        #
        # Raw Seconds
        time__total__elapsed = time__q__end - time__q__start
        #
        # Converting raw seconds into Days, Hours, Minutes, and Seconds
        time_delta = timedelta(seconds=time__total__elapsed)
        # Format the time_delta cleanly into a human-readable single line
        days = time_delta.days
        hours, remainder = divmod(time_delta.seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        #
        if(granule_samples is None):
            granule_samples = []
        len__granule_samples = len(granule_samples)
        print(f'    ====================================================================================================')
        print(f'    Sample of_Granules_That_Were_NOT_Found_in_CMR {db_key}: {len__granule_samples}      | Query Time: Total Duration: {days} Days, {hours} Hours, {minutes} Minutes, {seconds} Seconds')
        if(len__granule_samples != 0):
            print(f'')
        for granule_sample in granule_samples:
            print(f'    Just the ID of each:')
            print(f'      Granule ID: {granule_sample.granule_id}')
        if(len__granule_samples != 0):
            print(f'')
            print(f'    Detail for Each:')
        for granule_sample in granule_samples:
            #granule_sample_detail_str = granule_sample.to_string()
            print(f'      Granule ID: {granule_sample.granule_id}')
            print(f'        Obj: {granule_sample}')
        if(len__granule_samples == 0):
            print(f'      ---- No Granules to display ----')
        print(f'    ====================================================================================================')
        print(f'')
        sys.stdout.flush()
    print(f'')
    #
    #
    print(f'Workflow: workflow__Output_Sample_of_CMR_Unresolved_Granules_for__All_DBs() is completed')

# #123: "Output Number of Granules Found in CMR All DBs"                  # Hint (This INCLUDES Granules that have been deleted - it is a blind CMR Check Query) # Granules that Succeeded CMR check including any other value from any other column in the DB (new SQL needed)
# elif(option_selection_number == 123):
#   workflow__Output_Num_of_Granules_Found_in_CMR_for__All_DBs()
def workflow__Output_Num_of_Granules_Found_in_CMR_for__All_DBs():
    print(f'Starting workflow__Output_Num_of_Granules_Found_in_CMR_for__All_DBs()')
    #
    #
    cmr_checking__max_retries = 3
    #print(f'  Using {cmr_checking__max_retries} for cmr_checking__max_retries')
    print(f'  These queries may many minutes to process depending on how large the databases are.')
    print(f'')
    print(f'  Total Granules Found in CMR Counts:')
    print(f'    Hint (This INCLUDES Granules that have been deleted - it is a blind CMR Check Query) # Granules that Succeeded CMR check including any other value from any other column in the DB (new SQL needed)')
    print(f'')
    sys.stdout.flush()
    #
    db_keys = ['WV04', 'WV03', 'WV02', 'WV01', 'GE01']
    for db_key in db_keys:
        time__q__start = time.time()
        total_remaining_count = DatabaseManager.get_granule_count__for_found_in_CMR(db_name_key=db_key)
        time__q__end = time.time()
        #
        # Raw Seconds
        time__total__elapsed = time__q__end - time__q__start
        #
        # Converting raw seconds into Days, Hours, Minutes, and Seconds
        time_delta = timedelta(seconds=time__total__elapsed)
        # Format the time_delta cleanly into a human-readable single line
        days = time_delta.days
        hours, remainder = divmod(time_delta.seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        #
        print(f'    Num_of_Granules_Found_in_CMR {db_key}: {total_remaining_count}      | Query Time: Total Duration: {days} Days, {hours} Hours, {minutes} Minutes, {seconds} Seconds')
        sys.stdout.flush()
    print(f'')
    #
    #
    print(f'Workflow: workflow__Output_Num_of_Granules_Found_in_CMR_for__All_DBs() is completed')

# #124: "Output Sample of Granules Found in CMR All DBs"
# elif(option_selection_number == 124):
#   workflow__Output_Sample_of_Granules_Found_in_CMR_for__All_DBs()
def workflow__Output_Sample_of_Granules_Found_in_CMR_for__All_DBs():
    print(f'Starting workflow__Output_Sample_of_Granules_Found_in_CMR_for__All_DBs()')
    #
    #
    num_of_granules_to_select = 3
    #print(f'  Using {cmr_checking__max_retries} for cmr_checking__max_retries')
    print(f'  These queries may many minutes to process depending on how large the databases are.')
    print(f'')
    print(f'  Sample of {num_of_granules_to_select} Granules from each database That Were Found in CMR:')
    print(f'    Hint (This INCLUDES Granules that have been deleted - it is a blind CMR Check Query) # Granules that Succeeded CMR check including any other value from any other column in the DB (new SQL needed)')
    print(f'')
    sys.stdout.flush()
    #
    db_keys = ['WV04', 'WV03', 'WV02', 'WV01', 'GE01']
    for db_key in db_keys:
        time__q__start = time.time()
        granule_samples = DatabaseManager.get_granules__That_Were_Found_in_CMR(db_name_key=db_key, max_num_of_granules=num_of_granules_to_select)
        time__q__end = time.time()
        #
        # Raw Seconds
        time__total__elapsed = time__q__end - time__q__start
        #
        # Converting raw seconds into Days, Hours, Minutes, and Seconds
        time_delta = timedelta(seconds=time__total__elapsed)
        # Format the time_delta cleanly into a human-readable single line
        days = time_delta.days
        hours, remainder = divmod(time_delta.seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        #
        if(granule_samples is None):
            granule_samples = []
        len__granule_samples = len(granule_samples)
        print(f'    ====================================================================================================')
        print(f'    Sample of_Granules_That_Were_Found_in_CMR {db_key}: {len__granule_samples}      | Query Time: Total Duration: {days} Days, {hours} Hours, {minutes} Minutes, {seconds} Seconds')
        if(len__granule_samples != 0):
            print(f'')
        for granule_sample in granule_samples:
            print(f'    Just the ID of each:')
            print(f'      Granule ID: {granule_sample.granule_id}')
        if(len__granule_samples != 0):
            print(f'')
            print(f'    Detail for Each:')
        for granule_sample in granule_samples:
            #granule_sample_detail_str = granule_sample.to_string()
            print(f'      Granule ID: {granule_sample.granule_id}')
            print(f'        Obj: {granule_sample}')
        if(len__granule_samples == 0):
            print(f'      ---- No Granules to display ----')
        print(f'    ====================================================================================================')
        print(f'')
        sys.stdout.flush()
    print(f'')
    #
    #
    print(f'Workflow: workflow__Output_Sample_of_Granules_Found_in_CMR_for__All_DBs() is completed')

# #125: "Output Number of Granules Ready for Delete for All DBs"          # Important, If a granule has already been deleted, it should NOT appear in this list.
# elif(option_selection_number == 125):
#   workflow__Output_Num_of_Granules_Ready_for_Delete_for__All_DBs()
def workflow__Output_Num_of_Granules_Ready_for_Delete_for__All_DBs():
    print(f'Starting workflow__Output_Num_of_Granules_Ready_for_Delete_for__All_DBs()')
    #
    #
    delete_trying__max_retries = 3
    print(f'  Using {delete_trying__max_retries} for delete_trying__max_retries')
    print(f'  These queries may many minutes to process depending on how large the databases are.')
    print(f'')
    print(f'  Total Granules Ready for Deletes (S3 and DynamoDB) Counts:')
    print(f'    Hint (These granules have all the check boxes needed for deleting but are not yet deleted)  # Important, If a granule has already been deleted, it should NOT appear in this list.')
    print(f'')
    sys.stdout.flush()
    #
    db_keys = ['WV04', 'WV03', 'WV02', 'WV01', 'GE01']
    for db_key in db_keys:
        time__q__start = time.time()
        total_remaining_count = DatabaseManager.get_count__Granules_Ready_For_Delete(db_name_key=db_key, max_retries=delete_trying__max_retries)
        time__q__end = time.time()
        #
        # Raw Seconds
        time__total__elapsed = time__q__end - time__q__start
        #
        # Converting raw seconds into Days, Hours, Minutes, and Seconds
        time_delta = timedelta(seconds=time__total__elapsed)
        # Format the time_delta cleanly into a human-readable single line
        days = time_delta.days
        hours, remainder = divmod(time_delta.seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        #
        print(f'    Num_of_Granules_Ready_For_Delete {db_key}: {total_remaining_count}      | Query Time: Total Duration: {days} Days, {hours} Hours, {minutes} Minutes, {seconds} Seconds')
        sys.stdout.flush()
    print(f'')
    #
    #
    print(f'Workflow: workflow__Output_Num_of_Granules_Ready_for_Delete_for__All_DBs() is completed')

# #126: "Output Sample of Granules Ready for Delete for All DBs"          # Hint (These granules have all the check boxes needed for deleting but are not yet deleted)   # New SQL Needed
# elif(option_selection_number == 126):
#   workflow__Output_Sample_of_Granules_Ready_for_Delete_for__All_DBs()
def workflow__Output_Sample_of_Granules_Ready_for_Delete_for__All_DBs():
    print(f'Starting workflow__Output_Sample_of_Granules_Ready_for_Delete_for__All_DBs()')
    #
    #
    num_of_granules_to_select = 3
    delete_trying__max_retries = 3
    print(f'  Using {delete_trying__max_retries} for delete_trying__max_retries')
    print(f'  These queries may many minutes to process depending on how large the databases are.')
    print(f'')
    print(f'  Sample of {num_of_granules_to_select} Granules from each database That Are Ready for Deletes (S3 and DynamoDB):')
    print(f'    Hint (These granules have all the check boxes needed for deleting but are not yet deleted)  # Important, If a granule has already been deleted, it should NOT appear in this list.')
    print(f'')
    sys.stdout.flush()
    #
    db_keys = ['WV04', 'WV03', 'WV02', 'WV01', 'GE01']
    for db_key in db_keys:
        time__q__start = time.time()
        granule_samples = DatabaseManager.get_granules__That_Are_Ready_For_Deletes(db_name_key=db_key, max_num_of_granules=num_of_granules_to_select, max_retries=delete_trying__max_retries)
        time__q__end = time.time()
        #
        # Raw Seconds
        time__total__elapsed = time__q__end - time__q__start
        #
        # Converting raw seconds into Days, Hours, Minutes, and Seconds
        time_delta = timedelta(seconds=time__total__elapsed)
        # Format the time_delta cleanly into a human-readable single line
        days = time_delta.days
        hours, remainder = divmod(time_delta.seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        #
        if(granule_samples is None):
            granule_samples = []
        len__granule_samples = len(granule_samples)
        print(f'    ====================================================================================================')
        print(f'    Sample of_Granules_That_Are_Ready_For_Deletes {db_key}: {len__granule_samples}      | Query Time: Total Duration: {days} Days, {hours} Hours, {minutes} Minutes, {seconds} Seconds')
        if(len__granule_samples != 0):
            print(f'')
        for granule_sample in granule_samples:
            print(f'    Just the ID of each:')
            print(f'      Granule ID: {granule_sample.granule_id}')
        if(len__granule_samples != 0):
            print(f'')
            print(f'    Detail for Each:')
        for granule_sample in granule_samples:
            #granule_sample_detail_str = granule_sample.to_string()
            print(f'      Granule ID: {granule_sample.granule_id}')
            print(f'        Obj: {granule_sample}')
        if(len__granule_samples == 0):
            print(f'      ---- No Granules to display ----')
        print(f'    ====================================================================================================')
        print(f'')
        sys.stdout.flush()
    print(f'')
    #
    #
    print(f'Workflow: workflow__Output_Sample_of_Granules_Ready_for_Delete_for__All_DBs() is completed')

# #127: "Output Number of Granules that have been Deleted for All DBs"
# elif(option_selection_number == 127):
#   workflow__Output_Num_of_Granules_That_Have_Been_Deleted_for__All_DBs()
def workflow__Output_Num_of_Granules_That_Have_Been_Deleted_for__All_DBs():
    print(f'Starting workflow__Output_Num_of_Granules_That_Have_Been_Deleted_for__All_DBs()')
    #
    #
    #cmr_checking__max_retries = 3
    #print(f'  Using {cmr_checking__max_retries} for cmr_checking__max_retries')
    print(f'  These queries may many minutes to process depending on how large the databases are.')
    print(f'')
    print(f'  Total Granules That Have Been Deleted (S3 and DynamoDB) Counts:')
    print(f'    Hint (Granules that this system and database says and tracked that they were actually deleted)')
    print(f'')
    sys.stdout.flush()
    #
    db_keys = ['WV04', 'WV03', 'WV02', 'WV01', 'GE01']
    for db_key in db_keys:
        time__q__start = time.time()
        total_remaining_count = DatabaseManager.get_count__Granules_That_Have_Been_Deleted(db_name_key=db_key)
        time__q__end = time.time()
        #
        # Raw Seconds
        time__total__elapsed = time__q__end - time__q__start
        #
        # Converting raw seconds into Days, Hours, Minutes, and Seconds
        time_delta = timedelta(seconds=time__total__elapsed)
        # Format the time_delta cleanly into a human-readable single line
        days = time_delta.days
        hours, remainder = divmod(time_delta.seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        #
        print(f'    Num_of_Granules_That_Have_Been_Deleted {db_key}: {total_remaining_count}      | Query Time: Total Duration: {days} Days, {hours} Hours, {minutes} Minutes, {seconds} Seconds')
        sys.stdout.flush()
    print(f'')
    #
    #
    print(f'Workflow: workflow__Output_Num_of_Granules_That_Have_Been_Deleted_for__All_DBs() is completed')

# #128: "Output Sample of Granules that have been Deleted for All DBs"    # Hint (Granules that this system is sure actually deleted)
# elif(option_selection_number == 128):
#   workflow__Output_Sample_of_Granules_That_Have_Been_Deleted_for__All_DBs()
def workflow__Output_Sample_of_Granules_That_Have_Been_Deleted_for__All_DBs():
    print(f'Starting workflow__Output_Sample_of_Granules_That_Have_Been_Deleted_for__All_DBs()')
    #
    num_of_granules_to_select = 3
    #print(f'  Using {cmr_checking__max_retries} for cmr_checking__max_retries')
    print(f'  These queries may many minutes to process depending on how large the databases are.')
    print(f'')
    print(f'  Sample of {num_of_granules_to_select} Granules from each database That Have Been Deleted (S3 and DynamoDB)')
    print(f'    Hint (Granules that this system and database says and tracked that they were actually deleted)')
    print(f'')
    sys.stdout.flush()
    #
    db_keys = ['WV04', 'WV03', 'WV02', 'WV01', 'GE01']
    for db_key in db_keys:
        time__q__start = time.time()
        granule_samples = DatabaseManager.get_granules__That_Have_Been_Deleted(db_name_key=db_key, max_num_of_granules=num_of_granules_to_select)
        time__q__end = time.time()
        #
        # Raw Seconds
        time__total__elapsed = time__q__end - time__q__start
        #
        # Converting raw seconds into Days, Hours, Minutes, and Seconds
        time_delta = timedelta(seconds=time__total__elapsed)
        # Format the time_delta cleanly into a human-readable single line
        days = time_delta.days
        hours, remainder = divmod(time_delta.seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        #
        if(granule_samples is None):
            granule_samples = []
        len__granule_samples = len(granule_samples)
        print(f'    ====================================================================================================')
        print(f'    Sample of_Granules_That_Have_Been_Deleted {db_key}: {len__granule_samples}      | Query Time: Total Duration: {days} Days, {hours} Hours, {minutes} Minutes, {seconds} Seconds')
        if(len__granule_samples != 0):
            print(f'')
        for granule_sample in granule_samples:
            print(f'    Just the ID of each:')
            print(f'      Granule ID: {granule_sample.granule_id}')
        if(len__granule_samples != 0):
            print(f'')
            print(f'    Detail for Each:')
        for granule_sample in granule_samples:
            #granule_sample_detail_str = granule_sample.to_string()
            print(f'      Granule ID: {granule_sample.granule_id}')
            print(f'        Obj: {granule_sample}')
        if(len__granule_samples == 0):
            print(f'      ---- No Granules to display ----')
        print(f'    ====================================================================================================')
        print(f'')
        sys.stdout.flush()
    print(f'')
    #
    #
    print(f'Workflow: workflow__Output_Sample_of_Granules_That_Have_Been_Deleted_for__All_DBs() is completed')





# # Metrics for Suggesting which Granules should be attempted to be ingested - and which ones could not be deleted after trying multiple times.

# # 141: "Output Number of Granules Suggested for Ingest Attempt for All DBs"    # Hint (These granules exist in the local database, did not pass the CMR check more than once and are likely need ingestion or reingestion) 
# elif(option_selection_number == 141):
#     workflow__Output_Num_of_Granules_Suggested_for_Ingest_Attempt_for__All_DBs()
def workflow__Output_Num_of_Granules_Suggested_for_Ingest_Attempt_for__All_DBs():
    print(f'Starting workflow__Output_Num_of_Granules_Suggested_for_Ingest_Attempt_for__All_DBs()')
    #
    #
    #cmr_checking__max_retries = 3
    #print(f'  Using {cmr_checking__max_retries} for cmr_checking__max_retries')
    print(f'  These queries may many minutes to process depending on how large the databases are.')
    print(f'')
    print(f'  Total Granules Suggested for Ingest Attempts Counts:')
    print(f'    Hint (These granules exist in the local database, did not pass the CMR check more than once and are likely in need of ingestion or reingestion)')
    print(f'')
    sys.stdout.flush()
    #
    db_keys = ['WV04', 'WV03', 'WV02', 'WV01', 'GE01']
    for db_key in db_keys:
        time__q__start = time.time()
        total_remaining_count = DatabaseManager.get_count__Granules_Suggested_for_Ingest_Attempt(db_name_key=db_key)
        time__q__end = time.time()
        #
        # Raw Seconds
        time__total__elapsed = time__q__end - time__q__start
        #
        # Converting raw seconds into Days, Hours, Minutes, and Seconds
        time_delta = timedelta(seconds=time__total__elapsed)
        # Format the time_delta cleanly into a human-readable single line
        days = time_delta.days
        hours, remainder = divmod(time_delta.seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        #
        print(f'    Num_of_Granules_Suggested_For_Ingest_Attempts {db_key}: {total_remaining_count}      | Query Time: Total Duration: {days} Days, {hours} Hours, {minutes} Minutes, {seconds} Seconds')
        sys.stdout.flush()
    print(f'')
    #
    #
    print(f'Workflow: workflow__Output_Num_of_Granules_Suggested_for_Ingest_Attempt_for__All_DBs() is completed')

# # 142: "Output Sample of Granules Suggested for Ingest Attempt for All DBs"
# elif(option_selection_number == 142):
#     workflow__Output_Sample_of_Granules_Suggested_for_Ingest_Attempt_for__All_DBs()
def workflow__Output_Sample_of_Granules_Suggested_for_Ingest_Attempt_for__All_DBs():
    print(f'Starting workflow__Output_Sample_of_Granules_Suggested_for_Ingest_Attempt_for__All_DBs()')
    #
    num_of_granules_to_select = 3
    #print(f'  Using {cmr_checking__max_retries} for cmr_checking__max_retries')
    print(f'  These queries may many minutes to process depending on how large the databases are.')
    print(f'')
    print(f'  Sample of {num_of_granules_to_select} Granules from each database Suggested for Ingest Attempts')
    print(f'    Hint (These granules exist in the local database, did not pass the CMR check more than once and are likely in need of ingestion or reingestion)')
    print(f'')
    sys.stdout.flush()
    #
    db_keys = ['WV04', 'WV03', 'WV02', 'WV01', 'GE01']
    for db_key in db_keys:
        time__q__start = time.time()
        granule_samples = DatabaseManager.get_granules__Suggested_for_Ingest_Attempt(db_name_key=db_key, max_num_of_granules=num_of_granules_to_select)
        time__q__end = time.time()
        #
        # Raw Seconds
        time__total__elapsed = time__q__end - time__q__start
        #
        # Converting raw seconds into Days, Hours, Minutes, and Seconds
        time_delta = timedelta(seconds=time__total__elapsed)
        # Format the time_delta cleanly into a human-readable single line
        days = time_delta.days
        hours, remainder = divmod(time_delta.seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        #
        if(granule_samples is None):
            granule_samples = []
        len__granule_samples = len(granule_samples)
        print(f'    ====================================================================================================')
        print(f'    Sample of_Granules_Suggested_for_Ingest_Attempt {db_key}: {len__granule_samples}      | Query Time: Total Duration: {days} Days, {hours} Hours, {minutes} Minutes, {seconds} Seconds')
        if(len__granule_samples != 0):
            print(f'')
        for granule_sample in granule_samples:
            print(f'    Just the ID of each:')
            print(f'      Granule ID: {granule_sample.granule_id}')
        if(len__granule_samples != 0):
            print(f'')
            print(f'    Detail for Each:')
        for granule_sample in granule_samples:
            #granule_sample_detail_str = granule_sample.to_string()
            print(f'      Granule ID: {granule_sample.granule_id}')
            print(f'        Obj: {granule_sample}')
        if(len__granule_samples == 0):
            print(f'      ---- No Granules to display ----')
        print(f'    ====================================================================================================')
        print(f'')
        sys.stdout.flush()
    print(f'')
    #
    #
    print(f'Workflow: workflow__Output_Sample_of_Granules_Suggested_for_Ingest_Attempt_for__All_DBs() is completed')


# # 143: "Output Number of Granules That Could Not Be Deleted for All DBs"       # Hint (This is Granules that are ready for delete but have failed to be deleted at least 2 times (once for first attempt, and a second time for retry)
# elif(option_selection_number == 143):
#     workflow__Output_Num_of_Granules_That_Could_Not_Be_Deleted_for__All_DBs()
def workflow__Output_Num_of_Granules_That_Could_Not_Be_Deleted_for__All_DBs():
    print(f'Starting workflow__Output_Num_of_Granules_That_Could_Not_Be_Deleted_for__All_DBs()')
    #
    #
    #cmr_checking__max_retries = 3
    #print(f'  Using {cmr_checking__max_retries} for cmr_checking__max_retries')
    print(f'  These queries may many minutes to process depending on how large the databases are.')
    print(f'')
    print(f'  Total Granules That Could NOT Be Deleted (S3 Only) Counts:')
    print(f'    Hint (These are Granules that are ready for delete but have failed to be deleted at least 2 times (once for first attempt, and a second time for retry)')
    print(f'')
    sys.stdout.flush()
    #
    db_keys = ['WV04', 'WV03', 'WV02', 'WV01', 'GE01']
    for db_key in db_keys:
        time__q__start = time.time()
        total_remaining_count = DatabaseManager.get_count__Granules_That_Could_Not_Be_Deleted(db_name_key=db_key)
        time__q__end = time.time()
        #
        # Raw Seconds
        time__total__elapsed = time__q__end - time__q__start
        #
        # Converting raw seconds into Days, Hours, Minutes, and Seconds
        time_delta = timedelta(seconds=time__total__elapsed)
        # Format the time_delta cleanly into a human-readable single line
        days = time_delta.days
        hours, remainder = divmod(time_delta.seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        #
        print(f'    Num_of_Granules_That_Could_Not_Be_Deleted {db_key}: {total_remaining_count}      | Query Time: Total Duration: {days} Days, {hours} Hours, {minutes} Minutes, {seconds} Seconds')
        sys.stdout.flush()
    print(f'')
    #
    #
    print(f'Workflow: workflow__Output_Num_of_Granules_That_Could_Not_Be_Deleted_for__All_DBs() is completed')

# # 144: "Output Sample of Granules That Could Not Be Deleted for All DBs"
# elif(option_selection_number == 144):
#     workflow__Output_Sample_of_Granules_That_Could_Not_Be_Deleted_for__All_DBs()
def workflow__Output_Sample_of_Granules_That_Could_Not_Be_Deleted_for__All_DBs():
    print(f'Starting workflow__Output_Sample_of_Granules_That_Could_Not_Be_Deleted_for__All_DBs()')
    #
    num_of_granules_to_select = 3
    #print(f'  Using {cmr_checking__max_retries} for cmr_checking__max_retries')
    print(f'  These queries may many minutes to process depending on how large the databases are.')
    print(f'')
    print(f'  Sample of {num_of_granules_to_select} Granules from each database That Could Not Be Deleted (S3 Only)')
    print(f'    Hint (These are Granules that are ready for delete but have failed to be deleted at least 2 times (once for first attempt, and a second time for retry)')
    print(f'')
    sys.stdout.flush()
    #
    db_keys = ['WV04', 'WV03', 'WV02', 'WV01', 'GE01']
    for db_key in db_keys:
        time__q__start = time.time()
        granule_samples = DatabaseManager.get_granules__That_Could_Not_Be_Deleted(db_name_key=db_key, max_num_of_granules=num_of_granules_to_select)
        time__q__end = time.time()
        #
        # Raw Seconds
        time__total__elapsed = time__q__end - time__q__start
        #
        # Converting raw seconds into Days, Hours, Minutes, and Seconds
        time_delta = timedelta(seconds=time__total__elapsed)
        # Format the time_delta cleanly into a human-readable single line
        days = time_delta.days
        hours, remainder = divmod(time_delta.seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        #
        if(granule_samples is None):
            granule_samples = []
        len__granule_samples = len(granule_samples)
        print(f'    ====================================================================================================')
        print(f'    Sample of_Granules_That_Could_Not_Be_Deleted {db_key}: {len__granule_samples}      | Query Time: Total Duration: {days} Days, {hours} Hours, {minutes} Minutes, {seconds} Seconds')
        if(len__granule_samples != 0):
            print(f'')
        for granule_sample in granule_samples:
            print(f'    Just the ID of each:')
            print(f'      Granule ID: {granule_sample.granule_id}')
        if(len__granule_samples != 0):
            print(f'')
            print(f'    Detail for Each:')
        for granule_sample in granule_samples:
            #granule_sample_detail_str = granule_sample.to_string()
            print(f'      Granule ID: {granule_sample.granule_id}')
            print(f'        Obj: {granule_sample}')
        if(len__granule_samples == 0):
            print(f'      ---- No Granules to display ----')
        print(f'    ====================================================================================================')
        print(f'')
        sys.stdout.flush()
    print(f'')
    #
    #
    print(f'Workflow: workflow__Output_Sample_of_Granules_That_Could_Not_Be_Deleted_for__All_DBs() is completed')




def workflow__test_NEXT_WORKFLOW_PLACEHOLDER():
    # The next tests
    pass




def exit_program():
    print(f'')
    print(f'exit_program(): called.  Exiting now (with sys.exit(0)')
    print(f'  Exiting now (with sys.exit(0)')
    print(f'')
    sys.exit(0)

def main_router(option_selection_number=1):
    print(f'Starting Main Router with option (option_selection_number): {option_selection_number}')

    if(option_selection_number == 1):
        print(f'Selection {option_selection_number} is currently reserved.  Exiting now')
        exit_program()
    

    elif(option_selection_number == 11):
        workflow__Do_Full_DynamoDB_Scan_And_Write_All_To_SQLite_for_WV04()

    elif(option_selection_number == 12):
        workflow__Do_Full_DynamoDB_Scan_And_Write_All_To_SQLite_for_WV03()

    elif(option_selection_number == 13):
        workflow__Do_Full_DynamoDB_Scan_And_Write_All_To_SQLite_for_WV02()

    elif(option_selection_number == 14):
        workflow__Do_Full_DynamoDB_Scan_And_Write_All_To_SQLite_for_WV01()

    elif(option_selection_number == 15):
        workflow__Do_Full_DynamoDB_Scan_And_Write_All_To_SQLite_for_GE01()



    elif(option_selection_number == 21):
        workflow__Do_Full_Manifest_Download_And_Extraction_To_Files_List_For_PROD()
    elif(option_selection_number == 22):
        workflow__Do_Convert_Manifest_Files_List_To_GranuleIDs_For_PROD()
    elif(option_selection_number == 23):
        workflow__Do_Update_Local_DB_Flag_For_Manifest_Files_Found_For_PROD()

    elif(option_selection_number == 31):
        workflow__Do_Full_Manifest_Download_And_Extraction_To_Files_List_For_PROD_DR()
    elif(option_selection_number == 32):
        workflow__Do_Convert_Manifest_Files_List_To_GranuleIDs_For_PROD_DR()
    elif(option_selection_number == 33):
        workflow__Do_Update_Local_DB_Flag_For_Manifest_Files_Found_For_PROD_DR()
    
    
    
    

    # 35: "Run CMR API Request Verification for WV04",
    elif(option_selection_number == 35):
        workflow__Do_CMR_API_request_verification_for_WV04()

    # 36: "Run CMR API Request Verification for WV03",
    elif(option_selection_number == 36):
        workflow__Do_CMR_API_request_verification_for_WV03()

    # 37: "Run CMR API Request Verification for WV02",
    elif(option_selection_number == 37):
        workflow__Do_CMR_API_request_verification_for_WV02()

    # 38: "Run CMR API Request Verification for WV01",
    elif(option_selection_number == 38):
        workflow__Do_CMR_API_request_verification_for_WV01()

    # 39: "Run CMR API Request Verification for GE01",
    elif(option_selection_number == 39):
        workflow__Do_CMR_API_request_verification_for_GE01()



    # 45: "Run S3 and DynamoDB Deletes for WV04",
    elif(option_selection_number == 45):
        workflow__Do_S3_and_DynamoDB_Deletes_for_WV04()

    # 46: "Run S3 and DynamoDB Deletes for WV03",
    elif(option_selection_number == 46):
        workflow__Do_S3_and_DynamoDB_Deletes_for_WV03()

    # 47: "Run S3 and DynamoDB Deletes for WV02",
    elif(option_selection_number == 47):
        workflow__Do_S3_and_DynamoDB_Deletes_for_WV02()

    # 48: "Run S3 and DynamoDB Deletes for WV01",
    elif(option_selection_number == 48):
        workflow__Do_S3_and_DynamoDB_Deletes_for_WV01()

    # 49: "Run S3 and DynamoDB Deletes for GE01",
    elif(option_selection_number == 49):
        workflow__Do_S3_and_DynamoDB_Deletes_for_GE01()



    elif(option_selection_number == 51):
        workflow__create_local_sqlite_tables()


    
    elif(option_selection_number == 61):
        workflow__create_snapshot_backup_of_code_and_sqlite_DBs()
    elif(option_selection_number == 62):
        workflow__create_snapshot_backup_of_code_only()
    elif(option_selection_number == 63):
        workflow__create_snapshot_backup_of_sqlite_DBs_only()

    


    elif(option_selection_number == 71):
        workflow__test_sqlite_granule_table()

    elif(option_selection_number == 72):
        workflow__test_get_small_dynamoDB_samples()

    elif(option_selection_number == 73):
        workflow__test_get_small_dynamoDB_samples_AS_JSON()

    elif(option_selection_number == 74):
        workflow__test_convert_a_few_dynamoDB_rows_into_SQLite_DB_Rows()

    elif(option_selection_number == 75):
        workflow__test_view_local_SQLite_WV04_top_few_rows()

    # 81: "Test Various Manifest Processing Helper Functions",
    elif(option_selection_number == 81):
        workflow__test_various_manifest_processing_helper_functions()

    # 85: "Test Run CMR API Request Verification for All Types - Small Batch of data",
    elif(option_selection_number == 85):
        workflow__test_run_CMR_API_request_verification_for_all_types__small_batch_of_data()

    # 86: "Output All Counts for Remaining CMR Granules to check from All DBs",
    elif(option_selection_number == 86):
        workflow__Output_All_Counts_For_Remaining_CMR_Granules_To_Check_from_All_DBs()


    # 95: "Test S3 and DynamoDB Deletes for All Types - Small Batch of data",
    elif(option_selection_number == 95):
        workflow__test_run_S3_and_DynamoDB_Deletes_for_all_types__small_batch_of_data()

    # 96: "Output All Counts for Remaining S3 and DynamoDB Granule Deletes to try from All DBs",
    elif(option_selection_number == 96):
        workflow__Output_All_Counts_For_Remaining_S3_and_DynamoDB_Granule_Deletes_To_Try_from_All_DBs()




    # // Option 99 is defined below as the 'else' part of this whole processor.


    
    elif(option_selection_number == 101):
        workflow__Output_SQLite_Table_Stats_for__WV04()

    elif(option_selection_number == 102):
        workflow__Output_SQLite_Table_Stats_for__WV03()

    elif(option_selection_number == 103):
        workflow__Output_SQLite_Table_Stats_for__WV02()

    elif(option_selection_number == 104):
        workflow__Output_SQLite_Table_Stats_for__WV01()

    elif(option_selection_number == 105):
        workflow__Output_SQLite_Table_Stats_for__GE01()



    elif(option_selection_number == 109):
        workflow__Output_SQLite_Table_Stats_for__All_DBs()
    

    # Other Reporting and Diagnnostics

    #121: "Output Number of CMR Unresolved Granules for All DBs"            # Hint (These granules likely need ingestion or reingestion) # Granules that failed CMR check including retries (new SQL needed)
    elif(option_selection_number == 121):
        workflow__Output_Num_of_CMR_Unresolved_Granules_for__All_DBs()
    #122: "Output Sample of CMR Unresolved Granules for All DBs"
    elif(option_selection_number == 122):
        workflow__Output_Sample_of_CMR_Unresolved_Granules_for__All_DBs()

    #123: "Output Number of Granules Found in CMR All DBs"                  # Hint (This INCLUDES Granules that have been deleted - it is a blind CMR Check Query) # Granules that Succeeded CMR check including any other value from any other column in the DB (new SQL needed)
    elif(option_selection_number == 123):
        workflow__Output_Num_of_Granules_Found_in_CMR_for__All_DBs()
    #124: "Output Sample of Granules Found in CMR All DBs"
    elif(option_selection_number == 124):
        workflow__Output_Sample_of_Granules_Found_in_CMR_for__All_DBs()

    #125: "Output Number of Granules Ready for Delete for All DBs"          # Important, If a granule has already been deleted, it should NOT appear in this list.
    elif(option_selection_number == 125):
        workflow__Output_Num_of_Granules_Ready_for_Delete_for__All_DBs()
    #126: "Output Sample of Granules Ready for Delete for All DBs"          # Hint (These granules have all the check boxes needed for deleting but are not yet deleted)   # New SQL Needed
    elif(option_selection_number == 126):
        workflow__Output_Sample_of_Granules_Ready_for_Delete_for__All_DBs()
    
    #127: "Output Number of Granules that have been Deleted for All DBs"
    elif(option_selection_number == 127):
        workflow__Output_Num_of_Granules_That_Have_Been_Deleted_for__All_DBs()
    #128: "Output Sample of Granules that have been Deleted for All DBs"    # Hint (Granules that this system is sure actually deleted)
    elif(option_selection_number == 128):
        workflow__Output_Sample_of_Granules_That_Have_Been_Deleted_for__All_DBs()

    # # Metrics for Suggesting which Granules should be attempted to be ingested - and which ones could not be deleted after trying multiple times.
    # 141: "Output Number of Granules Suggested for Ingest Attempt for All DBs"    # Hint (These granules exist in the local database, did not pass the CMR check more than once and are likely need ingestion or reingestion) 
    elif(option_selection_number == 141):
        workflow__Output_Num_of_Granules_Suggested_for_Ingest_Attempt_for__All_DBs()
    # 142: "Output Sample of Granules Suggested for Ingest Attempt for All DBs"
    elif(option_selection_number == 142):
        workflow__Output_Sample_of_Granules_Suggested_for_Ingest_Attempt_for__All_DBs()
    
    # 143: "Output Number of Granules That Could Not Be Deleted for All DBs"       # Hint (This is Granules that are ready for delete but have failed to be deleted at least 2 times (once for first attempt, and a second time for retry)
    elif(option_selection_number == 143):
        workflow__Output_Num_of_Granules_That_Could_Not_Be_Deleted_for__All_DBs()
    # 144: "Output Sample of Granules That Could Not Be Deleted for All DBs"
    elif(option_selection_number == 144):
        workflow__Output_Sample_of_Granules_That_Could_Not_Be_Deleted_for__All_DBs()

    #DRAFT
    # #121: "Output Number of CMR Unresolved Granules for All DBs"            # Hint (These granules likely need ingestion or reingestion) # Granules that failed CMR check including retries (new SQL needed)
    # #122: "Output Number of Granules Found in CMR All DBs"                  # Hint (This INCLUDES Granules that have been deleted - it is a blind CMR Check Query) # Granules that Succeeded CMR check including any other value from any other column in the DB (new SQL needed)
    # elif(option_selection_number == 122):
    #   ()
    # #125: "Output Sample of Granules Ready for Delete for All DBs"          # Hint (These granules have all the check boxes needed for deleting but are not yet deleted)   # New SQL Needed
    # elif(option_selection_number == 109):
    #   workflow__Output_Num_of_Granules_Found_in_CMR_for__All_DBs()
    # #126: "Output Sample of Granules that have been Deleted for All DBs"    # Hint (Granules that this system is sure actually deleted)
    # elif(option_selection_number == 109):
    #   workflow__Output_SQLite_Table_Stats_for__All_DBs()


    else: #(option_selection_number == 99):
        print(f'  Either Option 99 was selected or an unknown options was selected.  Exiting now.')
        print(f'')
        print(f'    Available options are:')
        print(f'')
        options = get_router_options()
        #print(f'{options}')
        for num, desc in options.items():
            print(f'{num}. {desc}')
        print(f'')
        exit_program()
    
    pass


# All Possible Route options
def get_router_options():
    options = {
        1: "default",

        
        11: "Do Full DynamoDB Scan And Write All To SQLite for WV04",
        12: "Do Full DynamoDB Scan And Write All To SQLite for WV03",
        13: "Do Full DynamoDB Scan And Write All To SQLite for WV02",
        14: "Do Full DynamoDB Scan And Write All To SQLite for WV01",
        15: "Do Full DynamoDB Scan And Write All To SQLite for GE01",
        
        # Main Execution Steps for PROD and PROD DR
        #
        21: "Do Full Manifest Download and Extraction To Files List for PROD",
        22: "Do Convert Manifest Files List To GranuleIDs for PROD",
        23: "Do Update Local DB Flag For Manifest Files Found For PROD",
        
        31: "Do Full Manifest Download and Extraction To Files List for PROD DR",
        32: "Do Convert Manifest Files List To GranuleIDs for PROD DR",
        33: "Do Update Local DB Flag For Manifest Files Found For PROD DR",
        # 

        # CMR Query Steps
        35: "Run CMR API Request Verification for WV04",
        36: "Run CMR API Request Verification for WV03",
        37: "Run CMR API Request Verification for WV02",
        38: "Run CMR API Request Verification for WV01",
        39: "Run CMR API Request Verification for GE01",

        # Actual Delete Steps
        45: "Run S3 and DynamoDB Deletes for WV04",
        46: "Run S3 and DynamoDB Deletes for WV03",
        47: "Run S3 and DynamoDB Deletes for WV02",
        48: "Run S3 and DynamoDB Deletes for WV01",
        49: "Run S3 and DynamoDB Deletes for GE01",

        # # # # # # # # # # # # # # # # # # # # # # # # # # # # 

        51: "Create Local SQLite Tables",

        61: "Create a snapshot backup of Code and SQLite DBs",
        62: "Create a snapshot backup of just the Code",
        63: "Create a snapshot backup of just the DBs",


        71: "Test SQLite Granule Table",
        72: "Test Get Small DynamoDB Scan Sample",
        73: "Test Get Small DynamoDB Scan Sample - AS JSON",
        74: "Test Convert a few DynamoDB Rows into SQLite DB Rows",
        75: "Test View Local SQLite Table WV04 - top few rows",

        81: "Test Various Manifest Processing Helper Functions",

        85: "Test Run CMR API Request Verification for All Types - Small Batch of data",
        86: "Output All Counts for Remaining CMR Granules to check from All DBs",

        95: "Test S3 and DynamoDB Deletes for All Types - Small Batch of data",
        96: "Output All Counts for Remaining S3 and DynamoDB Granule Deletes to try from All DBs",

        99: "exit",

        # # # # # # # # # # # # # # # # # # # # # # # # # # # # 

        101: "Output SQLite Table Stats for WV04",
        102: "Output SQLite Table Stats for WV03",
        103: "Output SQLite Table Stats for WV02",
        104: "Output SQLite Table Stats for WV01",
        105: "Output SQLite Table Stats for GE01",

        109: "Output SQLite Table Stats for All DBs",

        # Other Reporting and Diagnnostics
        121: "Output Number of CMR Unresolved Granules for All DBs",            # Hint (These granules likely need ingestion or reingestion) # Granules that failed CMR check including retries (new SQL needed)
        122: "Output Sample of CMR Unresolved Granules for All DBs",
        
        123: "Output Number of Granules Found in CMR All DBs",                  # Hint (This INCLUDES Granules that have been deleted - it is a blind CMR Check Query) # Granules that Succeeded CMR check including any other value from any other column in the DB (new SQL needed)
        124: "Output Sample of Granules Found in CMR All DBs",
        
        125: "Output Number of Granules Ready for Delete for All DBs",          # Important, If a granule has already been deleted, it should NOT appear in this list.
        126: "Output Sample of Granules Ready for Delete for All DBs",          # Hint (These granules have all the check boxes needed for deleting but are not yet deleted)   # New SQL Needed
        
        127: "Output Number of Granules that have been Deleted for All DBs",
        128: "Output Sample of Granules that have been Deleted for All DBs",    # Hint (Granules that this system and database is sure actually deleted)

        #
        141: "Output Number of Granules Suggested for Ingest Attempt for All DBs",    # Hint (These granules exist in the local database, did not pass the CMR check more than once and are likely need ingestion or reingestion) 
        142: "Output Sample of Granules Suggested for Ingest Attempt for All DBs",
        
        143: "Output Number of Granules That Could Not Be Deleted for All DBs",       # Hint (This is Granules that are ready for delete but have failed to be deleted at least 2 times (once for first attempt, and a second time for retry)
        144: "Output Sample of Granules That Could Not Be Deleted for All DBs",
        

    }
    return options

# Terminal Menu - for when running this manually.
def display_menu(options):
    print(f'************************ MAIN INTERFACE - MENU ************************')
    for num, desc in options.items():
        print(f'{num}. {desc}')
    print(f'***********************************************************************')

    # Loop until there is a valid selection
    while True:
        print(f'')
        choice = input('Select an option number and press Enter: ')
        try:
            choice = int(choice)
        except ValueError:
            print(f'  X: Please enter a valid number.')
            continue 

        if choice in options:
            return choice
        else:
            print(f'  X: {choice} is not one of the options.  Try again.')

# Are we in automation mode?
def get_automation_settings():
    
    print(f'')

    # Arg Parser, looking for automation
    parser = argparse.ArgumentParser(description="Main Interface")
    #
    # 'action="store_true"' means it's a flag (True if present, False if not)
    parser.add_argument("--automation", action="store_true", help="Enable automation mode")         # 2. Add the automation flag
    #
    # Add the required integer (only required if automation is True)
    parser.add_argument("--value", type=int, help="Integer Route parameter required for automation")
    #
    # Parse the arguments
    args = parser.parse_args()
    #
    # Logic Check: If automation is passed, ensure value is also there
    if args.automation and args.value is None:
        #parser.error("--automation requires --value [int].  The int value tells us which route on the following choices.")
        print(f'PARSE ERROR')
        print(f'  using the --automation flag requires --value [int].')
        print(f'  The int value tells us which code route to use among the following choices:')
        options = get_router_options()
        #print(f'{options}')
        for num, desc in options.items():
            print(f'{num}. {desc}')
        print(f'')
        print(f'  Please add one of the above options to your --value parameter to continue with code execution.')
        print(f'    Example: python code/main_interface.py --automation --value 99')
        print(f'')
        exit_program()
        # print(f'  Exiting now (with sys.exit(0)')
        # print(f'')
        # sys.exit(0)


    # --- Your code starts here ---
    if args.automation:
        print(f"Running in automation mode with value: {args.value}")
        return True, args.value
    else:
        print("Running in manual mode.")
        return False, 1

    # Safety Catch All
    return False, 1



# Initial router function
def main():

    # Are we in automation mode, if so, which route was passed in?
    is_automation, selected_route_value = get_automation_settings()

    # If we are running in automation mode, skip the user selection
    #
    # Only show and accept the user input if we are NOT running in automation mode.
    if(is_automation == False):
        options = get_router_options()
        print(f'')
        selection = display_menu(options)
        print(f'\nYou selected {selection}: {options[selection]}')
        print(f'')
        selected_route_value = selection

    # Calling the main Router now
    main_router(option_selection_number=selected_route_value)


# Entry Point
if __name__ == "__main__":
    main()