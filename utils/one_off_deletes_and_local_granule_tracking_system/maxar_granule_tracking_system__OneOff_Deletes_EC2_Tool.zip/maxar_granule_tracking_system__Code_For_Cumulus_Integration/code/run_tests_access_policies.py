# run_tests_access_policies.py

# We need to be able to access specific places on AWS.
# If all these tests pass, then all the access is setup properly.

import json
import os
import boto3
from dotenv import load_dotenv
from datetime import datetime, timedelta, timezone

# DIR PATH for temp tests
SETTINGS__tests_temp_working_dir = f'tests_temp_working_dir'

# Use Yesterday because we know for sure there will be a manifest there.
def get_yesterday_utc_string():
    """Returns yesterday's date in YYYY-MM-DD format based on UTC time."""
    # 1. Get the current time in UTC
    now_utc = datetime.now(timezone.utc)
    
    # 2. Subtract one day
    yesterday_utc = now_utc - timedelta(days=1)
    
    # 3. Format as a string
    return yesterday_utc.strftime('%Y-%m-%d')

# Can we Save a file to the S3 export area
def save_test_file_to_s3_export_area():
    print(f'')
    print(f'About to run test: save_test_file_to_s3_export_area')
    print(f'... Finish writing this test')
    print(f'')
    pass

# Can we read from the DynamoDB?
def read_from_dynamo_DB():
    print(f'')
    print(f'About to run test: read_from_dynamo_DB')
    print(f'')

    print(f'About to access one of the DynamoDB Tables and read from it....(DynamoDB Table: WV04<dynamodb_table_name>)')

    print(f'')
    print(f'Access a record for a known ID....')
    #
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('WV04<dynamodb_table_name>')
    #
    # Record in WV04 on the first page (S3 Key Path)
    response = table.get_item(
        Key={'file_path': '<path/to/granule/root>/<path/to/specific/granule>'}
        
    )
    #
    print(response.get('Item', 'Row not found.'))

    print(f'')
    print(f'Access the first 2 records by doing a scan....')
    #
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('WV04<dynamodb_table_name>')
    #
    # Scan is expensive on large tables, but Limit=1 keeps it cheap for testing
    response = table.scan(Limit=2) # 1)
    items = response.get('Items', [])
    #
    if items:
        # print(items[0])
        for item in items:
            print(f'------------------------')
            print(item)
            print(f'------------------------')
    else:
        print("The table is empty.")


    pass

# Can we read from PROD and ORCA Manifests?
def read_manifest_files():
    print(f'')
    print(f'About to run test: read_manifest_files')
    print(f'')

    # Access specific variables, If the variable is missing, the default gets used (second parameter)
    INVENTORY_PROD_BUCKET_NAME = os.getenv("INVENTORY_PROD_BUCKET_NAME", "unknown_bucket_name_value")
    INVENTORY_PROD_BASE_KEY_PATH = os.getenv("INVENTORY_PROD_BASE_KEY_PATH", "unknown_base_key_path_value")
    INVENTORY_PROD_ORCA_BUCKET_NAME = os.getenv("INVENTORY_PROD_ORCA_BUCKET_NAME", "unknown_bucket_name_value")
    INVENTORY_PROD_ORCA_BASE_KEY_PATH = os.getenv("INVENTORY_PROD_ORCA_BASE_KEY_PATH", "unknown_base_key_path_value")

    print(f'')
    print(f"INVENTORY_PROD_BUCKET_NAME loaded:         {INVENTORY_PROD_BUCKET_NAME}")
    print(f"INVENTORY_PROD_BASE_KEY_PATH loaded:       {INVENTORY_PROD_BASE_KEY_PATH}")
    print(f"INVENTORY_PROD_ORCA_BUCKET_NAME loaded:    {INVENTORY_PROD_ORCA_BUCKET_NAME}")
    print(f"INVENTORY_PROD_ORCA_BASE_KEY_PATH loaded:  {INVENTORY_PROD_ORCA_BASE_KEY_PATH}")
    print(f'')

    print(f'About to access PROD manifest.json file....')

    # Append directory: 2026-02-09T01-00Z/
    full_key_path__prod_manifest        = f'{INVENTORY_PROD_BASE_KEY_PATH}{get_yesterday_utc_string()}T01-00Z/manifest.json'
    local_download_path__prod_manifest  = f'{SETTINGS__tests_temp_working_dir}/prod__manifest.json'
    
    s3_client = boto3.client('s3')
    
    try:
        print(f"Downloading from S3: {full_key_path__prod_manifest}...")
        
        # Download the file
        s3_client.download_file(
            Bucket=INVENTORY_PROD_BUCKET_NAME,
            Key=full_key_path__prod_manifest,
            Filename=local_download_path__prod_manifest
        )

        # Output the file contents.
        with open(local_download_path__prod_manifest, 'r') as f:
            data = json.load(f)  # Load the file content
            print(json.dumps(data, indent=4))  # Output with 4-space indentation
            
        print("Extraction complete!")
        
        # Optional: Clean up the downloaded file after test completes
        #os.remove(local_download_path__prod_manifest)
        #print(f"Temp file removed! {local_download_path__prod_manifest}")
        
    except Exception as e:
        print(f"read_manifest_files: An error occurred: {e}.  (TAG: Trying to read manifest.json file from PROD Bucket and Path) ")

    print(f'')
    print(f'')

    print(f'About to access PROD ORCA manifest.json file....')

    # Append directory: 2026-02-09T01-00Z/
    full_key_path__prod_orca_manifest        = f'{INVENTORY_PROD_ORCA_BASE_KEY_PATH}{get_yesterday_utc_string()}T01-00Z/manifest.json'
    local_download_path__prod_orca_manifest  = f'{SETTINGS__tests_temp_working_dir}/prod_orca__manifest.json'
    
    s3_client = boto3.client('s3')
    
    try:
        print(f"Downloading from S3: {full_key_path__prod_orca_manifest}...")
        
        # Download the file
        s3_client.download_file(
            Bucket=INVENTORY_PROD_ORCA_BUCKET_NAME,
            Key=full_key_path__prod_orca_manifest,
            Filename=local_download_path__prod_orca_manifest
        )

        # Output the file contents.
        with open(local_download_path__prod_orca_manifest, 'r') as f:
            data = json.load(f)  # Load the file content
            print(json.dumps(data, indent=4))  # Output with 4-space indentation
            
        print("Extraction complete!")
        
        # Optional: Clean up the downloaded file after test completes
        #os.remove(local_download_path__prod_orca_manifest)
        #print(f"Temp file removed! {local_download_path__prod_orca_manifest}")
        
    except Exception as e:
        print(f"read_manifest_files: An error occurred: {e}.  (TAG: Trying to read manifest.json file from PROD Bucket and Path) ")



# Main function for the tests.
def main():

    # Make sure the working directory for tests exists
    # Ensure the temp directory exists
    os.makedirs(SETTINGS__tests_temp_working_dir, exist_ok=True)

    # Load the ENV vars needed for this test.
    #
    # Load variables from the .env file
    load_dotenv()

    # Can we read from PROD and ORCA Manifests?
    #read_manifest_files()

    # Can we Save a file to the S3 export area
    save_test_file_to_s3_export_area()

    # Can we read from the DynamoDB?
    read_from_dynamo_DB()
    

    print(f'')
    print(f'END')
    print(f'')


main()