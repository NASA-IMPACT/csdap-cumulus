# config.py

# UPDATE: This file was only marginally used and needs to be utilized better as we take out any hard coded references and scale up to the Cloud Native version of this project.


class config:

	# Static Members
    config_version = "1.0.0"

    # These match what is in the manifests
    # Access Example: 	print(f'config.BUCKET_NAME__MCP_MAXAR_DELIVERY: {config.BUCKET_NAME__MCP_MAXAR_DELIVERY}')
    BUCKET_NAME__MCP_MAXAR_DELIVERY 	= 	"<delivery-bucket-name>" 					# MCP Original Delivery Bucket
    BUCKET_NAME__NGAP_CBA_PROD 			= 	"<prod-granule-bucket-name>" 			# NGAP Published - Using Public Bucket as proxy for granule - since all granules have thumbnails.
    BUCKET_NAME__NGAP_CBA_DR_PROD 		= 	"<prod-dr-granule-bucket-name>" 		# ORCA
    
    # Local Directory Paths
    LOCAL_DIR__SQLITE_ROOT  				=  	"gts_sqliteDBs"
    LOCAL_DIR__MANIFEST_FILE_PROCESSING  	=  	"gts_files_processing"
    


    # config.config_output_test()
    @staticmethod
    def config_output_test():
        print(f'Hello world from config_output_test.  config_version: {config.config_version}')

