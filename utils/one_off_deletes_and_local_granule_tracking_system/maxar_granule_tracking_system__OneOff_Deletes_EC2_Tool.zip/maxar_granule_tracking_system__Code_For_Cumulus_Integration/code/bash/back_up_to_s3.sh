#!/usr/bin/env bash

# back_up_to_s3.sh
# Backs up the entire directory and subdirectory of the drive to a specific s3 location
# This lets us get a quick restore point if the volume breaks again

# Exit immediately if a command exits with a non-zero status
set -e

# ==============================================================================
# CONFIGURATION
# ==============================================================================
# The local directory you want to recursively dump (Include trailing slash)
LOCAL_DIR="/var/www/my-app/"

# Your target S3 bucket name
S3_BUCKET="my-company-backup-bucket"

# The path inside the S3 bucket where you want the files to live
S3_PREFIX="active-current-copy/my-app"

# Optional: Extra arguments for the AWS CLI (e.g., encryption, storage class)
# --delete: Removes files in S3 that were deleted locally to ensure an exact match
EXTRA_ARGS="--delete --storage-class STANDARD"

# ==============================================================================
# EXECUTION
# ==============================================================================

# Verify the local directory exists before running
if [ ! -d "$LOCAL_DIR" ]; then
    echo "ERROR: Local directory $LOCAL_DIR does not exist." >&2
    exit 1
fi

echo "====================================================================="
echo "Starting S3 Sync: $(date)"
echo "Source:      $LOCAL_DIR"
echo "Destination: s3://$S3_BUCKET/$S3_PREFIX/"
echo "====================================================================="

# Run the sync command
aws s3 sync "$LOCAL_DIR" "s3://$S3_BUCKET/$S3_PREFIX/" $EXTRA_ARGS

echo "====================================================================="
echo "Sync Completed Successfully: $(date)"
echo "====================================================================="
