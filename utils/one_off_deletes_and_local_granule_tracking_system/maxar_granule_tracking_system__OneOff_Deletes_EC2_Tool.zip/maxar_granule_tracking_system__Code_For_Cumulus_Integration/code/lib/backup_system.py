# backup_system.py

import os
import shutil
import zipfile
from datetime import datetime
#
import boto3
from botocore.exceptions import NoCredentialsError

# To interface with the Databases (Create, selections, etc)
class BackupSystem:


    SETTINGS__local_dir_path__code          = 'code/'                                               # Local Directory that contains code being worked on
    SETTINGS__local_dir_path__sqlite_dbs    = 'gts_sqliteDBs/'                                      # Local Directory that contains the databases being worked on
    SETTINGS__local_dir_path__temp_out      = 'temp_out/'                                           # Local Directory where the zipped file goes -- that will get copied and sent to S3
    SETTINGS__local_dir_path__zip_versions  = 'out_zips_versions/'                                  # Local Directory where versioned zipped files will go.
    SETTINGS__local_file_name_prefix        = 'mgts'                                                # File name part that is used as the prefix for the zipped file names.
    SETTINGS__out_s3_bucket_name            = '<gts-utilities-bucket-name>'                         # Output Destination - S3 Bucket Name 
    SETTINGS__out_s3_root_key_path          = '<Expected_Backup_Key_Path>/backups'                  # Output Destination - Key Path up to the backups area

    # Zip all the files in the code directory

    # Lists all the files in the directory path.
    @staticmethod
    def get_all_files(in_directory_path):
        # Returns a list of filenames in the specified directory
        try:
            return [f for f in os.listdir(in_directory_path) if os.path.isfile(os.path.join(in_directory_path, f))]
        except FileNotFoundError:
            return "Directory not found."

    @staticmethod
    def get_date_timestamp_string():
        timestamp_string = datetime.utcnow().strftime("%Y_%m_%d__%H_%M")
        return timestamp_string


    # Zip the code directory
    @staticmethod
    def zip_entire_directory(in_directory_path, output_dir, output_filename="myfile_full"):
        # Ensure the output directory exists
        os.makedirs(output_dir, exist_ok=True)

        # Define the full path (shutil.make_archive adds .zip automatically)
        full_output_path = os.path.join(output_dir, output_filename)

        # This will create "myfile_full.zip" containing everything in in_directory_path
        # Note: make_archive adds the '.zip' extension automatically
        shutil.make_archive(full_output_path, 'zip', in_directory_path)
        print(f"Archive '{full_output_path}.zip' created successfully.")

    # Zip the code directory, but add the utc date time to the file name
    @staticmethod
    def zip_entire_dir_with_timestamp(in_directory_path, output_dir, output_filename="myfile_full"):
        # Ensure the output directory exists
        os.makedirs(output_dir, exist_ok=True)

        # Define the full path (shutil.make_archive adds .zip automatically)
        #full_output_path = os.path.join(output_dir, output_filename)
        #output_name = f"{output_filename}_{timestamp}"
        timestamp = BackupSystem.get_date_timestamp_string()  #datetime.utcnow().strftime("%Y_%m_%d__%H_%M")
        output_filename_with_timestamp = f"{output_filename}_{timestamp}"
        full_output_path = os.path.join(output_dir, output_filename_with_timestamp)
        shutil.make_archive(full_output_path, 'zip', in_directory_path)
        print(f"Archive '{full_output_path}.zip' created successfully.")

        return output_filename_with_timestamp


    # S3 Upload
    @staticmethod
    def upload_file_to_s3(local_file_path, bucket_name, key_path):
        # Construct the local path
        #local_file_path = f"{SETTINGS__local_dir_path__temp_out}{SETTINGS__local_file_name_prefix}.zip"
        
        # Initialize the S3 client
        # Boto3 automatically looks for environment variables for credentials
        s3_client = boto3.client('s3')

        # To set Credentials, do this (Mac Instructions)
        # export AWS_ACCESS_KEY_ID='your_access_key_here'
        # export AWS_SECRET_ACCESS_KEY='your_secret_key_here'
        # export AWS_DEFAULT_REGION='<AWS_Region>' # or your specific region
        
        try:
            print(f"Uploading {local_file_path} to s3://{bucket_name}/{key_path} ...")
            
            s3_client.upload_file(
                Filename=local_file_path,
                Bucket=bucket_name,
                Key=key_path
            )
            
            print("Upload Successful!")
        except FileNotFoundError:
            print(f"The local file {local_file_path} was not found.")
        except NoCredentialsError:
            print(f'')
            print(f'************************** ERROR COPYING FILE TO S3 **************************')
            print(f'')
            print("Credentials not available. If running locally, Please check your environment variables.")
            print(f'')
            print(f'  You may have to go get credentials and then run these commands before running this script:')
            print(f"    export AWS_ACCESS_KEY_ID='your_access_key_here'")
            print(f"    export AWS_SECRET_ACCESS_KEY='your_secret_key_here'")
            print(f"    export AWS_SESSION_TOKEN='your_session_token'")
            print(f"    export AWS_DEFAULT_REGION='<AWS_Region>' # or your specific region")
            print(f'')
            print(f'************************** ERROR COPYING FILE TO S3 **************************')
            print(f'')
        except Exception as e:
            print(f"An error occurred: {e}")

    # Snapshot Versions of backups which create a date timestamp and put it in the filename
    # Each time this is run, it will create a unique snapshot

    @staticmethod
    def backup_code():
        print(f'About to zip source code files and send to S3')
        print(f'')
        list_of_files = BackupSystem.get_all_files(in_directory_path=BackupSystem.SETTINGS__local_dir_path__code)
        print(f'  Files Found: {list_of_files}')
        print(f'')
        print(f'Creating Zip Files.')
        #
        #BackupSystem.zip_entire_directory(         in_directory_path=BackupSystem.SETTINGS__local_dir_path__code, output_dir=BackupSystem.SETTINGS__local_dir_path__temp_out,     output_filename=BackupSystem.SETTINGS__local_file_name_prefix)
        output_filename = f"{BackupSystem.SETTINGS__local_file_name_prefix}_src_code"  # mgts_src_code
        output_filename_with_timestamp = BackupSystem.zip_entire_dir_with_timestamp(in_directory_path=BackupSystem.SETTINGS__local_dir_path__code, output_dir=BackupSystem.SETTINGS__local_dir_path__zip_versions, output_filename=output_filename)
        print(f'')

        local_path__full_file_path__no_ext = os.path.join(BackupSystem.SETTINGS__local_dir_path__zip_versions, output_filename_with_timestamp)
        local_path__full_file_path = f"{local_path__full_file_path__no_ext}.zip"
        local_path__file_name_only = f"{output_filename_with_timestamp}.zip"
        #
        #print(f'Zip files created.  About to send to S3 Bucket: {BackupSystem.SETTINGS__out_s3_bucket_name} to KeyPath {BackupSystem.SETTINGS__out_s3_key_path}')
        key_path_for_current_zip_file = f"{BackupSystem.SETTINGS__out_s3_root_key_path}/manual/src_code/{local_path__file_name_only}"  #SETTINGS__out_s3_root_key_path           # Output Destination - Key Path up to the backups area

        print(f'Zip files created.  About to send to S3 Bucket: {BackupSystem.SETTINGS__out_s3_bucket_name} to KeyPath {key_path_for_current_zip_file}')
        # Example out: Zip files created.  About to send to S3 Bucket: backup-bucket to KeyPath path/to/backups/manual/src_code/mgts_src_code_2026_03_18__01_40.zip
        #upload_zip_to_s3()
        BackupSystem.upload_file_to_s3(local_file_path=local_path__full_file_path, bucket_name=BackupSystem.SETTINGS__out_s3_bucket_name, key_path=key_path_for_current_zip_file)
        
        print(f'')
        print(f'Should be all done now.')


        #output_filename = f"{BackupSystem.SETTINGS__local_file_name_prefix}_src_code"  # mgts_src_code
        
        # Get the timestamp and filename string
        #timestamp_string = BackupSystem.get_date_timestamp_string()
        #output_filename_with_timestamp = f"{output_filename}_{timestamp_string}"

        

    @staticmethod
    def backup_databases():
        # Get a timestamp (for the manual filename)
        timestamp = BackupSystem.get_date_timestamp_string()  #datetime.utcnow().strftime("%Y_%m_%d__%H_%M")

        # Iterate the Databases directory
        print(f'About to get the list of DBs to backup to S3')
        print(f'')
        list_of_db_files = BackupSystem.get_all_files(in_directory_path=BackupSystem.SETTINGS__local_dir_path__sqlite_dbs)
        print(f'  DB Files Found: {list_of_db_files}')
        print(f'')
        print(f'Backing up each DB now.')

        for db_file in list_of_db_files:
            # Upload each databaes file into the S3 DB Backup location.

            # Get the local file
            local_path__full_file_path = os.path.join(BackupSystem.SETTINGS__local_dir_path__sqlite_dbs, db_file)

            # Generate the Key Path
            key_path_for_current_db_file = f"{BackupSystem.SETTINGS__out_s3_root_key_path}/manual/DBs/{timestamp}/{db_file}"  #SETTINGS__out_s3_root_key_path         # Output Destination - Key Path up to the backups area

            print(f'')
            print(f'About to back up file {local_path__full_file_path} to S3 location: Bucket: {BackupSystem.SETTINGS__out_s3_bucket_name}, KeyPath {key_path_for_current_db_file}')
            BackupSystem.upload_file_to_s3(local_file_path=local_path__full_file_path, bucket_name=BackupSystem.SETTINGS__out_s3_bucket_name, key_path=key_path_for_current_db_file)
            print(f' ... Current DB file finished uploading.')
            print(f'')

        

        #SETTINGS__local_dir_path__sqlite_dbs    = 'gts_sqliteDBs/'                                      # Local Directory that contains the databases being worked on

        # output_filename = f"DBs"
        
        # # Get the timestamp and filename string
        # timestamp_string = BackupSystem.get_date_timestamp_string()
        # output_filename_with_timestamp = f"{output_filename}_{timestamp_string}"

        

    @staticmethod
    def backup_code_and_databases():
        BackupSystem.backup_code()
        BackupSystem.backup_databases()