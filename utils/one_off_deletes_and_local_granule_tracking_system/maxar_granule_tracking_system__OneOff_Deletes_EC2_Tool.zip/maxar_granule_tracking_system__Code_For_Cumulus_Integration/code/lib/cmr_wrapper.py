# cmr_wrapper.py
from __future__ import annotations

# Query the CMR 
#   Find out if our granules are published 
#   Find out if they are downloadable
#   Query in batches or individually
#   Test functions to ensure syntax works properly.


# Concept Ids
# WV01_Pan_L1B  =   "C2497387766-CSDA"

# Imports
import json
import os
import time
import sys

import requests
from requests.auth import HTTPBasicAuth


# Concept IDs matched to dataset
# WV01_Pan_L1B      #       C2497387766-CSDA
# WV01_Pan_L2A      #       C2520285535-CSDA

# WV01_Pan_L2A      #       C2520285535-CSDA


# To interface with the code that actually makes requests to the CMR
class CMRRequestManager:
    @staticmethod
    def get_CMR_GRANULES_URL():
        #CMR_GRANULES_URL = "https://cmr.earthdata.nasa.gov/search/granules.json"
        CMR_GRANULES_URL = "https://cmr.earthdata.nasa.gov/search/granules.umm_json"
        return CMR_GRANULES_URL

    # - Placeholder Functions
    # # Function to Build the reqeust Headers
    # # Function to make the Form Data
    # # Function to actually execute the requests
    # # Function to process the return results

    # - Placeholder - get_Collection_Concept_Id(granule_id)    // This function parse the granule id down to which collection within a larger dataset and then looks up the colleciton concept id based on the values in a look up table (Future: actually query CMR for this info from a collection name)
    
    # collection_concept_id__LIST = CMRRequestManager.get_collection_concept_id_list_for()
    @staticmethod
    def get_collection_concept_id_list():
        # #def get_collection_concept_id_list_for(db_name_key="DEFAULT"):
    
        # Default is to just get ALL of them.
        # Comment Guide:         # Collection Concept Id,   DB_Name_Key,    Collection_Short_Name
        collection_concept_id__LIST = [
            # WV01
            'C2497387766-CSDA',  # C2497387766-CSDA,        WV01,           WV01_Pan_L1B
            'C2520285535-CSDA',  # C2520285535-CSDA,        WV01,           WV01_Pan_L2A

            # WV02
            'C2497404794-CSDA',  # C2497404794-CSDA,        WV02,           WV02_MSI_L1B
            'C2497398128-CSDA',  # C2497398128-CSDA,        WV02,           WV02_Pan_L1B
            'C2520304080-CSDA',  # C2520304080-CSDA,        WV02,           WV02_MSI_L2A
            'C2520295955-CSDA',  # C2520295955-CSDA,        WV02,           WV02_Pan_L2A

            # WV03
            'C2497111771-CSDA',  # C2497111771-CSDA,        WV03,           WV03_MSI_L1B
            'C2497431983-CSDA',  # C2497431983-CSDA,        WV03,           WV03_Pan_L1B
            'C2520330358-CSDA',  # C2520330358-CSDA,        WV03,           WV03_MSI_L2A
            'C2520343293-CSDA',  # C2520343293-CSDA,        WV03,           WV03_Pan_L2A

            # WV04
            'C2497446902-CSDA',  # C2497446902-CSDA,        WV04,           WV04_MSI_L1B
            'C2497439327-CSDA',  # C2497439327-CSDA,        WV04,           WV04_Pan_L1B

            # GE01
            'C2471470251-CSDA',  # C2471470251-CSDA,        GE01,           GE01_MSI_L1B
            'C2497510652-CSDA',  # C2497510652-CSDA,        GE01,           GE01_Pan_L1B
            'C2520319725-CSDA',  # C2520319725-CSDA,        GE01,           GE01_MSI_L2A
            'C2520325054-CSDA'   # C2520325054-CSDA,        GE01,           GE01_Pan_L2A

            # Planetscope
            # C2112982481-CSDA # C2112982481-CSDA, NO_DB_YET, PlanetScope3band
        ]

        # Return the list
        return collection_concept_id__LIST

    # Need this function to ensure we don't end up with granules spread into multiple databases.
    # The main reason we need this is because of how the DBs are separated.
    # can_add_this_granule = CMRRequestManager.check_granule_id_against_db_name_key(db_name_key=db_name_key, granule_id=object_key_name__granule_id)
    # db_name_key = "WV01"
    # granule_id = "WV01_20171119060932_102001006BB20B00_17NOV19060932-P1BS-501699587090_03_P033"
    @staticmethod
    def check_granule_id_against_db_name_key(db_name_key, granule_id):
        # Current Convention is first 4 chars of a granule id should match the db_name_key exactly.
        ret_bool__does_granule_match_db_name_key = False

        len_granule_id = len(granule_id)
        if(len_granule_id > 4):
            part_to_check = granule_id[:4] 
            if(part_to_check == db_name_key):
                ret_bool__does_granule_match_db_name_key = True

        return ret_bool__does_granule_match_db_name_key

    #def send_CMR_API_Post_Request_For_Granule_Batch(granule_rows_list, collection_concept_id): #, db_name_key="DEFAULT"):
    @staticmethod
    def send_CMR_API_Post_Request_For_Granule_Batch(granule_rows_list, collection_concept_id_list): #, db_name_key="DEFAULT"):
        
        ret_response_json   = {} #'{}'
        has_api_error       = False

        try:
            # Get the Granule IDs from the Granule Rows List.
            granule_id_list = []
            for granule in granule_rows_list:
                granule_id_list.append(f'{granule.granule_id}')
                #print(f'granule.granule_id: {granule.granule_id}')

            # Ensure we don't have to deal with pagination by using a page size well above our max granule batch size and telling it page 1.
            payload_parameters = {
                #"collection_concept_id":            collection_concept_id,      # "C2497387766-CSDA",  // This is WV01
                "collection_concept_id[]":          collection_concept_id_list,     # Found out that we CAN pass multiple Collection Concept IDs in to this request.
                "granule_ur[]":                     granule_id_list,                # List of Granule IDs, 500 max (the actual limit is higher, closer to 2000, but 500 is safe)
                "page_num":                         1,                          
                "page_size":                        2000                        
            }

            # Base URL for the reqeust
            base_url = CMRRequestManager.get_CMR_GRANULES_URL()

            # Make the Post Request
            response = requests.post(
                base_url, 
                data=payload_parameters
            )

            # Check to see if we got a response where we have to wait (HTTP 429 error with retry headers)
            if(response.status_code == 429):
                print(f'CMR API Request got a 429 response.  Checking for retry timer.')
                print(f'  Reponse Headers: {response.headers}')

                # Detecting the Retry-After
                retry_after = float(response.headers.get("Retry-After", 5))
                did_have_a_retry_after = False
                if(retry_after == 5.0):
                    print(f'  Retry-After NOT detected.  Using the default of 5 seconds.')

                # How long to wait until next API Reqeust.  If we got a message back with an exact amount, Adding 100 ms just to buffer it some.
                sleep_time = retry_after + 0.1 

                print(f'  Sleeping for {sleep_time} before next request.  Also returning blank json response for this request.')
                time.sleep(sleep_time)

                # Set the flag to tell us that there was an error with the API
                has_api_error = True

                # Returning a blank object, so this batch will get tried again later.
                return {}, has_api_error

            # Capture the return JSON
            ret_response_json = response.json()

        except Exception as e:
            print(f'send_CMR_API_Post_Request_For_Granule_Batch: ERROR - While Trying to make the API Request.  Error Info: {e}')
            #return '{}'  # Actual Empty response looks like this: response.json:  {'hits': 0, 'took': 15, 'items': []}
            # Set the flag to tell us that there was an error with the API
            has_api_error = True
            return {}, has_api_error

        return ret_response_json, has_api_error
    
    def run_HC_Test_03__Multiple_Post():
        print(f'run_HC_Test_03__Multiple_Post(): Started')
        print(f'')
        print(f'')

        # Simulating the params I would need and/or have access to in this context
        db_name_key             = "WV01"
        collection_concept_id   = "C2497387766-CSDA"            # Lookup table for these, for all collections. 

        # For this test, this is numbers 20 through 29 in my local SQLite WV01.db
        granule_id_list = [
            "WV01_20171119060931_102001006BB20B00_17NOV19060931-P1BS-501699587090_03_P032",
            "WV01_20171119060932_102001006BB20B00_17NOV19060932-P1BS-501699587090_03_P033",
            "WV01_20171119060933_102001006BB20B00_17NOV19060933-P1BS-501699587090_03_P034",
            "WV01_20171119060934_102001006BB20B00_17NOV19060934-P1BS-501699587090_03_P035",
            "WV01_20171119060934_102001006BB20B00_17NOV19060934-P1BS-501699587090_03_P036",
            "WV01_20171119060940_102001006896C100_17NOV19060940-P1BS-501699587090_03_P019",
            "WV01_20171119060941_102001006896C100_17NOV19060941-P1BS-501699587090_03_P020",
            "WV01_20171119060942_102001006896C100_17NOV19060942-P1BS-501699587090_03_P021",
            "WV01_20171119060943_102001006896C100_17NOV19060943-P1BS-501699587090_03_P022",
            "WV01_20171119060944_102001006896C100_17NOV19060944-P1BS-501699587090_03_P023"
            # In the real version, this list will have up to 500 Granule Ids in it.
        ]

        # Testing Multiple Collection IDs in one request (saves a lot of trouble with parsing things)
        # WV01_Pan_L1B      #       C2497387766-CSDA
        # WV01_Pan_L2A      #       C2520285535-CSDA
        #
        collection_concept_id__LIST = ['C2497387766-CSDA', 'C2520285535-CSDA']
        #collection_concept_id__LIST = ['C2497387766-CSDA'] # WV01_Pan_L1B ONLY
        #collection_concept_id__LIST = ['C2520285535-CSDA'] # WV01_Pan_L2A ONLY     # returned: response.json:  {'hits': 0, 'took': 15, 'items': []}
        

        # Load up the post request
        payload_parameters = {
            #"collection_concept_id":            collection_concept_id,      # "C2497387766-CSDA",  // This is WV01
            "collection_concept_id[]":          collection_concept_id__LIST,      # "C2497387766-CSDA",  // This is WV01
            "granule_ur[]":                     granule_id_list,            # List of Granule IDs, 500 max (the actual limit is higher, closer to 2000, but 500 is safe)
            "page_num":                         1,
            "page_size":                        2000 #500

            # "bounding_box": "-179,-89,179,89",        # I think this param is actually optional
        }

        # # Headers
        # headers = {
        #     "Accept": "application/json",
        #     "Client-Id": "csda-cmr-step1-test",
        #     "User-Agent": "csda-cmr-step1-test/1.0"
        # }

        # Base URL for the reqeust
        base_url = CMRRequestManager.get_CMR_GRANULES_URL()

        # Make the Post Request
        response = requests.post(
            base_url, 
            data=payload_parameters
        )
        
        # response = requests.get(
        #     CMRRequestManager.get_CMR_GRANULES_URL(),
        #     params=query_parameters, # data=form_data,
        #     #headers=headers,
        #     #timeout=(20, 120),
        # )

        response.raise_for_status()

        # return response
        print(f'------------------------------------------------------------------------------------')
        print(f'response.url:   {response.url}')        # What was the URL it used?
        print(f'')
        print(f'response:       {response}')            # response: <Response [200]>
        print(f'')
        print(f'response.json:  {response.json()}')     # response: 
        print(f'------------------------------------------------------------------------------------')

        # Output:   
        #       response.url:   https://cmr.earthdata.nasa.gov/search/granules.umm_json
        #       response:       <Response [200]>
        #       response.json:  {'hits': 10, 'took': 90, 'items': [{'meta': {'concept-type': 'granule', 'concept-id': 'G2744189357-CSDA',  .....
        






        print(f'')
        print(f'')
        print(f'run_HC_Test_03__Multiple_Post(): Reached the End')




    # Test to make a query with hardcoded values (proof of concept and scaffolding guide).
    def run_HC_Test_02__Simpler_Get():
        print(f'run_HC_Test_02__Simpler_Get(): Started')
        print(f'')
        print(f'')

        # # Working Query (no auth needed)
        # https://cmr.earthdata.nasa.gov/search/granules.umm_json?collection_concept_id=C2497387766-CSDA&bounding_box=-179,-89,179,89&GranuleUR=WV01_20171119060931_102001006BB20B00_17NOV19060931-P1BS-501699587090_03_P032&page_num=1&page_size=500
        
        # # Examining Params more closely
        # collection_concept_id:    C2497387766-CSDA            # This is WV01_Pan_L1B // Need to parse this out of WV01 Table by parsing our Granule ID and converting (need support function)
        # provider:                 CSDA                        # This value should ALWAYS be CSDA.
        # GranuleUR:                <Internal Granule ID>       # This is what is stored in the DB at the id level, last part of filenames up to where it starts becoming unique.

        # The info going into the reqeust
        query_parameters = {
            "collection_concept_id":    "C2497387766-CSDA",
            #"bounding_box":             "-179,-89,179,89",
            "GranuleUR":                "WV01_20171119060931_102001006BB20B00_17NOV19060931-P1BS-501699587090_03_P032",
            "page_num":                 1,
            "page_size":                500
        }

        # form_data: lis[tuple[str, str]] = [
        #     ("collection_concept_id",   "C2497387766-CSDA"),
        #     ("bounding_box",            "-179,-89,179,89"),    # Seems to be required, so increased to cover nearly the whole world.
        #     ("GranuleUR",               "WV01_20171119060931_102001006BB20B00_17NOV19060931-P1BS-501699587090_03_P032"),
        #     ("page_size",               "500"),
        #     ("page_number",             "1"),
        #
        #     #("provider",                "CSDA"),
        #     #("producer_granule_id[]",   "WV01_20171119060931_102001006BB20B00_17NOV19060931-P1BS-501699587090_03_P032"),
        #     #("temporal",                "2017-11-01T00:00:00Z,2017-11-20T23:59:59Z"),
        #     #("bounding_box",            "113,27,115,29"),
        #     #("options[producer_granule_id][ignore_case]", "false"),
        #     #("pretty", "true"),
        # ]

        # Add the 'downloadable' boolean param as well  -- Comment this out to do the First 'existance' Query, Uncomment for the second 'is_downloadable' query
        #form_data.append(("downloadable", "true"))


        # Headers
        headers = {
            #"Authorization": f"Bearer {edl_token}",
            #"Authorization": f"{edl_token}",
            "Accept": "application/json",
            "Client-Id": "csda-cmr-step1-test",
            "User-Agent": "csda-cmr-step1-test/1.0"
        }

        response = requests.get(
            CMRRequestManager.get_CMR_GRANULES_URL(),
            params=query_parameters, # data=form_data,
            #headers=headers,
            #timeout=(20, 120),
        )

        # response = requests.post(
        #     CMRRequestManager.get_CMR_GRANULES_URL(),
        #     data=form_data,
        #     headers=headers,
        #     timeout=(20, 120),
        # )
        

        response.raise_for_status()

        # return response
        print(f'------------------------------------------------------------------------------------')
        print(f'response.url:   {response.url}')        # What was the URL it used?
        print(f'')
        print(f'response:       {response}')            # response: <Response [200]>
        print(f'')
        print(f'response:       {response.json()}')     # response: 
        print(f'------------------------------------------------------------------------------------')

        # Output:   https://cmr.earthdata.nasa.gov/search/granules.umm_json?collection_concept_id=C2497387766-CSDA&bounding_box=-179%2C-89%2C179%2C89&GranuleUR=WV01_20171119060931_102001006BB20B00_17NOV19060931-P1BS-501699587090_03_P032&page_num=1&page_size=500
        # And a successful response:        response:       {'hits': 1, 'took': 63, 'items': [{'meta': {'concept-type': 'granule', 'concept-id': 'G2744189357-CSDA',  ......


        print(f'')
        print(f'')
        print(f'run_HC_Test_02__Simpler_Get(): Reached the End')

    # Test to make a query with hardcoded values (proof of concept and scaffolding guide).
    def run_HC_Test_01():
        print(f'run_HC_Test_01(): Started')

        # https://cmr.earthdata.nasa.gov/search/granules.json?collection_concept_id=C2497387766-CSDA&provider=CSDA
        # https://cmr.earthdata.nasa.gov/search/granules.json?collection_concept_id=C2497387766-CSDA&provider=CSDA&producer_granule_id=WV01_20171119060931_102001006BB20B00_17NOV19060931-P1BS-501699587090_03_P032&options[producer_granule_id][ignore_case]=false&page_size=1
        
        # # Examining Params more closely
        # collection_concept_id:    C2497387766-CSDA            # This is WV01_Pan_L1B // Need to parse this out of WV01 Table by parsing our Granule ID and converting (need support function)
        # provider:                 CSDA                        # This value should ALWAYS be CSDA.
        # producer_granule_id:      <Internal Granule ID>       # This is what is stored in the DB at the id level, last part of filenames up to where it starts becoming unique.

        # The info going into the reqeust
        form_data: lis[tuple[str, str]] = [
            ("collection_concept_id",   "C2497387766-CSDA"),
            ("provider",                "CSDA"),
            #("producer_granule_id[]",   "WV01_20171119060931_102001006BB20B00_17NOV19060931-P1BS-501699587090_03_P032"),
            ("GranuleUR",   "WV01_20171119060931_102001006BB20B00_17NOV19060931-P1BS-501699587090_03_P032"),


            ("bounding_box",            "113,27,115,29"),
            #("temporal",                "2017-11-01T00:00:00Z,2017-11-20T23:59:59Z"),

            #("options[producer_granule_id][ignore_case]", "false"),
            ("page_size", "500"),
            ("page_number", "1"),
            #("pretty", "true"),
        ]

        # Add the 'downloadable' boolean param as well  -- Comment this out to do the First 'existance' Query, Uncomment for the second 'is_downloadable' query
        form_data.append(("downloadable", "true"))

        #edl_token = get_or_create_edl_token(EARTHDATA_USERNAME, EARTHDATA_PASSWORD)
        #edl_token = get_or_create_edl_token()
        #edl_token = '<REMOVED>'


        # Headers
        headers = {
            #"Authorization": f"Bearer {edl_token}",
            #"Authorization": f"{edl_token}",
            "Accept": "application/json",
            "Client-Id": "csda-cmr-step1-test",
            "User-Agent": "csda-cmr-step1-test/1.0"
        }

        response = requests.post(
            CMRRequestManager.get_CMR_GRANULES_URL(),
            data=form_data,
            headers=headers,
            timeout=(20, 120),
        )
        response.raise_for_status()

        # return response
        print(f'response: {response}')  # response: <Response [200]>
        print(f'response: {response.json()}')  # response: 


        print(f'run_HC_Test_01(): Reached the End')
    pass



# END OF FILE