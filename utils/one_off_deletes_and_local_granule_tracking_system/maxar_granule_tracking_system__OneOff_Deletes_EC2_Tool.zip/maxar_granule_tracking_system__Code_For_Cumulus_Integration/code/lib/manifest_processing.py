# manifest_processing.py

import os
import shutil
from datetime import datetime, timedelta
import subprocess
import sys
import json 
import csv
import gzip
import time

# To interface with the Databases (Create, selections, etc)
class ManifestProcessing:

    SETTINGS__local_dir_path__manifest_processing_root      = 'gts_files_processing/'         # Local Directory that contains the manifest files downloaded and being processed
    SETTINGS__cache_full_manifest__is_load_from_cache       = True


    @staticmethod
    def get_date_timestamp_string():
        timestamp_string = datetime.utcnow().strftime("%Y_%m_%d__%H_%M")
        return timestamp_string

    # Creates a new run subdirectory and returns the name 'new_sub_dir_name'  // something like "run__2026_02_28__22_14"
    # Returns the name by itself 'run__2026_02_28__22_14' and the directory path 'gts_files_processing/run__2026_02_28__22_14'
    @staticmethod
    def create_new_run_directory():
        parent_dir = ManifestProcessing.SETTINGS__local_dir_path__manifest_processing_root  # 'gts_files_processing/'

        # Get the timestamp (for creating a new run dir)
        timestamp_str = ManifestProcessing.get_date_timestamp_string()

        # Create a new subdirectory name 
        new_sub_dir_name = f"run__{timestamp_str}"
        
        # Get the new name of the directory to create
        new_subdir_to_create = os.path.join(parent_dir, new_sub_dir_name)       # // "gts_files_processing/run__2026_02_28__22_14"

        # Check if the directory already exists
        if os.path.exists(new_subdir_to_create):
            print(f"The directory '{new_subdir_to_create}' already exists.")
        else:
            # Create the directory (and any missing parent directories)
            os.makedirs(new_subdir_to_create)
            print(f"Directory '{new_subdir_to_create}' created successfully.")

            # Now make all the expected subdirectorties.
            print(f'  create_new_run_directory: Creating expected subdirectories used by manifest processing')
            #print(f'    Directories where temp manifest files get downloaded and extracted')
            dir_path__manifests__MCP_CBA        = f'{new_subdir_to_create}/manifest_work_area/temp_manifest_files__MCP_CBA' 
            dir_path__manifests__MCP_CBA_DR     = f'{new_subdir_to_create}/manifest_work_area/temp_manifest_files__MCP_CBA_DR' 
            os.makedirs(dir_path__manifests__MCP_CBA,       exist_ok=True)
            os.makedirs(dir_path__manifests__MCP_CBA_DR,    exist_ok=True)
            print(f'  Created or Found dir: {dir_path__manifests__MCP_CBA}')
            print(f'  Created or Found dir: {dir_path__manifests__MCP_CBA_DR}')

            # Full Path to files
            # # manifest_work_area/cached_full_list_of_bucket_key_paths/complete__MCP_CBA.txt       # // Actually a csv file
            # # manifest_work_area/cached_full_list_of_bucket_key_paths/complete__MCP_CBA_DR.txt    # // Actually a csv file
            dir_path__manifest_cache        = f'{new_subdir_to_create}/manifest_work_area/cached_full_list_of_bucket_key_paths'
            os.makedirs(dir_path__manifest_cache,    exist_ok=True)
            print(f'  Created or Found dir: {dir_path__manifest_cache}')
            
            # Create more dirs?
        
        # # Ensure the output directory exists
        # os.makedirs(new_subdir_to_create, exist_ok=True)

        return new_sub_dir_name, new_subdir_to_create

    # returns False and None if no subdirectories are found.
    # Example return when directories exist: True, gts_files_processing/run_1
    # Example return when No directories exist: True, gts_files_processing/run_1
    @staticmethod
    def get_most_recent_run_directory_path():

        search_path = ManifestProcessing.SETTINGS__local_dir_path__manifest_processing_root
        # Get a list of full paths for all subdirectories
        subdirs = [
            os.path.join(search_path, d) 
            for d in os.listdir(search_path) 
            if os.path.isdir(os.path.join(search_path, d))
        ]

        # Get the most recently created directory
        if subdirs:
            latest_subdir = max(subdirs, key=os.path.getctime)
            print(f"Most recent directory found: {latest_subdir}")
            return True, latest_subdir 
        else:
            print("No subdirectories found.")
            return False, None
        
        return False, None

    @staticmethod
    def delete_temp_manifest_processing_files():
        parent_dir = ManifestProcessing.SETTINGS__local_dir_path__manifest_processing_root  # 'gts_files_processing/'

        # Delete Protection - Make sure the string is what is expected.
        if(parent_dir != 'gts_files_processing/'):
            print(f'delete_temp_manifest_processing_files: ERROR: DELETE PROTECTION HIT.  We were expecting a parent_dir with the value: "gts_files_processing/".  Instead, parent_dir is: {parent_dir}.  Please correct this in the settings part of the code and try again!')
            print(f'Returning without deleting anything.')
            return

        # Iterate over every item inside parent_dir  'gts_files_processing/'
        for item in os.listdir(parent_dir):
            # Construct the full path ('gts_files_processing/subdir1')
            item_path = os.path.join(parent_dir, item)
            
            # Check if the item is a directory
            if os.path.isdir(item_path):
                try:
                    # Recursively delete the subdirectory and its contents
                    print(f'About to delete: item_path: {item_path}')
                    shutil.rmtree(item_path)
                    print(f"Deleted: {item_path}")
                except Exception as e:
                    print(f"Error deleting {item_path}: {e}")



    # Function to either continue the most recent run or start a new one (if a directory is not found)   (this uses get_most_recent_run_directory_path and create_new_run_directory)
    @staticmethod
    def continue_existing__or__start_new_run():

        is_new_run = False
        current_run_dir_path = ""
        # get_most_recent_run_directory_path
        # create_new_run_directory

        # Try to find the most recent run path
        print(f'Looking for an existing run...')
        is_found_subdir, current_run_dir_path = ManifestProcessing.get_most_recent_run_directory_path()
        if(is_found_subdir == False):
            # If no path was found, create a new one.
            print(f'Did not find an existing run.  About to create a new one.')
            new_run_sub_dir_name, new_run__sub_dir_path = ManifestProcessing.create_new_run_directory()
            
            is_new_run = True
            current_run_dir_path = new_run__sub_dir_path
            return is_new_run, current_run_dir_path
        if(is_found_subdir == True):
            # If we did find the path..
            print(f'Found Existing Run {current_run_dir_path}.  Continuing from here')

            is_new_run = False
            #current_run_dir_path = // Already set when trying to get the most recent run directory path..
            return is_new_run, current_run_dir_path
        
        return is_new_run, current_run_dir_path


    # ########################
    # # Helpers
    # ########################
    

    # Check to see if a file already exists or not.
    # Ported Over
    @staticmethod
    def does_local_file_already_exist(local_file_path=""):
        return os.path.exists(local_file_path)

    # Download a file from S3
    # Ported Over
    #def download_file_from_s3(bucket, file_key, local_file_path, aws_profile_string, skip_download_if_exists=False):
    @staticmethod
    def download_file_from_s3(bucket, file_key, local_file_path, skip_download_if_exists=False):
        is_skip_download = False
        if(skip_download_if_exists == True):
            # Only download the file if it does not already exist.
            #local_file_already_exists = does_local_file_already_exist(local_file_path=local_file_path)
            local_file_already_exists = ManifestProcessing.does_local_file_already_exist(local_file_path=local_file_path)
            if(local_file_already_exists == False):
                is_skip_download = False

            else:
                print("  Already found a local file at: " + str(local_file_path))
                is_skip_download = True
        else:
            is_skip_download = False

        if(is_skip_download == False):
            print(f"  Now Downloading file: s3://{bucket}/{file_key}")
            #command = f"aws s3 cp s3://{bucket}/{file_key} {local_file_path} --profile {aws_profile_string}"
            command = f"aws s3 cp s3://{bucket}/{file_key} {local_file_path}"
            subprocess.run(command, shell=True, check=True)
        else:
            print(f"    Skipping Download for: s3://{bucket}/{file_key}")

    # Open a JSON file and read it.
    # Ported Over
    @staticmethod
    def read_json_file(file_path):
        with open(file_path, 'r') as file:
            return json.load(file)

    # This function gunzips a file, then reads it's contents, and appends the filename to the list that was passed in.
    # csv_headers_list=[], , output_file_path=""
    # Note: We may also need the bucket name (which is in column called, "Bucket")  // So columns we may need, "Key", "Bucket"
    # Ported Over
    @staticmethod
    def open_gziped_csv_file(gzip_file_path="", csv_headers_list=[], file_name_col_name="Key", file_name_list=[]): 
        
        # gunzip the file and Read the file
        with gzip.open(gzip_file_path, 'rt', encoding='utf-8') as f_in:
            reader = csv.reader(f_in)
            for row in reader:
                # Map the headers to the row items
                row_dict = dict(zip(csv_headers_list, row))

                # For each filename found, append it to the list.
                #current_file_name = row_dict['Key'] # csv_line                                                     # Example:      WV02<path/to/specific/granule>-BROWSE.jpg
                #
                # Refactor - we need a bucketname AND a file name (in a CSV format)
                current_bucket_name = row_dict['Bucket'] # csv_line
                current_key_path = row_dict['Key'] # csv_line
                
                # Storing this as a CSV type Row with two columns: bucket_name and key_path
                current_bucket_and_key_path__str = '"'+str(current_bucket_name)+'","'+str(current_key_path)+'"'     # Example:      "<prod-granule-bucket-name>","WV02<path/to/specific/granule>-BROWSE.jpg"

                #file_name_list.append(current_file_name)
                file_name_list.append(current_bucket_and_key_path__str)
                #data.append(row_dict)

        # Return the filenames list 
        return file_name_list

    # save__processed_manifest_file__all_file_names_list(full_file_path=settings__cache_full_manifest__file_path, string_array_to_save=file_names_list__OLD_NGAP_PROD)
    # Ported Over
    @staticmethod
    def save__processed_manifest_file__all_file_names_list(full_file_path="", string_array_to_save=[]):
        
        # Create directory if it does not exist

        # Save each line to a an output file
        with open(full_file_path, 'w') as output_file:
            # Iterate each line in the list. 
            for line_to_write in string_array_to_save:
                # Write the line and a newline char ('\n') at the end
                output_file.write(line_to_write+'\n')
        print("  save__processed_manifest_file__all_file_names_list: File saved to: " + str(full_file_path))

    @staticmethod
    def save__processed_manifest_file__partial_file_names_list(full_file_path="", string_array_to_save=[]):
        
        # Counter
        lines_written = 0
        lines_skipped = 0

        # Save each line to a an output file
        # Using 'a' to create or append to the file
        with open(full_file_path, 'a') as output_file:
            # Iterate each line in the list. 
            for line_to_write in string_array_to_save:

                # Note, this is highly optimized, only writing lines that contain 'thumb.jpg'
                if 'thumb.jpg' in line_to_write:
                    # Write the line and a newline char ('\n') at the end
                    output_file.write(line_to_write+'\n')
                    #
                    # Increment the counter
                    lines_written = lines_written + 1
                else:
                    # Increment the line skipper
                    lines_skipped = lines_skipped + 1
        total_lines = lines_written + lines_skipped
        print("  save__processed_manifest_file__partial_file_names_list: File saved to: " + str(full_file_path))
        print(f'    Wrote: {lines_written} Lines.  Skipped: {lines_skipped}.  Total: {total_lines}.  (Note: only thumb.jpg lines were written)')

        return lines_written, lines_skipped, total_lines

    # load__processed_manifest_file__all_file_names_list(full_file_path=settings__cache_full_manifest__file_path)
    # Ported Over
    @staticmethod
    def load__processed_manifest_file__all_file_names_list(full_file_path=""):
        input_list = []
        lines_read_counter = 0
        # Open the file
        with open(full_file_path, 'r') as file:
            # Iterate each line of the file
            for line in file:
                # Add each line to the list
                input_list.append(line.strip())
                lines_read_counter = lines_read_counter + 1
        
        return input_list, lines_read_counter


    # Function for processing a manifest file
    # Function for downloading a manifest file, reading it's contents, then downloading all the gzipped_csv files, then reading those and ending up with a list of filenames
    # process_manifest_file__get_file_names_list(human_readable_name_of_process="Processing CBA PROD",      s3_bucket_name=bucket_name__CBA_PROD,       s3_path_to_manifist_json_file=s3_key_path_to_manifest_json_file__CBA_PROD,      local_file_path_for_manifest_json=local_full_file_path_manifest_json__CBA_PROD,     aws_profile_string=aws_profile__CBA_PROD,       local_dir_path_for_temp_files=local_dir_path_for_temp_files)
    # process_manifest_file__get_file_names_list(human_readable_name_of_process="Processing CBA DR PROD",   s3_bucket_name=bucket_name__CBA_DR_PROD,    s3_path_to_manifist_json_file=s3_key_path_to_manifest_json_file__CBA_DR_PROD,   local_file_path_for_manifest_json=local_full_file_path_manifest_json__CBA_DR_PROD,  aws_profile_string=aws_profile__CBA_DR_PROD,    local_dir_path_for_temp_files=local_dir_path_for_temp_files)
    # def process_manifest_file__get_file_names_list(human_readable_name_of_process="", s3_bucket_name="", s3_path_to_manifist_json_file="", local_file_path_for_manifest_json="", aws_profile_string="", local_dir_path_for_temp_files=""):
    # Ported Over
    # This new param: is_write_list_while_downloading=True means that as a csv file is processed, instead of just adding it to a growing list, that growing list is written to the output text file (create or append) and then saved to disk, while the growing list gets flushed.
    @staticmethod
    def process_manifest_file__get_file_names_list(human_readable_name_of_process="", s3_bucket_name="", s3_path_to_manifist_json_file="", local_file_path_for_manifest_json="", local_dir_path_for_temp_files="", local__cache_full_manifest__file_path="", is_write_list_while_downloading=True):
        
        # Counters (Only for the setting that writes as we go)
        # rtrn lines_written, lines_skipped, total_lines
        write_as_we_go__lines_written = 0
        write_as_we_go__lines_skipped = 0
        write_as_we_go__total_lines = 0

        # The list of file names to be returned
        ret_file_names_list = []

        # The list of multiple files found in the manifest.json file.  Each one needs to be individually downloaded and processed.
        gz_csv_manifest_file_list = []

        # Download the manifest File from S3
        print(str(human_readable_name_of_process) + ":  About to download the manifest.json file.")
        #
        # Removing this block -- this only made sense when I was running this locally and tweaking settings in between runs.
        #download_file_from_s3(bucket=s3_bucket_name,   file_key=s3_path_to_manifist_json_file,         local_file_path=local_file_path_for_manifest_json,      aws_profile_string=aws_profile_string,      skip_download_if_exists=False)
        # if(settings__does_already_have_root_manifest_file == True):
        #     print(f'{human_readable_name_of_process}:  Setting for skipping downloading of root manifest file is set to True.  Local File: {local_file_path_for_manifest_json}, should already exist.')
        # else:
        #     #download_file_from_s3(bucket=s3_bucket_name,    file_key=s3_path_to_manifist_json_file,         local_file_path=local_file_path_for_manifest_json,      aws_profile_string=aws_profile_string,      skip_download_if_exists=False)
        #     download_file_from_s3(bucket=s3_bucket_name,    file_key=s3_path_to_manifist_json_file,         local_file_path=local_file_path_for_manifest_json,      skip_download_if_exists=False)
        ManifestProcessing.download_file_from_s3(bucket=s3_bucket_name,    file_key=s3_path_to_manifist_json_file,         local_file_path=local_file_path_for_manifest_json,      skip_download_if_exists=True)

        # Read the manifest.json file
        print(str(human_readable_name_of_process) + ":  About to read file: " +str(local_file_path_for_manifest_json)+ " into an object and get the list of the next files to download.")
        manifest_JSON = ManifestProcessing.read_json_file(local_file_path_for_manifest_json)
        #
        # Iterate the 'files' key to find a list of all gz csv files.
        for item in manifest_JSON['files']:
            gz_csv_manifest_file_list.append(item['key'])  
            # Example Filename:     # '<path/to/manifest/root>/data/aaaa8b23-1234-47cf-abcd-897cb687f3bb.csv.gz'
        #print("   (gz_csv_manifest_file_list): " + str(gz_csv_manifest_file_list)) # ['<path/to/manifest/root>/data/aaaa8b23-1234-47cf-94f2-897cb687f3bb.csv.gz', '<path/to/manifest/root>/data/88888888-1234-4eb2-bae7-3c48c1884aca.csv.gz']

        # print("Get the csv header (column names)")
        csv_header_as_str   = manifest_JSON['fileSchema']                   # This gives a list like this: "header1, header2, header3"
        csv_header_list     = [item.strip() for item in csv_header_as_str.split(',')]   # This result should be: ["header1", "header2", "header3"]


        print(f'')
        print(f'{human_readable_name_of_process}:  From Manifest: (csv_header_as_str): {csv_header_as_str}')
        print(f'{human_readable_name_of_process}:  From Manifest: (csv_header_list):   {csv_header_list}')
        print(f'')
        

        # Iterate each file, download it locally, unzip, and read for the file names.
        process_coutner = 1   # Starting with 1 for ease of logging outputs
        len__num_of_gzip_files_to_process = len(gz_csv_manifest_file_list)
        #
        print(str(human_readable_name_of_process) + ":  About to download and process individual csv.gz files.")
        for gz_csv_file in gz_csv_manifest_file_list:
            local_file_name = gz_csv_file.split('/')[-1]
            local_file_full_file_path = str(local_dir_path_for_temp_files) + str(local_file_name)

            print("    Now Processing gzip csv: " + str(process_coutner) + " out of " + str(len__num_of_gzip_files_to_process) + ".  local_file_path: " + str(local_file_full_file_path))

            # Removing this block -- this only made sense when I was running this locally and tweaking settings in between runs.
            # #print("        DOWNLOAD THIS FILE ")
            # #download_file_from_s3(bucket=s3_bucket_name,   file_key=gz_csv_file,       local_file_path=local_file_full_file_path,      aws_profile_string=aws_profile_string,      skip_download_if_exists=True)
            # if(settings__does_already_have_ALL_csv_gz_files_downloaded == True):
            #     print(f'{human_readable_name_of_process}:  Setting for skipping downloading of all csv_gz_files is set to True.  Local File: {local_file_full_file_path}, should already exist.')
            # else:
            #     #download_file_from_s3(bucket=s3_bucket_name,    file_key=gz_csv_file,       local_file_path=local_file_full_file_path,      aws_profile_string=aws_profile_string,      skip_download_if_exists=True)
            #     download_file_from_s3(bucket=s3_bucket_name,    file_key=gz_csv_file,       local_file_path=local_file_full_file_path,      skip_download_if_exists=True)
            ManifestProcessing.download_file_from_s3(bucket=s3_bucket_name,    file_key=gz_csv_file,       local_file_path=local_file_full_file_path,      skip_download_if_exists=True)

            #print("        OPEN THIS FILE AND EXTRACT THE CONTENTS")
            


            #print("About to process gzip file " + str(process_coutner) + " out of " + str(len__num_of_gzip_files_to_process))
            
            # Read the file contents and extract the file names
            #ret_file_names_list = open_gziped_csv_file(gzip_file_path=local_file_full_file_path, csv_headers_list=csv_header_list, file_name_col_name="Key", file_name_list=ret_file_names_list)
            #ret_file_names_list = open_gziped_csv_file(gzip_file_path=local_file_full_file_path, csv_headers_list=csv_header_list, file_name_col_name="Key", file_name_list=ret_file_names_list)
            ret_file_names_list = ManifestProcessing.open_gziped_csv_file(gzip_file_path=local_file_full_file_path, csv_headers_list=csv_header_list, file_name_col_name="Key", file_name_list=ret_file_names_list)
            #
            print(f'{human_readable_name_of_process}:  Current Lenght of (ret_file_names_list) is: {len(ret_file_names_list)}.')
            print(f'')
            #
            if(is_write_list_while_downloading == True):
                print(f'{human_readable_name_of_process}:  The setting to write the list as we go (is_write_list_while_downloading) is set to True.  About to dump the text file so far: ')
                current__lines_written, current__lines_skipped, current__total_lines = ManifestProcessing.save__processed_manifest_file__partial_file_names_list(full_file_path=local__cache_full_manifest__file_path, string_array_to_save=ret_file_names_list)
                #
                # Flush the list, so the memory can be reused
                ret_file_names_list = [] 

                # Increment the larger counters
                write_as_we_go__lines_written = write_as_we_go__lines_written + current__lines_written
                write_as_we_go__lines_skipped = write_as_we_go__lines_skipped + current__lines_skipped
                write_as_we_go__total_lines   = write_as_we_go__total_lines   + current__total_lines
            #
            process_coutner = process_coutner + 1
            
            # DEBUG - Skip after 2 files
            # if (process_coutner > 2):
            #   break;
        
        print(f'')
        print(f'process_manifest_file__get_file_names_list: Counter Results: process_coutner: {process_coutner}')
        if(is_write_list_while_downloading == True):
            print(f'    Total for All csv Files: write_as_we_go__lines_written: {write_as_we_go__lines_written}')
            print(f'    Total for All csv Files: write_as_we_go__lines_skipped: {write_as_we_go__lines_skipped}')
            print(f'    Total for All csv Files: write_as_we_go__total_lines:   {write_as_we_go__total_lines}')
        print(f'')

        # Return the file names
        return ret_file_names_list


    

    # Do a full Download (Files that have already been downloaded should be skipped)
    @staticmethod
    def exec__manifest_to_bucket_key_process__Do_Full_Download(utc_date_string="", key_prefix__manifest_json="", local_dir_path_for_temp_files="", local_file_name_manifest="", local__cache_full_manifest__file_path="", bucket_name__MANIFEST_SRC=""):
        # Key only, not the bucket name, just the dir path (without the left slash at the beginning of the string)
        s3_key_path_to_manifest_json_file = f"{key_prefix__manifest_json}{utc_date_string}T01-00Z/manifest.json"

        # Where are we storing these files locally? -- The dir path and file name may be needed separatly later.
        local_full_file_path_manifest_json   = str(local_dir_path_for_temp_files) + str(local_file_name_manifest)

        # This allows the system to write the files as it goes.  This is necessary for very large manifests or machines with not enough RAM to handle the entire list at once.
        is_write_list_while_downloading = True

        print(f'About to attempt download of manifest files with these settings')
        print(f'  utc_date_string:                       {utc_date_string}')
        print(f'  s3_key_path_to_manifest_json_file:     {s3_key_path_to_manifest_json_file}')
        print(f'  local_full_file_path_manifest_json:    {local_full_file_path_manifest_json}')
        print(f"About to attempt to download the manifest and all of it's files, extract, iterate and read in order to generate the list we need for future steps.  This process may take a while...")

        file_names_list      = []
        file_names_list      = ManifestProcessing.process_manifest_file__get_file_names_list(human_readable_name_of_process="Processing MCP_CBA_DR",        s3_bucket_name=bucket_name__MANIFEST_SRC,       s3_path_to_manifist_json_file=s3_key_path_to_manifest_json_file,         local_file_path_for_manifest_json=local_full_file_path_manifest_json,        local_dir_path_for_temp_files=local_dir_path_for_temp_files,      local__cache_full_manifest__file_path=local__cache_full_manifest__file_path, is_write_list_while_downloading=is_write_list_while_downloading)

        print(f"")
        print(f"The complete manifest bucket and keypath names list has been loaded from processing.  Now saving a cached copy at: " + str(local__cache_full_manifest__file_path))
        print(f"")
        len__file_names_list = len(file_names_list)
        if(len__file_names_list == 0):
            print(f'... It looks like the file_names_list is empty.  This happens if the files were already written as they were downloaded and opened.  Skipping the final save now (as the file should already exist and be filled out at: {local__cache_full_manifest__file_path})')
        else:
            ManifestProcessing.save__processed_manifest_file__all_file_names_list(full_file_path=local__cache_full_manifest__file_path, string_array_to_save=file_names_list)

        print(f"")
        #print(f'exec__manifest_to_bucket_key_process__Do_Full_Download Completed.')
        print(f'  The manifest bucket and keypath names list has been Saved to: {local__cache_full_manifest__file_path}   Load as needed for the next step!')
        print(f"")

        print("For Quick Verification --- outputing the first item on the list of filenames")
        print("")
        try:
            #for file_name in file_names_list:
            print("  file_names_list[0]: " + str(file_names_list[0]))         # Example: "<prod-granule-bucket-name>","<path/to/specific/granule>-BROWSE.jpg"
        except:
            error_type, error_value, _ = sys.exc_info()
            print(f'')
            print(f"exec__manifest_to_bucket_key_process__Do_Full_Download: Uncaught Error When trying to output the files_names_list first line for verification.  The next thing to do is to check and see if that file was actually written to!\n\n   -- Sys Error Info: Error Type: {error_type}, Error Value: {error_value}")
            print(f'')


    # Do a full Download (Files that have already been downloaded should be skipped)
    # Params
    # local__cache_full_manifest__file_paths_list__path // This is the location of the text file that contains the granules paths.
    # # That file contains a large list where each line looks like this: 
    # # # "<prod-dr-granule-bucket-name>","<path/to/specific/granule>-thumb.jpg"
    # Simillar param from other function: local__cache_full_manifest__file_path
    #
    # This param: local__cache_full_manifest__granule_ids_text_file__path
    # # This is the location where a textfile of only granule IDs will live.
    # # This is the granule IDs that are from their confirmed source (PROD or PROD_DR).  The directory name should specify which one it is.
    # # # At the end of this function, this path is where the list of granule ids will live.
    @staticmethod
    def exec__get_granule_ids_from_file_names_list(local__file_path__full_manifest_list="", local__file_path__granule_ids="", local__file_path__last_granule_id=""):
        #def exec__get_granule_ids_from_file_names_list(local__cache_full_manifest__file_paths_list__path="", local__cache_full_manifest__granule_ids_text_file__path=""):
        # - Open the large list of granule ids
        # # - Consider a way to stream each line, and keep track of which line was last executed. (maybe write that to a temp file, so we can resume if this process crashes)
        # - Write the Granule IDs list
        # FUTURE OPTIMIZATION, Is there a way to sort the manifest by date created, or only get a manifest of when files were created, or have the manifest include that column?
        # # Use the 'last modified' field to handle this.


        is_resume                   = False
        can_continue                = False
        last_granule_id             = ""
        temp_file_path              = local__file_path__last_granule_id
        manifest_file_path          = local__file_path__full_manifest_list
        granule_list_output_path    = local__file_path__granule_ids
        #
        counter__lines_read                 = 0
        counter__lines_skipped              = 0
        counter__lines_saved_path_1st       = 0
        counter__lines_saved_path_resumed   = 0


        # check to see if the temp file exists already.
        if os.path.exists(temp_file_path):
            with open(temp_file_path, 'r', encoding='utf-8') as f:
                top_line = f.readline().strip()

                if(top_line == "completed"):
                    print(f'The temp file is showing the string "completed".  It looks like we have already read all the granules!  Exiting Process now')
                    return
                else:
                    #elif(top_line.strip() != ""):
                    if not top_line.strip():
                        # String is blank, do nothing
                        pass
                    else:
                        # String is not blank, and it's not 'completed', so this must be a granule ID
                        last_granule_id = top_line.strip()
                        is_resume = True
                        # The top line is NOT Blank, we assume this is a granule ID.
                        print(f'It looks like we are resuming a run.  The last Granule ID parsed was: {last_granule_id}')
        
        # Open in append mode
        def append_granule_to_granule_list(granule_id_line):
            with open(granule_list_output_path, 'a', encoding='utf-8') as f:
                #f.write(granule_id_line + '\n')
                f.write(granule_id_line)
        
        # Open in 'w' mode so this file can keep getting overwritten and reused.
        def update_last_granule_id_temp_file(granule_id_line):
            with open(temp_file_path, 'w', encoding='utf-8') as f:
                f.write(granule_id_line)

        # Open the file
        
        with open(manifest_file_path, 'r') as file:
            for line in file:

                # Get the Granule ID
                # Convert from:         "bucket-name","path/to/granule/<granule_id>-file.extension"
                # To just:              <granule_id>
                granuleID = line.split(',')[1].split('/')[-1].replace('-thumb.jpg','').replace('"','')

                # Update the Lines Read Counter
                counter__lines_read = counter__lines_read + 1

                # Now Check and see if this is a fresh run - If it is a fresh run, just append the granule and save it!
                if(is_resume == False):
                    # Just append this granule id to the granule ID file
                    append_granule_to_granule_list(granule_id_line=granuleID)

                    # And replace the temp file with the Granule ID
                    update_last_granule_id_temp_file(granule_id_line=granuleID)

                    # Update the Lines Saved Counter (Original, First Path through the manifest file)
                    counter__lines_saved_path_1st = counter__lines_saved_path_1st + 1
                    
                else:
                    # We are resuming, check this granule to see if we are able to continue.
                    if(can_continue == False):
                        # Only Check this current granuleID against the one from the temp file.
                        if(granuleID.strip() == last_granule_id.strip()):
                            # We are finally caught up, the next granule ID is the next one to resume saving!
                            # Set can_continue to True so the next time around the loop, we will actually write the file!
                            can_continue = True

                        # Update the Lines Skipped Counter
                        counter__lines_skipped = counter__lines_skipped + 1

                    else:
                        # In this block, we are continuing with granules not yet seen.

                        # Just append this granule id to the granule ID file
                        append_granule_to_granule_list(granule_id_line=granuleID)

                        # And replace the temp file with the Granule ID
                        update_last_granule_id_temp_file(granule_id_line=granuleID)

                        # Update the Lines Saved Counter (resumed work, when I run this for a second time or if it needs to be resumed.)
                        counter__lines_saved_path_resumed = counter__lines_saved_path_resumed + 1

            # At the very end of all this, write 'complete' to the temp file, so we don't process the same list over and over again incase of failed automation configurations in the future. 
            update_last_granule_id_temp_file(granule_id_line='completed')

        print(f'exec__get_granule_ids_from_file_names_list: Process Finished.  Look for the Granules List File at: {local__file_path__granule_ids}')
        print(f'  Final Function Report')
        print(f'    counter__lines_read:                {counter__lines_read}')
        print(f'    counter__lines_skipped:             {counter__lines_skipped}')
        print(f'    counter__lines_saved_path_1st:      {counter__lines_saved_path_1st}')
        print(f'    counter__lines_saved_path_resumed:  {counter__lines_saved_path_resumed}')

        
        

        #last_line_processed = None

        pass



    # IMPORTANT, THIS IS THE NEXT PART
    # IMPORTANT, THIS IS THE NEXT PART
    # 
    # Pass in the Function which can be called to update the Granule ID to the Database
    @staticmethod
    def exec__update_database_for_each_granule_id(local__file_path__granule_ids="", local__file_path__last_granule_id__for_db_update="", manifest_column_name="", update_dynamoDB__callback_func=""):
        #(run_dir_path, local__file_path__full_manifest_list, local__file_path__granule_ids, local__file_path__last_granule_id)
        # def exec__get_granule_ids_from_file_names_list(local__file_path__full_manifest_list="", local__file_path__granule_ids="", local__file_path__last_granule_id=""):

        # Pass in SQLite Helper function for updating the Granule ID
        # Simillar 'last granule id' logic
        # Work way through the granule list, make a query for each one to update.
        # # Possible options to batch query (so maybe I can update a lot of records at one time?)
        # Make sure to time this function to see how long this takes.. this one may have to run for a long time to complete.

        # Timing this function
        time__start = time.perf_counter()

        # One of these runs, the manifest Granule_ID Count was: '31453326' // 31,453,326
        # Need to kind of time these to see how long it takes this code to execute.
        is_test_mode_on         = False
        test_mode_max_processes = 10000
        test_mode_counter       = 0

        # Periodic Output
        output_status_every_N_lines_read = 100000 # 100k loops, so about 314 intermediate outputs.
        #
        # Metrics
        # for 10,000 granules
        # # Before Adding Resume Logic  and  Before Adding DB Update Code         Execution Time: 0.001117 seconds.
        # # After  Adding Resume Logic  and  Before Adding DB Update Code         Execution Time: 0.423026 seconds.     // After skipping 10k lines: Execution Time: 0.541674 seconds.
        # # After  Adding Resume Logic  and  After  Adding DB Update Code         Execution Time: 16.830311 seconds.    // After skipping 10k lines: Execution Time: 17.627441 seconds.
        #
        # Math
        # 17.2 seconds for 10k means about: 0.00172 seconds per granule ID
        # 0.00172 seconds * 31,453,326 = about 54,100 seconds (54,099.7207).
        # 54,100 seconds is 901.7 minutes
        # 901.7 minutes is 15.03 hours


        # Let's get a report of how many rows were created and how many were updated (how many new rows do we have?)
        counter__how_many__new_db_rows_created      = 0
        counter__how_many__existing_db_rows_updated = 0

        # Some of this function is simillar to the last step -- the pause and resume logic is very simillar

        is_resume                   = False
        can_continue                = False
        last_granule_id             = ""
        temp_file_path              = local__file_path__last_granule_id__for_db_update  # local__file_path__last_granule_id
        granule_ids_file_path       = local__file_path__granule_ids                     #   manifest_file_path          = local__file_path__full_manifest_list
        #granule_list_output_path    = local__file_path__granule_ids
        #
        counter__lines_read                 = 0
        counter__lines_skipped              = 0
        counter__lines_saved_path_1st       = 0
        counter__lines_saved_path_resumed   = 0


        # check to see if the temp file exists already.
        if os.path.exists(temp_file_path):
            with open(temp_file_path, 'r', encoding='utf-8') as f:
                top_line = f.readline().strip()

                if(top_line == "completed"):
                    print(f'The temp file is showing the string "completed".  It looks like we have already read all the granules!  Exiting Process now')
                    return
                else:
                    #elif(top_line.strip() != ""):
                    if not top_line.strip():
                        # String is blank, do nothing
                        pass
                    else:
                        # String is not blank, and it's not 'completed', so this must be a granule ID
                        last_granule_id = top_line.strip()
                        is_resume = True
                        # The top line is NOT Blank, we assume this is a granule ID.
                        print(f'It looks like we are resuming a run.  The last Granule ID parsed was: {last_granule_id}')
        
        # # Open in append mode
        # def append_granule_to_granule_list(granule_id_line):
        #     with open(granule_list_output_path, 'a', encoding='utf-8') as f:
        #         #f.write(granule_id_line + '\n')
        #         f.write(granule_id_line)
        def upsert_sqlite_db_with_granule_id(granule_id_line):
            # This Function Call does the following
            # - Find a the row with this granule ID in it
            # - Update the flag (Might be PROD, or PROD_DR)
            # - If the row is not found, create a new row, and update the flag on that row.
            #
            # The Callback function is:     def update_or_create__manifest_column__by_granule_id(manifest_column_name, granule_id):
            is_created_new_row, is_updated_existing_row = update_dynamoDB__callback_func(manifest_column_name=manifest_column_name, granule_id=granule_id_line)  


            return is_created_new_row, is_updated_existing_row
        
        # Open in 'w' mode so this file can keep getting overwritten and reused.
        def update_last_granule_id_temp_file(granule_id_line):
            with open(temp_file_path, 'w', encoding='utf-8') as f:
                f.write(granule_id_line)

        # Open the file
        
        with open(granule_ids_file_path, 'r') as file:
            for line in file:

                # We assume the line we are reading IS the granule id.  It is a good idea in the future to validate this some how!
                granuleID = line.strip()

                # Update the Lines Read Counter
                counter__lines_read = counter__lines_read + 1

                if( (counter__lines_read % output_status_every_N_lines_read) == 0):
                    print(f'Progress: {counter__lines_read} lines read so far....', flush=True)

                # Now Check and see if this is a fresh run - If it is a fresh run, just append the granule and save it!
                if(is_resume == False):
                    # Upsert this granule into the DB (Create new row if no row is found, or Update the correct datetime flag column if the row is found)
                    is_created_new_row, is_updated_existing_row = upsert_sqlite_db_with_granule_id(granule_id_line=granuleID)
                    if(is_created_new_row == True):
                        counter__how_many__new_db_rows_created = counter__how_many__new_db_rows_created + 1
                    if(is_updated_existing_row == True):
                        counter__how_many__existing_db_rows_updated = counter__how_many__existing_db_rows_updated + 1

                    # And replace the temp file with the Granule ID
                    update_last_granule_id_temp_file(granule_id_line=granuleID)

                    # Update the Lines Saved Counter (Original, First Path through the manifest file)
                    counter__lines_saved_path_1st = counter__lines_saved_path_1st + 1

                    # TEST MODE CHECKPOINT
                    if(is_test_mode_on == True):
                        test_mode_counter = test_mode_counter + 1
                        if(test_mode_counter > test_mode_max_processes):
                            print(f'')
                            print(f'  -----')
                            print(f'TEST MODE:  Currently processed: {test_mode_counter}.  The Max is {test_mode_max_processes}.  Breaking out of the loop now.  Last Granule ID Processed was {granuleID}')
                            print(f'  -----')
                            print(f'')
                            break

                else:
                    # We are resuming, check this granule to see if we are able to continue.
                    if(can_continue == False):
                        # Only Check this current granuleID against the one from the temp file.
                        if(granuleID.strip() == last_granule_id.strip()):
                            # We are finally caught up, the next granule ID is the next one to resume saving!
                            # Set can_continue to True so the next time around the loop, we will actually write the file!
                            can_continue = True

                        # Update the Lines Skipped Counter
                        counter__lines_skipped = counter__lines_skipped + 1

                    else:
                        # In this block, we are continuing with granules not yet seen.

                        # Upsert this granule into the DB (Create new row if no row is found, or Update the correct datetime flag column if the row is found)
                        is_created_new_row, is_updated_existing_row = upsert_sqlite_db_with_granule_id(granule_id_line=granuleID)
                        if(is_created_new_row == True):
                            counter__how_many__new_db_rows_created = counter__how_many__new_db_rows_created + 1
                        if(is_updated_existing_row == True):
                            counter__how_many__existing_db_rows_updated = counter__how_many__existing_db_rows_updated + 1

                        # And replace the temp file with the Granule ID
                        update_last_granule_id_temp_file(granule_id_line=granuleID)

                        # Update the Lines Saved Counter (resumed work, when I run this for a second time or if it needs to be resumed.)
                        counter__lines_saved_path_resumed = counter__lines_saved_path_resumed + 1

                        # TEST MODE CHECKPOINT
                        if(is_test_mode_on == True):
                            test_mode_counter = test_mode_counter + 1
                            if(test_mode_counter > test_mode_max_processes):
                                print(f'')
                                print(f'  -----')
                                print(f'TEST MODE:  Currently processed: {test_mode_counter}.  The Max is {test_mode_max_processes}.  Breaking out of the loop now.  Last Granule ID Processed was {granuleID}')
                                print(f'  -----')
                                print(f'')
                                break

            # At the very end of all this, write 'complete' to the temp file, so we don't process the same list over and over again incase of failed automation configurations in the future. 
            update_last_granule_id_temp_file(granule_id_line='completed')

                # - Handle Resume Logic (See Previous Function Example)

                # - Determine which dataset this granule is attached to.
                # - Call the SQL Updating function, passing in which DB (dataset) and the Granule ID, and which flag (PROD, or PROD_DR)
                # # Note: Will need to parse the DataSet here in a clever way, but the PROD or PROD_DR part can be passed in at the higher level that calls this function, (this can be two separate SQL Wrapper functions -- and should be.)


                # update_or_create__manifest_column__by_granule_id  -   returns     -  is_created_new_row, is_updated_existing_row
                #counter__how_many__new_db_rows_created      = 0
                #counter__how_many__existing_db_rows_updated = 0

                # if(is_test_mode_on == True):
                #     test_mode_counter = test_mode_counter + 1
                #     if(test_mode_counter > test_mode_max_processes):
                #         print(f'')
                #         print(f'  -----')
                #         print(f'TEST MODE:  Currently processed: {test_mode_counter}.  The Max is {test_mode_max_processes}.  Breaking out of the loop now.  Last Granule ID Processed was {granuleID}')
                #         print(f'  -----')
                #         print(f'')
                #         break
                    
                


        print(f'exec__update_database_for_each_granule_id: Process Finished.  Look for the Granules List File at: {local__file_path__granule_ids}')
        print(f'  Final Function Report')
        print(f'    counter__lines_read:                {counter__lines_read}')
        print(f'    counter__lines_skipped:             {counter__lines_skipped}')
        print(f'    counter__lines_saved_path_1st:      {counter__lines_saved_path_1st}')
        print(f'    counter__lines_saved_path_resumed:  {counter__lines_saved_path_resumed}')
        #
        print(f'  DB Created or Update Report')
        print(f'    counter__how_many__new_db_rows_created:       {counter__how_many__new_db_rows_created}')
        print(f'    counter__how_many__existing_db_rows_updated:  {counter__how_many__existing_db_rows_updated}')

        # End of the function
        time__end       = time.perf_counter()
        time__duration  = time__end - time__start
        print(f'')
        print(f'  Execution Time: {time__duration:.6f} seconds.')
        print(f'')




    # Helper to convert to the day before the input day.  This is due to delay in manifest deliveries depending on what time of day this is run.
    @staticmethod
    def get_previous_day(date_str):
        # Parse string into a datetime object
        date_obj = datetime.strptime(date_str, '%Y-%m-%d')
        
        # Subtract one day using timedelta
        yesterday = date_obj - timedelta(days=1)
        
        # Format back to YYYY-MM-DD string
        return yesterday.strftime('%Y-%m-%d')

    @staticmethod
    def get_target_manifest_date_string_from(run_dir_path):
        # # This line converts a string that looks like 'gts_files_processing/run__2026_03_18__17_05' to '2026-03-18'
        #target_manifest_date_utc_string = run_dir_path.split("__")[-2].replace('_','-')
        run_date_utc_string = run_dir_path.split("__")[-2].replace('_','-')

        # Now Convert to Yesterday's Date (Because sometimes the manifests are not ready until the next day)
        target_manifest_date_utc_string = ManifestProcessing.get_previous_day(date_str=run_date_utc_string)

        return target_manifest_date_utc_string

    # ########################
    # # Download Manifests
    # ########################

    # Expected input:   run_dir_path = 'gts_files_processing/run__2026_03_18__17_05'
    @staticmethod
    def download_manifest_to_run_dir__PROD(run_dir_path):

        # If the run_dir_path was not passed in, then create a new run dir!
        if run_dir_path == None:
            is_new_run, run_dir_path = ManifestProcessing.continue_existing__or__start_new_run()

        #try:
        # Get the date variable from the run directory path name -- (so we know which manifest to get)
        target_manifest_date_utc_string = ManifestProcessing.get_target_manifest_date_string_from(run_dir_path=run_dir_path)

        # Local location of where the temp files will exist
        local_dir_path__manifests__MCP_CBA          = f'{run_dir_path}/manifest_work_area/temp_manifest_files__MCP_CBA/' 
        local_file_name_manifest__MCP_CBA           = f'manifest__MCP_CBA.json'

        # Local location of where the cached full manifest will live
        local__cache_full_manifest__file_path = f'{run_dir_path}/manifest_work_area/cached_full_list_of_bucket_key_paths/complete__MCP_CBA.txt'       # // Actually a csv file
        
        bucket_name__MANIFEST_SRC = "<manifest-bucket-name>"
        key_prefix__manifest_json = "<path/to/manifest/root>/"    # Next part is "<YYYY-MM-DD>T<HH-MM>Z"

        print(f'About to download and process the PROD Manifest')

        ManifestProcessing.exec__manifest_to_bucket_key_process__Do_Full_Download(utc_date_string=target_manifest_date_utc_string, key_prefix__manifest_json=key_prefix__manifest_json, local_dir_path_for_temp_files=local_dir_path__manifests__MCP_CBA, local_file_name_manifest=local_file_name_manifest__MCP_CBA, local__cache_full_manifest__file_path=local__cache_full_manifest__file_path, bucket_name__MANIFEST_SRC=bucket_name__MANIFEST_SRC)

        print(f'')
        print(f'exec__manifest_to_bucket_key_process__Do_Full_Download Completed.')
        print(f'')

        


    @staticmethod
    def download_manifest_to_run_dir__PROD_DR(run_dir_path):

        # If the run_dir_path was not passed in, then create a new run dir!
        if run_dir_path == None:
            is_new_run, run_dir_path = ManifestProcessing.continue_existing__or__start_new_run()

        try:
            # Get the date variable from the run directory path name -- (so we know which manifest to get)
            target_manifest_date_utc_string = ManifestProcessing.get_target_manifest_date_string_from(run_dir_path=run_dir_path)

            # Local location of where the temp files will exist
            local_dir_path__manifests__MCP_CBA_DR       = f'{run_dir_path}/manifest_work_area/temp_manifest_files__MCP_CBA_DR/'
            local_file_name_manifest__MCP_CBA_DR        = f'manifest__MCP_CBA_DR.json'

            # Local location of where the cached full manifest will live
            local__cache_full_manifest__file_path = f'{run_dir_path}/manifest_work_area/cached_full_list_of_bucket_key_paths/complete__MCP_CBA_DR.txt'       # // Actually a csv file

            bucket_name__MANIFEST_SRC = "<manifest-bucket-name>"
            key_prefix__manifest_json = "<path/to/manifest/root>/orca/"   # Next part is "<YYYY-MM-DD>T<HH-MM>Z"

            print(f'About to download and process the PROD_DR Manifest')

            ManifestProcessing.exec__manifest_to_bucket_key_process__Do_Full_Download(utc_date_string=target_manifest_date_utc_string, key_prefix__manifest_json=key_prefix__manifest_json, local_dir_path_for_temp_files=local_dir_path__manifests__MCP_CBA_DR, local_file_name_manifest=local_file_name_manifest__MCP_CBA_DR, local__cache_full_manifest__file_path=local__cache_full_manifest__file_path, bucket_name__MANIFEST_SRC=bucket_name__MANIFEST_SRC)

            
        except:
            error_type, error_value, _ = sys.exc_info()
            print(f'')
            print(f"download_manifest_to_run_dir__PROD_DR: Uncaught Error Downloading and/or processing the PROD_DR Manifest.\n\n   -- Sys Error Info: Error Type: {error_type}, Error Value: {error_value}")
            print(f'')


    # Getting the Granule IDs List from the large Manifests

    @staticmethod
    def convert_manifest_list_to_granule_ids(run_dir_path, local__file_path__full_manifest_list, local__file_path__granule_ids, local__file_path__last_granule_id):
        # If the run_dir_path was not passed in, then create a new run dir!
        if run_dir_path == None:
            is_new_run, run_dir_path = ManifestProcessing.continue_existing__or__start_new_run()

        # Timing this function
        time__start = time.perf_counter()

        ManifestProcessing.exec__get_granule_ids_from_file_names_list(local__file_path__full_manifest_list=local__file_path__full_manifest_list, local__file_path__granule_ids=local__file_path__granule_ids, local__file_path__last_granule_id=local__file_path__last_granule_id)

        # End of the function
        time__end       = time.perf_counter()
        time__duration  = time__end - time__start
        print(f'')
        print(f'  Execution Time: {time__duration:.6f} seconds.  (convert_manifest_list_to_granule_ids)')
        print(f'')
        

    @staticmethod
    def convert_manifest_list_to_granule_ids__PROD(run_dir_path):
        # If the run_dir_path was not passed in, then create a new run dir!
        if run_dir_path == None:
            is_new_run, run_dir_path = ManifestProcessing.continue_existing__or__start_new_run()

        # Local location of where the cached full manifest file lives -- this is the list that needs to be converted to Granule IDs
        local__file_path__full_manifest_list    = f'{run_dir_path}/manifest_work_area/cached_full_list_of_bucket_key_paths/complete__MCP_CBA.txt'

        # Local location of where the List of Granule IDs will live
        local__file_path__granule_ids           = f'{run_dir_path}/manifest_work_area/cached_full_list_of_bucket_key_paths/MCP_CBA__GranuleIds_List.txt'

        # Local location of where the temp file that stores the last processed granule ID lives.
        local__file_path__last_granule_id       = f'{run_dir_path}/manifest_work_area/cached_full_list_of_bucket_key_paths/MCP_CBA__Last_Granule_ID.txt'

        # Call the function which calls the one that does the work.
        ManifestProcessing.convert_manifest_list_to_granule_ids(run_dir_path=run_dir_path, local__file_path__full_manifest_list=local__file_path__full_manifest_list, local__file_path__granule_ids=local__file_path__granule_ids, local__file_path__last_granule_id=local__file_path__last_granule_id)

    @staticmethod
    def convert_manifest_list_to_granule_ids__PROD_DR(run_dir_path):
        # If the run_dir_path was not passed in, then create a new run dir!
        if run_dir_path == None:
            is_new_run, run_dir_path = ManifestProcessing.continue_existing__or__start_new_run()

        # Local location of where the cached full manifest file lives -- this is the list that needs to be converted to Granule IDs
        local__file_path__full_manifest_list   = f'{run_dir_path}/manifest_work_area/cached_full_list_of_bucket_key_paths/complete__MCP_CBA_DR.txt'

        # Local location of where the List of Granule IDs will live
        local__file_path__granule_ids           = f'{run_dir_path}/manifest_work_area/cached_full_list_of_bucket_key_paths/MCP_CBA_DR__GranuleIds_List.txt'

        # Local location of where the temp file that stores the last processed granule ID lives.
        local__file_path__last_granule_id       = f'{run_dir_path}/manifest_work_area/cached_full_list_of_bucket_key_paths/MCP_CBA_DR__Last_Granule_ID.txt'

        # Call the function which calls the one that does the work.
        ManifestProcessing.convert_manifest_list_to_granule_ids(run_dir_path=run_dir_path, local__file_path__full_manifest_list=local__file_path__full_manifest_list, local__file_path__granule_ids=local__file_path__granule_ids, local__file_path__last_granule_id=local__file_path__last_granule_id)
        

    # Updating the DB

    @staticmethod
    def update_database_for_each_granule_id__PROD(run_dir_path, manifest_column_name, update_dynamoDB__callback_func):
        # If the run_dir_path was not passed in, then create a new run dir!
        if run_dir_path == None:
            is_new_run, run_dir_path = ManifestProcessing.continue_existing__or__start_new_run()

        # Local location of where the List of Granule IDs lives (If this file does not exist, then the process before this should be run first.)
        local__file_path__granule_ids                       = f'{run_dir_path}/manifest_work_area/cached_full_list_of_bucket_key_paths/MCP_CBA__GranuleIds_List.txt'

        # Local location of where the temp file that stores the last processed granule ID lives.
        local__file_path__last_granule_id__for_db_update    = f'{run_dir_path}/manifest_work_area/cached_full_list_of_bucket_key_paths/MCP_CBA__Last_Granule_ID__For_DB_Updates.txt'

        # SET MORE VARS HERE?

        # Call the function that does the work.
        ManifestProcessing.exec__update_database_for_each_granule_id(local__file_path__granule_ids=local__file_path__granule_ids, local__file_path__last_granule_id__for_db_update=local__file_path__last_granule_id__for_db_update, manifest_column_name=manifest_column_name, update_dynamoDB__callback_func=update_dynamoDB__callback_func)
        
        #pass
        #exec__update_database_for_each_granule_id(local__file_path__granule_ids="", local__file_path__last_granule_id__for_db_update="")

    @staticmethod
    def update_database_for_each_granule_id__PROD_DR(run_dir_path, manifest_column_name, update_dynamoDB__callback_func):
        #def update_database_for_each_granule_id__PROD_DR(run_dir_path):
        
        # If the run_dir_path was not passed in, then create a new run dir!
        if run_dir_path == None:
            is_new_run, run_dir_path = ManifestProcessing.continue_existing__or__start_new_run()

        # Local location of where the List of Granule IDs lives (If this file does not exist, then the process before this should be run first.)
        local__file_path__granule_ids           = f'{run_dir_path}/manifest_work_area/cached_full_list_of_bucket_key_paths/MCP_CBA_DR__GranuleIds_List.txt'

        # Local location of where the temp file that stores the last processed granule ID lives.
        local__file_path__last_granule_id__for_db_update    = f'{run_dir_path}/manifest_work_area/cached_full_list_of_bucket_key_paths/MCP_CBA_DR__Last_Granule_ID__For_DB_Updates.txt'

        # SET MORE VARS HERE?

        # Call the function that does the work.
        ManifestProcessing.exec__update_database_for_each_granule_id(local__file_path__granule_ids=local__file_path__granule_ids, local__file_path__last_granule_id__for_db_update=local__file_path__last_granule_id__for_db_update, manifest_column_name=manifest_column_name, update_dynamoDB__callback_func=update_dynamoDB__callback_func)
        
        #pass
        #exec__update_database_for_each_granule_id(local__file_path__granule_ids="", local__file_path__last_granule_id__for_db_update="")
    


    






# END OF FIlE