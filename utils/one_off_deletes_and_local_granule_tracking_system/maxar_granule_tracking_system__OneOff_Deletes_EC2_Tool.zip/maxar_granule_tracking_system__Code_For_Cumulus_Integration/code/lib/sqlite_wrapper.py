# sqlite_wrapper.py
from __future__ import annotations

# List of DB Names (top level config)
#FILE_CONFIG__DB_NAMES_TUPLE = ("WV01", "WV02", "WV03", "WV04", "GE01")
#FILE_CONFIG__DB_NAMES_TUPLE = ("WV01", "WV02", "WV03", "WV04", "GE01", "IK01", "OV03")
# Leaving off IK01 and OV03 for now because their dynamoDB structures are a little bit different. Eventually, we will add these.


# DBs
# WV01, WV02, WV03, WV04, GE01, IK01, OV03 // The WV01 DB Covers all WV01 Datasets (WV01_L1B, WV01_Pan, etc) - true for all of these database types

# Columns on the Shared Schema
#
# // IMPORTANT -- REMEMBER, For Now, THESE Local DB TABLES ARE FOR DELETE TRACKING..
# DB: Example Name: "WV04"      (or all DBs really, just using WV04 as an example)
#   DynamoDB_Key__file_path                 String      <SIZE PATH NAME (500 chars?)>   // Comes from DynamoDB table read field: 'file_path'
#   DynamoDB_Contents                       String      <SIZE JSON DOC>                 // Everything from a single DynamoDB record row (the internal)
#   MCP_Rep_Granule_KeyPath                 String      <SIZE PATH NAME (500 chars?)>   // Representatitve Granule Keypath (to one of the files) // Comes from the MCP Manifest from bucket "<delivery-bucket-name>", after filtering down
#   NGAP_CBA_PROD_Rep_Granule_KeyPath       String      <SIZE PATH NAME (500 chars?)>   // Representatitve Granule Keypath (to one of the files) // Comes from the NGAP CBA PROD Manifest from bucket "<prod-bucket-name>", after filtering down
#   NGAP_CBA_DR_PROD_Rep_Granule_KeyPath    String      <SIZE PATH NAME (500 chars?)>   // Representatitve Granule Keypath (to one of the files) // Comes from the NGAP CBA DR PROD Manifest (ORCA) from bucket "<prod-orca-bucket-name>", after filtering down
#   Granule_ID                              String      <SIZE Partial Path Name ()>     // Get this from either path, filtering backwards!
#
#   // This is tracking the 4 check boxes
#   // // Decided to Change all these boolean columns to datetimes.  Null Value means False, DateTime means it True and was last observed at the datetime.
#   is_in_NGAP_PROD                         Datetime (Treated lightly as a Bool)    // Did we find this Granule in NGAP PROD
#   is_in_NGAP_DR_PROD                      Datetime (Treated lightly as a Bool)    // Did we find this Granule in NGAP DR PROD (ORCA)
#   is_found_at_EarthData_PROD              Datetime (Treated lightly as a Bool)    // Need to learn how to query this PROPERLY CMR
#   is_in_metrics_PROD                      Datetime (Treated lightly as a Bool)    // Never got an answer to how to check this
#   //
#   //
#   is_deleted_from_MCP_delivery            Datetime (Treated lightly as a Bool)    // Tracking if we have already deleted from MCP Delivery Bucket     // File Not Found means this column gets a 1 or a YES
#   is_deleted_from_MCP_dynamoDB            Datetime (Treated lightly as a Bool)    // Tracking if we have already deleted from DynamoDB                // DynamoDB Lookup and key not found means this column gets a 1 or a YES
#
#   created_at          // When was this record created
#   updated_at          // When was this record last updated
#
#   granule_status, String,     # Future Column, granule_status, String, maybe even an enum column if we move this to RDS and use it for more than just deletes.

# Some Notes about how this system functions
# Since some items have already been deleted from the delivery bucket and dynamoDB, when this DB is filled out, there will be nulls.
# The idea here is to track items that are in DynamoDB and delivery bucket, and then after a full ingest happens, delete those items from the DynamoDB AND the original delivery bucket (once ingested and verified, the delivery versions are no longer needed)

# Python level imports -- dataclasses and typing should give functions a bit more context.
from dataclasses import dataclass   
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple, Union

# Imports for SQLAlchemy
from sqlalchemy import Column, Integer, String, Index, DateTime, create_engine, event, func, select, text, update
from sqlalchemy.engine import Engine
from sqlalchemy.orm import declarative_base, Session, mapped_column, sessionmaker
#from sqlalchemy_utils import database_exists, create_database
from sqlalchemy.inspection import inspect

import json
import sys


base_db_path = "gts_sqliteDBs"

Base = declarative_base()

# The Granule Data Model
class Granule(Base):
    __tablename__ = "granule"
    
    # A simple unique ID that counts number of items
    id = Column(Integer, primary_key=True)

    # This must have a value and must be Unique!
    granule_id = Column(String, nullable=False, unique=True, index=True)
    
    # Created At column logs the timestamp when the granule was first created, updated_at will get a new timestamp each time the recrod is updated
    created_at = Column(DateTime, nullable=False, server_default=func.current_timestamp(), index=True)
    updated_at = Column(DateTime, nullable=False, server_default=func.current_timestamp(), onupdate=func.current_timestamp(), index=True)

    # Columns to keep track of what was in the original DynamoDB entry
    DynamoDB_Key__file_path = Column(String, nullable=True, index=True)
    DynamoDB_Contents = Column(String, nullable=True)

    # The key paths to a single file in each environment
    # Note: It is not necessary to store the DR path since it will be a duplicate of the PROD path, and there is already a flag that shows if we have it or not.
    MCP_Rep_Granule_KeyPath = Column(String, nullable=True, index=True)
    NGAP_CBA_PROD_Rep_Granule_KeyPath = Column(String, nullable=True, index=True)
    #NGAP_CBA_DR_PROD_Rep_Granule_KeyPath = Column(String, nullable=True)

    # These are the flags, originally BOOL type, but changed to Datetime
    # a Null Value can be interpreted as a False value, where a time stamp means True AND gives you the info of When the flag was set/observed!
    is_in_NGAP_PROD                 = Column(DateTime, nullable=True, index=True)
    is_in_NGAP_DR_PROD              = Column(DateTime, nullable=True, index=True)
    is_found_at_EarthData_PROD      = Column(DateTime, nullable=True, index=True)
    is_in_metrics_PROD              = Column(DateTime, nullable=True, index=True)
    #
    is_deleted_from_MCP_delivery    = Column(DateTime, nullable=True, index=True)
    is_deleted_from_MCP_dynamoDB    = Column(DateTime, nullable=True, index=True)

    # # Comments on CMR checking columns and how they are used.
    # The CMR API is queried in batches (hundreds of granules at a time)
    # First a batch is selected and quered for existance ('cmr_found_at').  
    # # This updates if each of the granules were observed in the CMR record
    # For any granules from that first CMR API Request that were observed, they go into a list to be queried again.
    # # This second CMR API query is to see if these granules are downloadable or not ('cmr_downloadable_at').
    # # If some of the granules from the first batch were not found, then this second CMR API request may be a smaller batch than the first one.  The second batch is a subset of equal or smaller size than the first batch.
    # # any granules that have a download link in their CMR record will get an update to 'cmr_downloadable_at'.
    # This is the nuanced part.  The columns for checking and retrying CMR Queries ('cmr_last_attempt_at' and 'num_of_attempts_cmr_check') are only related to the first API Request.  
    # This lets us later get a clean report of granules that are in the CMR but are not reachable, which means we would have to do some kind of metadata level repair or S3 batch operation to fix.

    # New Columns AFTER running one-off migration - def run__one_time_migration__2026_Jul_28__Add_CMR_And_Tracking_Cols
    #
    # --- New Columns Added Below ---
    last_attempt_MCP_delete             = Column(DateTime, nullable=True, index=True)
    last_attempt_MCP_dynamoDB_delete    = Column(DateTime, nullable=True, index=True)
    #
    num_of_attempts_MCP_s3_delete           = Column(Integer, nullable=False, server_default="0", index=True)
    num_of_attempts_MCP_dynamoDB_delete     = Column(Integer, nullable=False, server_default="0", index=True)
    #
    #
    cmr_checked_at          = Column(DateTime, nullable=True, index=True)
    cmr_found_at            = Column(DateTime, nullable=True, index=True)
    cmr_downloadable_at     = Column(DateTime, nullable=True, index=True)
    #
    cmr_concept_id          = Column(String, nullable=True, index=True)
    #
    num_of_attempts_cmr_check   = Column(Integer, nullable=False, server_default="0", index=True)
    cmr_last_attempt_at         = Column(DateTime, nullable=True, index=True)
    cmr_last_error              = Column(String, nullable=True, index=True)
    
    # def to_dict(obj):
    #     mapper = inspect(obj.__class__)
    #     data = {}
    #     for column in mapper.columns:
    #         data[column.key] = getattr(obj, column.key)
    #     return data

    # def to_string(obj):
    #     return ", ".join(f"{k}={v}" for k, v in to_dict(obj).items())

    def to_dict(self):
        mapper = inspect(self.__class__)
        return {c.key: getattr(self, c.key) for c in mapper.columns}

    def __repr__(self):
        # Optional: a nicer representation
        props = ", ".join(f"{k}={v}" for k, v in self.to_dict().items())
        return f"<MyClass {props}>"


# To interface with the Databases (Create, selections, etc)
class DatabaseManager:

    @staticmethod
    def get_all_db_engine_config():
        # DB Names
        DB_CONFIGS = {
            "WV01": f"sqlite:///{base_db_path}/WV01.db",
            "WV02": f"sqlite:///{base_db_path}/WV02.db",
            "WV03": f"sqlite:///{base_db_path}/WV03.db",
            "WV04": f"sqlite:///{base_db_path}/WV04.db",
            "GE01": f"sqlite:///{base_db_path}/GE01.db",
            "DEFAULT": f"sqlite:///{base_db_path}/default.db",
        }
        return DB_CONFIGS

    # Usage Example: 
    # engines = DatabaseManager.initialize_databases()
    @staticmethod
    def initialize_databases():
        
        # Get the list of possible DB Engines
        DB_CONFIGS = DatabaseManager.get_all_db_engine_config()

        engines = {}

        for name, uri in DB_CONFIGS.items():
            engine = create_engine(uri)
            
            # Create the SQLIte database if it doesn't exist
            # Requires 'sqlalchemy-utils' package
            #if not database_exists(engine.url):
            #    create_database(engine.url)
            #    print(f"Created database: {uri}")

            # Create the granule table defined in Base.  
            # Placing this here places the same schema inside every database.
            Base.metadata.create_all(engine)

            # Was better to put this in the 'onupdate' function.
            # This DB trigger should make sure that the updated_at column changes anytime there is an UPDATE
            # with engine.begin() as conn:
            #     conn.execute(
            #         text(
            #             """
            #             CREATE TRIGGER IF NOT EXISTS trg_granule_updated_at
            #             AFTER UPDATE ON granule
            #             FOR EACH ROW
            #             BEGIN
            #               UPDATE granule
            #               SET updated_at = CURRENT_TIMESTAMP
            #               WHERE id = NEW.id;
            #             END;
            #             """
            #         )
            #     )

            # Now I can access each database/engine by it's friendly name (like WV01, etc)
            engines[name] = engine
            
        return engines

    # Get Session
    @staticmethod
    def get_session_for_db_name_key(db_name_key="DEFAULT"):
        DB_CONFIGS = DatabaseManager.get_all_db_engine_config()
        target_engine_uri = DB_CONFIGS[db_name_key]
        target_engine = create_engine(target_engine_uri)
        Session = sessionmaker(bind=target_engine)
        return Session

    # Add a new Granule (just need the granule id)
    @staticmethod
    def add_new_granule(db_name_key="DEFAULT", granule_id="default_granule_id"):
        
        # Get the session
        Session = DatabaseManager.get_session_for_db_name_key(db_name_key=db_name_key)

        try:
            with Session() as session:
                # Create record (omitting nullable columns automatically sets them to NULL)
                new_granule = Granule(granule_id=granule_id) 
                #new_granule = Granule(**{'granule_id':granule_id}) 
                
                session.add(new_granule)
                session.commit()
                #print(f"Created record with ID: {new_granule.id}")
        except:
            print(f'Error adding a new granule {granule_id}.  ')
     
    # Updates a single column for a specific record in a specific database   
    @staticmethod
    def update_string_granule_field_by_granule_id(db_name_key="DEFAULT", granule_id="default_granule_id", column_name="COL", new_value="VAL"):
        
        # Get the session
        Session = DatabaseManager.get_session_for_db_name_key(db_name_key=db_name_key)

        with Session() as session:
            stmt = (
                update(Granule)
                .where(Granule.granule_id == granule_id)
                .values({column_name: new_value, "updated_at": func.current_timestamp()})
            )
            record  = session.execute(stmt)
            session.commit()

            # Returns how many rows are effected.
            return int(record.rowcount or 0)

            # # Find the record by ID
            # stmt    = select(Granule).where(Granule.granule_id == granule_id)
            # record  = session.execute(stmt).scalar_one_or_none()
            #
            # if record:
            #     # Dynamically set the column value
            #     setattr(record, column_name, new_value)
            #     session.commit()
            #     #print(f"Updated {db_name_key}.Granule.{column_name} with value: {new_value}")
            # else:
            #     print(f"Record {db_name_key}.Granule.granule_id: {granule_id} not found.")

    

    @staticmethod
    def update_datetime_granule_field_by_granule_id(db_name_key="DEFAULT", granule_id="default_granule_id", column_name="COL"):
        # Get the session
        Session = DatabaseManager.get_session_for_db_name_key(db_name_key=db_name_key)

        with Session() as session:
            stmt = (
                update(Granule)
                .where(Granule.granule_id == granule_id)
                .values({column_name: func.current_timestamp(), "updated_at": func.current_timestamp()})
            )
            record  = session.execute(stmt)
            session.commit()

            # Returns how many rows are effected.
            return int(record.rowcount or 0)

    
    # # CMR Related Field Definitions (Reference)
    # cmr_checked_at          = Column(DateTime, nullable=True, index=True)
    # cmr_found_at            = Column(DateTime, nullable=True, index=True)
    # cmr_downloadable_at     = Column(DateTime, nullable=True, index=True)
    # #
    # cmr_concept_id          = Column(String, nullable=True, index=True)
    # #
    # num_of_attempts_cmr_check   = Column(Integer, nullable=False, server_default="0", index=True)
    # cmr_last_attempt_at         = Column(DateTime, nullable=True, index=True)
    # cmr_last_error              = Column(String, nullable=True, index=True)

    # Update Paths Reference
    #update_paths_log_obj['update_path_count__Local_Granule_Found_in_CMR']
    #update_paths_log_obj['update_path_count__Local_Granule_NOT_Found_in_CMR']
    #update_paths_log_obj['update_path_count__NEW_Granule_Found_in_CMR']

    # CMR Update Path: NEW Granule was found in the CMR that does NOT exist in our DB - Creating a new entry to catch it
    # # rows_affected = DatabaseManager.create__new_granule__from_found_in_CMR(db_name_key="DEFAULT", granule_id="default_granule_id", cmr_concept_id="UNKNOWN", is__cmr_downloadable=True)
    # # # update_paths_log_obj['update_path_count__NEW_Granule_Found_in_CMR']
    @staticmethod
    def create__new_granule__from_found_in_CMR(db_name_key="DEFAULT", granule_id="default_granule_id", cmr_concept_id="UNKNOWN", is__cmr_downloadable=True):
        # # Fields to Update:
        # granule_id                    = Column(String, nullable=False, unique=True, index=True)
        # is_found_at_EarthData_PROD    = Column(DateTime, nullable=True, index=True)
        # cmr_found_at                  = Column(DateTime, nullable=True, index=True)
        # cmr_downloadable_at           = Column(DateTime, nullable=True, index=True)
        # cmr_concept_id                = Column(String, nullable=True, index=True)
        # cmr_last_attempt_at           = Column(DateTime, nullable=True, index=True)
        # # 
        # Granule.is_found_at_EarthData_PROD
        # Granule.cmr_found_at
        # Granule.cmr_downloadable_at
        # Granule.cmr_concept_id
        # Granule.cmr_last_attempt_at

        # .values({"is_found_at_EarthData_PROD": func.current_timestamp(), "cmr_concept_id": cmr_concept_id, "cmr_found_at": func.current_timestamp(), "cmr_downloadable_at": func.current_timestamp(), "cmr_last_attempt_at": func.current_timestamp(), "updated_at": func.current_timestamp()})

        # Get the session
        Session = DatabaseManager.get_session_for_db_name_key(db_name_key=db_name_key)

        try:
            with Session() as session:
                if (is__cmr_downloadable == True):
                    # Create record (omitting nullable columns automatically sets them to NULL)
                    new_granule = Granule(
                        granule_id=granule_id,
                        is_found_at_EarthData_PROD=func.current_timestamp(),
                        cmr_checked_at=func.current_timestamp(),
                        cmr_found_at=func.current_timestamp(),
                        cmr_downloadable_at=func.current_timestamp(),
                        cmr_concept_id=cmr_concept_id,
                        cmr_last_attempt_at=func.current_timestamp()
                    ) 
                    session.add(new_granule)
                    session.commit()
                    #print(f"Created record with ID: {new_granule.id}")
                    return 1
                else:
                    # Create record (omitting nullable columns automatically sets them to NULL)
                    new_granule = Granule(
                        granule_id=granule_id,
                        is_found_at_EarthData_PROD=func.current_timestamp(),
                        cmr_checked_at=func.current_timestamp(),
                        cmr_found_at=func.current_timestamp(),
                        cmr_concept_id=cmr_concept_id,
                        cmr_last_attempt_at=func.current_timestamp()
                    ) 
                    session.add(new_granule)
                    session.commit()
                    #print(f"Created record with ID: {new_granule.id}")
                    return 1
        except:
            print(f'Error adding a new found in the CMR and not in our local DB.  granule {granule_id}.  ')

        # If we got to this part, something went wrong so 0 rows were affected.
        return 0 

    # CMR Update Path: Granule was NOT found in the CMR but does exist in our DB
    # # rows_affected = DatabaseManager.update__existing_granule__was_NOT_found_in_CMR(db_name_key="DEFAULT", granule_id="default_granule_id", num_of_attempts_cmr_check=1)
    # # # update_paths_log_obj['update_path_count__Local_Granule_NOT_Found_in_CMR']
    @staticmethod
    def update__existing_granule__was_NOT_found_in_CMR(db_name_key="DEFAULT", granule_id="default_granule_id", num_of_attempts_cmr_check=1):
        # # Fields to Update:
        # cmr_checked_at                = Column(DateTime, nullable=True, index=True)
        # num_of_attempts_cmr_check     = Column(Integer, nullable=False, server_default="0", index=True)
        # cmr_last_attempt_at           = Column(DateTime, nullable=True, index=True)
        # # 
        # Granule.cmr_checked_at
        # Granule.num_of_attempts_cmr_check
        # Granule.cmr_last_attempt_at

        # Get the session
        Session = DatabaseManager.get_session_for_db_name_key(db_name_key=db_name_key)

        with Session() as session:
            stmt = (
                    update(Granule)
                    .where(Granule.granule_id == granule_id)
                    .values({"cmr_checked_at": func.current_timestamp(), "num_of_attempts_cmr_check": num_of_attempts_cmr_check, "cmr_last_attempt_at": func.current_timestamp(), "updated_at": func.current_timestamp()})
            )
            record  = session.execute(stmt)
            session.commit()

            # Returns how many rows are effected.
            return int(record.rowcount or 0)

        pass

    # CMR Update Path: Granule was found in the CMR and exists in our DB
    # # rows_affected = DatabaseManager.update__granule__was_found_in_CMR(db_name_key="DEFAULT", granule_id="default_granule_id", cmr_concept_id="UNKNOWN", is__cmr_downloadable=True)
    # # # update_paths_log_obj['update_path_count__Local_Granule_Found_in_CMR']
    @staticmethod
    def update__granule__was_found_in_CMR(db_name_key="DEFAULT", granule_id="default_granule_id", cmr_concept_id="UNKNOWN", is__cmr_downloadable=True):
        # # Fields to Update:
        # is_found_at_EarthData_PROD    = Column(DateTime, nullable=True, index=True)
        # cmr_found_at                  = Column(DateTime, nullable=True, index=True)
        # cmr_downloadable_at           = Column(DateTime, nullable=True, index=True)
        # cmr_concept_id                = Column(String, nullable=True, index=True)
        # # 
        # Granule.is_found_at_EarthData_PROD
        # Granule.cmr_found_at
        # Granule.cmr_downloadable_at
        # Granule.cmr_concept_id

        # Get the session
        Session = DatabaseManager.get_session_for_db_name_key(db_name_key=db_name_key)

        # Do the update inside the session
        with Session() as session:
            if (is__cmr_downloadable == True):
                stmt = (
                    update(Granule)
                    .where(Granule.granule_id == granule_id)
                    .values({"cmr_checked_at": func.current_timestamp(), "is_found_at_EarthData_PROD": func.current_timestamp(), "cmr_concept_id": cmr_concept_id, "cmr_found_at": func.current_timestamp(), "cmr_downloadable_at": func.current_timestamp(), "cmr_last_attempt_at": func.current_timestamp(), "updated_at": func.current_timestamp()})
                )
                record  = session.execute(stmt)
                session.commit()

                # Returns how many rows are effected.
                return int(record.rowcount or 0)
            else:
                stmt = (
                    update(Granule)
                    .where(Granule.granule_id == granule_id)
                    .values({"cmr_checked_at": func.current_timestamp(), "is_found_at_EarthData_PROD": func.current_timestamp(), "cmr_concept_id": cmr_concept_id, "cmr_found_at": func.current_timestamp(), "cmr_last_attempt_at": func.current_timestamp(), "updated_at": func.current_timestamp()})
                )
                record  = session.execute(stmt)
                session.commit()

                # Returns how many rows are effected.
                return int(record.rowcount or 0)





    # Deletes - Update Queries - Update Attempts
    # Deletes - Update Queries - Update Deleted Status

    # Update Granule was deleted or attempted to be deleted 
    #@staticmethod
    #def update__granule__was_attempted_to_delete(db_name_key="DEFAULT", granule_id="default_granule_id", is_deleted__from_s3=False, is_deleted__from_dynamo_db=False, new_num_attempts__s3=3, new_num_attempts__dynamoDB=3):
    @staticmethod
    def update__granule__was_attempted_to_delete(db_name_key="DEFAULT", granule_id_list=["default_granule_id"], is_deleted__from_s3=False, is_deleted__from_dynamo_db=False, new_num_attempts__s3=3, new_num_attempts__dynamoDB=3):
        # # Fields to Update:
        # is_deleted_from_MCP_delivery    = Column(DateTime, nullable=True, index=True)
        # is_deleted_from_MCP_dynamoDB    = Column(DateTime, nullable=True, index=True)
        #
        # last_attempt_MCP_delete             = Column(DateTime, nullable=True, index=True)
        # last_attempt_MCP_dynamoDB_delete    = Column(DateTime, nullable=True, index=True)
        # #
        # num_of_attempts_MCP_s3_delete           = Column(Integer, nullable=False, server_default="0", index=True)
        # num_of_attempts_MCP_dynamoDB_delete     = Column(Integer, nullable=False, server_default="0", index=True)
        # # 
        # Granule.is_deleted_from_MCP_delivery
        # ...
        # Get the session
        Session = DatabaseManager.get_session_for_db_name_key(db_name_key=db_name_key)

        # Do the update inside the session
        with Session() as session:

            # Both Deleted
            if ((is_deleted__from_s3 == True) and (is_deleted__from_dynamo_db == True)):
                stmt = (
                    update(Granule)
                    #.where(Granule.granule_id == granule_id)
                    .where(Granule.granule_id.in_(granule_id_list))  # granule_id_list is a Python list of up to 25 granule IDs
                    .values(
                        {
                            "is_deleted_from_MCP_delivery":         func.current_timestamp(), 
                            "is_deleted_from_MCP_dynamoDB":         func.current_timestamp(),

                            "last_attempt_MCP_delete":              func.current_timestamp(), 
                            "last_attempt_MCP_dynamoDB_delete":     func.current_timestamp(), 

                            "num_of_attempts_MCP_s3_delete":        new_num_attempts__s3,
                            "num_of_attempts_MCP_dynamoDB_delete":  new_num_attempts__dynamoDB,
                         
                            "updated_at": func.current_timestamp()
                        })
                )
                record  = session.execute(stmt)
                session.commit()

                # Returns how many rows are effected.
                return int(record.rowcount or 0)
            
            # Only S3 was deleted
            elif ((is_deleted__from_s3 == True) and (is_deleted__from_dynamo_db == False)):
                stmt = (
                    update(Granule)
                    #.where(Granule.granule_id == granule_id)
                    .where(Granule.granule_id.in_(granule_id_list))  # granule_id_list is a Python list of up to 25 granule IDs
                    .values(
                        {
                            "is_deleted_from_MCP_delivery":         func.current_timestamp(), 
                            #"is_deleted_from_MCP_dynamoDB":         func.current_timestamp(),

                            "last_attempt_MCP_delete":              func.current_timestamp(), 
                            "last_attempt_MCP_dynamoDB_delete":     func.current_timestamp(), 

                            "num_of_attempts_MCP_s3_delete":        new_num_attempts__s3,
                            "num_of_attempts_MCP_dynamoDB_delete":  new_num_attempts__dynamoDB,
                         
                            "updated_at": func.current_timestamp()
                        })
                )
                record  = session.execute(stmt)
                session.commit()

                # Returns how many rows are effected.
                return int(record.rowcount or 0)

            # Only DynamoDB was deleted
            elif ((is_deleted__from_s3 == False) and (is_deleted__from_dynamo_db == True)):
                stmt = (
                    update(Granule)
                    #.where(Granule.granule_id == granule_id)
                    .where(Granule.granule_id.in_(granule_id_list))  # granule_id_list is a Python list of up to 25 granule IDs
                    .values(
                        {
                            #"is_deleted_from_MCP_delivery":         func.current_timestamp(), 
                            "is_deleted_from_MCP_dynamoDB":         func.current_timestamp(),

                            "last_attempt_MCP_delete":              func.current_timestamp(), 
                            "last_attempt_MCP_dynamoDB_delete":     func.current_timestamp(), 

                            "num_of_attempts_MCP_s3_delete":        new_num_attempts__s3,
                            "num_of_attempts_MCP_dynamoDB_delete":  new_num_attempts__dynamoDB,
                         
                            "updated_at": func.current_timestamp()
                        })
                )
                record  = session.execute(stmt)
                session.commit()

                # Returns how many rows are effected.
                return int(record.rowcount or 0)

            # Neither deleted
            elif ((is_deleted__from_s3 == False) and (is_deleted__from_dynamo_db == False)):
                stmt = (
                    update(Granule)
                    #.where(Granule.granule_id == granule_id)
                    .where(Granule.granule_id.in_(granule_id_list))  # granule_id_list is a Python list of up to 25 granule IDs
                    .values(
                        {
                            #"is_deleted_from_MCP_delivery":         func.current_timestamp(), 
                            #"is_deleted_from_MCP_dynamoDB":         func.current_timestamp(),

                            "last_attempt_MCP_delete":              func.current_timestamp(), 
                            "last_attempt_MCP_dynamoDB_delete":     func.current_timestamp(), 

                            "num_of_attempts_MCP_s3_delete":        new_num_attempts__s3,
                            "num_of_attempts_MCP_dynamoDB_delete":  new_num_attempts__dynamoDB,
                         
                            "updated_at": func.current_timestamp()
                        })
                )
                record  = session.execute(stmt)
                session.commit()

                # Returns how many rows are effected.
                return int(record.rowcount or 0)

            # The 4 if statements above should catch all the path combos, but just incase they did not catch.. this should not update anything
            else:
                print(f'DEBUG Code Error: update__granule__was_attempted_to_delete: Last else block happened.  No Updates Happened.  Something may be wrong with the checking logic.  Look into this.')
                return 0

        # This code should not get reached.  This is a catch all.
        return 0
    

    # 122
    # Get Database rows of granules for a CMR API Call.
    # This selection is specifically looking for items that have not been verified, have not been tried to many times, are sorted by oldest first, and capped at a max number (function input param)
    # Also returns a list of only granule IDs
    @staticmethod
    def get_granules_for_cmr_API_call(db_name_key="DEFAULT", max_num_of_granules=2, max_retries=3):
        # Get the session
        Session = DatabaseManager.get_session_for_db_name_key(db_name_key=db_name_key)

        with Session() as session:
            results = (
                session.query(Granule)
                .filter(
                    Granule.cmr_found_at.is_(None),
                    #Granule.cmr_found_at.is_(None),        # If we need to add another dimension for selection
                    Granule.num_of_attempts_cmr_check < max_retries,
                )
                .order_by(Granule.num_of_attempts_cmr_check.asc())      # .asc() sorts the Lowest number of retries first
                .order_by(Granule.created_at.asc())                     # .asc() sorts then Oldest first // Trying to give every granule a chance to get cycled before retrying older ones.
                .order_by(Granule.cmr_last_attempt_at.asc())            # .asc() sorts then Oldest first // Trying to give every granule a chance to get cycled before retrying older ones.
                .limit(max_num_of_granules)
                .all()
            )

            # Handle the 0 rows case
            if not results:
                return None

            return results
        return None

    # 121
    # Helper to tell us how many granules are left in the database that fit the selection criteria
    @staticmethod
    def get_remaining_granule_count__for_cmr_API_call(db_name_key="DEFAULT", max_retries=3):
        ret_total_count = 0
        # Get the session
        Session = DatabaseManager.get_session_for_db_name_key(db_name_key=db_name_key)

        with Session() as session:
            # Rewriting this to be significantly more efficient
            ret_total_count = (
                session.query(func.count(Granule.id))  # Passing the primary key directly here
                .filter(
                    Granule.cmr_found_at.is_(None), # If this value is None, then we have not yet found this granule..
                    Granule.num_of_attempts_cmr_check < max_retries,
                )
                .scalar()  # Using .scalar() instead of .count() to get the raw integer
            )
            return ret_total_count

            # # .count() executes a SELECT COUNT(*) query directly on the database
            # total_count = (
            #     session.query(Granule)
            #     .filter(
            #         Granule.cmr_found_at.is_(None),
            #         Granule.num_of_attempts_cmr_check < max_retries,
            #     )
            #     .count()
            # )
            # #return total_count
            # ret_total_count = total_count
            # return ret_total_count

        return ret_total_count



    # # # # METRICS CONSTRUCTION                #           START
    # # # # METRICS CONSTRUCTION                #           START
    # # # # METRICS CONSTRUCTION                #           START

    

    # New Batch of Queries
    #
    # -Q1: Verified by all checkboxes (Prod Manifest, Prod ORCA Manifest, CMR API)
    #     -Q2: Same as Q1, but just the total count, no actual data returned other than counting how many are ready (make sure to NOT include the ones that were already deleted)
    # -Q3: Ready for Deletes (The same query, but with the extra field that says they have NOT already been deleted) - should be almost the same results at first, but after ALL deletes happen, then we may have 0 granules here but some granules on a previous query
    #     -Q4: Same as Q3, but just the total count, no actual data returned other than counting how many are ready (make sure to NOT include the ones that were already deleted)
    # -Q5: Granules that have been verified and deleted
    #    -Q6: Same as Q5, but just the total count, no actual data returned other than counting how many have actually been deleted (tracked)
    #
    # There is one more set of queries missing from here... check the main_interface and write the code to fit what those functions need.

    # (Q1) Select Granules Verified by all checkboxes (Prod Manifest, Prod ORCA Manifest, Exists in CMR API)
    @staticmethod
    def get_granules__Verified_By_Prod_Orca_And_CMR_API(db_name_key="DEFAULT", max_num_of_granules=2):
        # Get the session
        Session = DatabaseManager.get_session_for_db_name_key(db_name_key=db_name_key)

        with Session() as session:
            results = (
                session.query(Granule)
                .filter(
                    Granule.is_in_NGAP_PROD.isnot(None),
                    Granule.is_in_NGAP_DR_PROD.isnot(None),
                    Granule.is_found_at_EarthData_PROD.isnot(None),
                )
                .order_by(Granule.created_at.asc())                     # .asc() sorts then Oldest first // Trying to give every granule a chance to get cycled before retrying older ones.
                .limit(max_num_of_granules)
                .all()
            )

            # Handle the 0 rows case
            if not results:
                return None

            return results
        return None
        

    # (Q2) Count Granules that are Verified by all checkboxes (Prod Manifest, Prod ORCA Manifest, Exists in CMR API)
    # Note, this may include granules that have been already deleted.  This is a raw number of granules that satisfy the particular checkboxes.
    @staticmethod
    def get_count__Granules_Verified_By_Prod_Orca_And_CMR_API(db_name_key="DEFAULT"):
        ret_total_count = 0
        # Get the session
        Session = DatabaseManager.get_session_for_db_name_key(db_name_key=db_name_key)

        with Session() as session:
            ret_total_count = (
                session.query(func.count(Granule.id))  # Passing the primary key directly here
                .filter(
                    Granule.is_in_NGAP_PROD.isnot(None),
                    Granule.is_in_NGAP_DR_PROD.isnot(None),
                    Granule.is_found_at_EarthData_PROD.isnot(None),
                    #Granule.cmr_found_at.isnot(None), # If this value is NOT None, that means a CMR entry has been observed and recorded.
                )
                .scalar()  # Using .scalar() instead of .count() to get the raw integer
            )
            return ret_total_count

        return ret_total_count

    # 121 and 122 are above, used in other section

    # 123
    @staticmethod
    def get_granule_count__for_found_in_CMR(db_name_key="DEFAULT"):
        ret_total_count = 0
        # Get the session
        Session = DatabaseManager.get_session_for_db_name_key(db_name_key=db_name_key)

        with Session() as session:
            # Rewriting this to be significantly more efficient
            ret_total_count = (
                session.query(func.count(Granule.id))  # Passing the primary key directly here
                .filter(
                    Granule.cmr_found_at.isnot(None), # If this value is NOT None, then we HAVE found this granule..
                    #Granule.num_of_attempts_cmr_check < max_retries,
                )
                .scalar()  # Using .scalar() instead of .count() to get the raw integer
            )
            return ret_total_count

        return ret_total_count

    # 124
    @staticmethod
    def get_granules__That_Were_Found_in_CMR(db_name_key="DEFAULT", max_num_of_granules=2):
        # Get the session
        Session = DatabaseManager.get_session_for_db_name_key(db_name_key=db_name_key)

        with Session() as session:
            results = (
                session.query(Granule)
                .filter(
                    Granule.cmr_found_at.isnot(None), # If this value is NOT None, then we HAVE found this granule..
                    #Granule.cmr_found_at.isnot(None), # If this value is NOT None, that means a CMR entry has been observed and recorded.
                )
                .order_by(Granule.created_at.asc())                     # .asc() sorts then Oldest first // Trying to give every granule a chance to get cycled before retrying older ones.
                .limit(max_num_of_granules)
                .all()
            )

            # Handle the 0 rows case
            if not results:
                return None

            return results
        return None

    # 125 - Ready for deletes (Has all the checkboxes, but has not actually been deleted yet)
    # (Q?) Count Granules that are Verified by all checkboxes (Prod Manifest, Prod ORCA Manifest, Exists in CMR API)
    # Note, this may include granules that have been already deleted.  This is a raw number of granules that satisfy the particular checkboxes.
    @staticmethod
    def get_count__Granules_Ready_For_Delete(db_name_key="DEFAULT", max_retries=3):
        ret_total_count = 0
        # Get the session
        Session = DatabaseManager.get_session_for_db_name_key(db_name_key=db_name_key)

        with Session() as session:
            ret_total_count = (
                session.query(func.count(Granule.id))  # Passing the primary key directly here
                .filter(
                    Granule.DynamoDB_Key__file_path.isnot(None),     # Had to add this because we cannot select by a partial path with DynamoDB..... so we need the whole piece
                    Granule.is_in_NGAP_PROD.isnot(None),
                    Granule.is_in_NGAP_DR_PROD.isnot(None),
                    Granule.is_found_at_EarthData_PROD.isnot(None),
                    Granule.is_deleted_from_MCP_delivery.is_(None),  # And has not yet been deleted from S3
                    Granule.is_deleted_from_MCP_dynamoDB.is_(None),  # And has not yet been deleted from DynamoDB
                    Granule.num_of_attempts_MCP_s3_delete < max_retries, # Account for Max Retries - if a granule has been attempted too many times, then it is NOT ready for delete (we need a 129 and 130 which show us how many are not able to be deleted)
                    #Granule.cmr_found_at.isnot(None), # If this value is NOT None, that means a CMR entry has been observed and recorded.
                )
                .scalar()  # Using .scalar() instead of .count() to get the raw integer
            )
            return ret_total_count

        return ret_total_count

    # 126 - Select of Granules that are ready for deletes.
    # IMPORTANT - MAY NEED TO MODIFY THIS FUNCTION TO HANDLE RETRIES.. IF WE ARE AT MAX RETRIES - LIKE THE CMR QUERIES.
    @staticmethod
    def get_granules__That_Are_Ready_For_Deletes(db_name_key="DEFAULT", max_num_of_granules=2, max_retries=3):
        # Get the session
        Session = DatabaseManager.get_session_for_db_name_key(db_name_key=db_name_key)

        with Session() as session:
            results = (
                session.query(Granule)
                .filter(
                    Granule.DynamoDB_Key__file_path.isnot(None),     # Had to add this because we cannot select by a partial path with DynamoDB..... so we need the whole piece
                    Granule.is_in_NGAP_PROD.isnot(None),
                    Granule.is_in_NGAP_DR_PROD.isnot(None),
                    Granule.is_found_at_EarthData_PROD.isnot(None),
                    Granule.is_deleted_from_MCP_delivery.is_(None),  # And has not yet been deleted from S3
                    Granule.is_deleted_from_MCP_dynamoDB.is_(None),  # And has not yet been deleted from DynamoDB
                    Granule.num_of_attempts_MCP_s3_delete < max_retries, # Account for Max Retries - if a granule has been attempted too many times, then it is NOT ready for delete (we need a 129 and 130 which show us how many are not able to be deleted)
                    #Granule.cmr_found_at.isnot(None), # If this value is NOT None, that means a CMR entry has been observed and recorded.
                )
                .order_by(Granule.created_at.asc())                     # .asc() sorts then Oldest first // Trying to give every granule a chance to get cycled before retrying older ones.
                .limit(max_num_of_granules)
                .all()
            )

            # Handle the 0 rows case
            if not results:
                return None

            return results
        return None

    # 127 - That HAVE been Deleted Already
    @staticmethod
    def get_count__Granules_That_Have_Been_Deleted(db_name_key="DEFAULT"):
        ret_total_count = 0
        # Get the session
        Session = DatabaseManager.get_session_for_db_name_key(db_name_key=db_name_key)

        with Session() as session:
            ret_total_count = (
                session.query(func.count(Granule.id))  # Passing the primary key directly here
                .filter(
                    Granule.is_deleted_from_MCP_delivery.isnot(None),  # Has been deleted from S3
                    Granule.is_deleted_from_MCP_dynamoDB.isnot(None),  # And Has been deleted from DynamoDB
                    #Granule.cmr_found_at.isnot(None), # If this value is NOT None, that means a CMR entry has been observed and recorded.
                )
                .scalar()  # Using .scalar() instead of .count() to get the raw integer
            )
            return ret_total_count

        return ret_total_count

    # 128 Select Granules That HAVE been Deleted Already
    @staticmethod
    def get_granules__That_Have_Been_Deleted(db_name_key="DEFAULT", max_num_of_granules=2):
        # Get the session
        Session = DatabaseManager.get_session_for_db_name_key(db_name_key=db_name_key)

        with Session() as session:
            results = (
                session.query(Granule)
                .filter(
                    Granule.is_deleted_from_MCP_delivery.isnot(None),  # Has been deleted from S3
                    Granule.is_deleted_from_MCP_dynamoDB.isnot(None),  # And Has been deleted from DynamoDB
                )
                .order_by(Granule.created_at.asc())                     # .asc() sorts then Oldest first // Trying to give every granule a chance to get cycled before retrying older ones.
                .limit(max_num_of_granules)
                .all()
            )

            # Handle the 0 rows case
            if not results:
                return None

            return results
        return None




    # Granules that we have in the database, but have hit their max retries on Checking for CMR - This likely means that we have the delivery granule (in MCP - via DynamoDB_Key__file_path), but it is not been ingested yet.
    # IMPORTANT: This function is more important than it seems, the granules that get returned from this query becomes one of multiple sources of generating CNM messages.
    # 141 - Count of Suggested Granules to be attempted to be ingested
    # 142 - Suggested Granules to be attempted to be ingested
    #
    # 141 - Count of Suggested Granules to be attempted to be ingested 
    @staticmethod
    def get_count__Granules_Suggested_for_Ingest_Attempt(db_name_key="DEFAULT"):
        ret_total_count = 0
        # Get the session
        Session = DatabaseManager.get_session_for_db_name_key(db_name_key=db_name_key)

        with Session() as session:
            ret_total_count = (
                session.query(func.count(Granule.id))  # Passing the primary key directly here
                .filter(
                    Granule.cmr_found_at.is_(None),         # If this value is None, then we have not yet found this granule in the CMR..
                    Granule.num_of_attempts_cmr_check > 1,  # Granule that has been checked / failed against the CMR and then retried and retried against the CMR at least once
                )
                .scalar()  # Using .scalar() instead of .count() to get the raw integer
            )
            return ret_total_count

        return ret_total_count

    # 142 - Suggested Granules to be attempted to be ingested
    @staticmethod
    def get_granules__Suggested_for_Ingest_Attempt(db_name_key="DEFAULT", max_num_of_granules=2):
        # Get the session
        Session = DatabaseManager.get_session_for_db_name_key(db_name_key=db_name_key)

        with Session() as session:
            results = (
                session.query(Granule)
                .filter(
                    Granule.cmr_found_at.is_(None),         # If this value is None, then we have not yet found this granule in the CMR..
                    Granule.num_of_attempts_cmr_check > 1,  # Granule that has been checked / failed against the CMR and then retried and retried against the CMR at least once
                )
                .order_by(Granule.created_at.asc())                     # .asc() sorts then Oldest first // Trying to give every granule a chance to get cycled before retrying older ones.
                .limit(max_num_of_granules)
                .all()
            )

            # Handle the 0 rows case
            if not results:
                return None

            return results
        return None

    # Granules that are ready to be deleted, but for some reason could not be deleted (Have hit their max tries for delete).  Maybe they were already deleted and not recorded properly, or deleted by other means?  Maybe there is just something wrong with the granule (missing file, etc) 
    # 143 - Count of Granules that could not be deleted 
    # 144 - Granules that could not be deleted 

    # 143 - Count of Granules that could not be deleted 
    @staticmethod
    def get_count__Granules_That_Could_Not_Be_Deleted(db_name_key="DEFAULT"):
        ret_total_count = 0
        # Get the session
        Session = DatabaseManager.get_session_for_db_name_key(db_name_key=db_name_key)

        with Session() as session:
            ret_total_count = (
                session.query(func.count(Granule.id))  # Passing the primary key directly here
                .filter(
                    Granule.is_in_NGAP_PROD.isnot(None),                # Checkbox 1: Granule IS found in NGAP Prod Manifest
                    Granule.is_in_NGAP_DR_PROD.isnot(None),             # Checkbox 2: Granule IS found in NGAP DR Pord Manifest
                    Granule.is_found_at_EarthData_PROD.isnot(None),     # Checkbox 3: Granule IS found in CMR API Call.
                    Granule.is_deleted_from_MCP_delivery.is_(None),     # Has NOT been deleted from S3 (according to this Database)
                    Granule.num_of_attempts_MCP_s3_delete > 1,          # Has failed to be deleted from S3 AND failed the retry to delete at least once.
                    
                )
                .scalar()  # Using .scalar() instead of .count() to get the raw integer
            )
            return ret_total_count

        return ret_total_count

    # 144 - Granules that could not be deleted 
    @staticmethod
    def get_granules__That_Could_Not_Be_Deleted(db_name_key="DEFAULT", max_num_of_granules=2):
        # Get the session
        Session = DatabaseManager.get_session_for_db_name_key(db_name_key=db_name_key)

        with Session() as session:
            results = (
                session.query(Granule)
                .filter(
                    Granule.is_in_NGAP_PROD.isnot(None),                # Checkbox 1: Granule IS found in NGAP Prod Manifest
                    Granule.is_in_NGAP_DR_PROD.isnot(None),             # Checkbox 2: Granule IS found in NGAP DR Pord Manifest
                    Granule.is_found_at_EarthData_PROD.isnot(None),     # Checkbox 3: Granule IS found in CMR API Call.
                    Granule.is_deleted_from_MCP_delivery.is_(None),     # Has NOT been deleted from S3 (according to this Database)
                    Granule.num_of_attempts_MCP_s3_delete > 1,          # Has failed to be deleted from S3 AND failed the retry to delete at least once.
                )
                .order_by(Granule.created_at.asc())                     # .asc() sorts then Oldest first // Trying to give every granule a chance to get cycled before retrying older ones.
                .limit(max_num_of_granules)
                .all()
            )

            # Handle the 0 rows case
            if not results:
                return None

            return results
        return None
    

    # # # # METRICS CONSTRUCTION                #           END
    # # # # METRICS CONSTRUCTION                #           END
    # # # # METRICS CONSTRUCTION                #           END


    @staticmethod
    def get_remaining_granule_count__for_cmr_API_call__SLOW(db_name_key="DEFAULT", max_retries=3):
        ret_total_count = 0
        # Get the session
        Session = DatabaseManager.get_session_for_db_name_key(db_name_key=db_name_key)

        with Session() as session:
            
            # .count() executes a SELECT COUNT(*) query directly on the database
            total_count = (
                session.query(Granule)
                .filter(
                    Granule.cmr_found_at.is_(None),
                    Granule.num_of_attempts_cmr_check < max_retries,
                )
                .count()
            )
            #return total_count
            ret_total_count = total_count
            return ret_total_count

        return ret_total_count

    @staticmethod 
    def test__output_6_rows_of_DB_Contents_by_DB_Name(db_name_key="DEFAULT"):
        # Get the session
        Session = DatabaseManager.get_session_for_db_name_key(db_name_key=db_name_key)

        with Session() as session:
            # Query the first 6 records
            # .order_by(Granule.id.desc()) shows the newest first
            #stmt = select(Granule).limit(6)
            stmt = select(Granule).limit(6).order_by(Granule.id.desc())
            results = session.execute(stmt).scalars().all()

            if not results:
                print(f"--- No data found in {db_name_key} ---")
                return

            # Define column headers (getting them from the model class)
            columns = [column.name for column in Granule.__table__.columns]
            
            # Formatting setup - Going to make this look like a bit like a table
            width = 20
            #header = "".join([f"{col:<{width}}" for col in columns])
            header = " | ".join([f"{col:<{width}}" for col in columns])
            
            print(f"\n[Session View] Database: {db_name_key}")
            print(header)
            print("-" * len(header))

            # Iterate through the ORM objects
            for row in results:
                line = ""
                for col in columns:
                    # getattr dynamically gets the value for the column name
                    val = str(getattr(row, col))
                    # Truncate for clean table view
                    display_val = (val[:width-3] + '...') if len(val) > width else val
                    line += f"{display_val:<{width}}"
                print(line)
            print("-" * len(header) + "\n")

    @staticmethod 
    def test__output_6_rows_of_DB_Contents_by_DB_Name__ShowAllContents(db_name_key="DEFAULT"):
        # Get the session
        Session = DatabaseManager.get_session_for_db_name_key(db_name_key=db_name_key)

        with Session() as session:
            # Query the first 6 records
            # .order_by(Granule.id.desc()) shows the newest first
            #stmt = select(Granule).limit(6)
            stmt = select(Granule).limit(6).order_by(Granule.id.desc())
            results = session.execute(stmt).scalars().all()

            if not results:
                print(f"--- No data found in {db_name_key} ---")
                return

            # Define column headers (getting them from the model class)
            columns = [column.name for column in Granule.__table__.columns]
            
            print(f"\n[Session View] Database: {db_name_key}")

            # Formatting setup - Going to make this be more of a list of rows.
            for row in results:
                print("\nRow:")
                for col in columns:
                    # Get the value dynamically
                    val = getattr(row, col)
                    # Print in "column: value" format
                    print(f"{col}: {val}")
                print("-" * 30)

    # In order to communicate between isolated classes, 
    # This function gets passed in to a utility function as a call back.
    # That utility function reads from DynamoDB and then calls this function to write the records to SQLite.
    #
    # The param utils is the utils class (for access to the Utils from here)
    @staticmethod
    def write_dynamoDB_item_to_sqlite(sqlite_db_name_key, dynamo_db_item, utils):
        # sqlite_db_name_key, dynamo_db_item

        is_error = False
        # Single DynamoDB item passed in.
        try:
            # Get the file_path from the dynamoDB record
            dynamo_db_item__file_path = dynamo_db_item.get('file_path', '')

            # Get the entire contents of the row as a JSON String
            # Stringifying some JSON -- But the numbers need some help being formatted.
            dynamo_db_item__JSON_STRING = json.dumps(dynamo_db_item, cls= utils.DecimalEncoder)  

            # Get the Granule ID by doing the string conversion (try/catch)
            granule_id = utils.get_granule_id__from__dynamodb_file_path_field_value(dynamodb_file_path_field_value=dynamo_db_item__file_path)

            # Create a new granule and update it's rows
            DatabaseManager.add_new_granule(db_name_key=sqlite_db_name_key, granule_id=granule_id)
            # Update the new SQLiteDB record to include the DynamoDB contents
            num_of_rows_affected = DatabaseManager.update_string_granule_field_by_granule_id(db_name_key=sqlite_db_name_key, granule_id=granule_id, column_name="DynamoDB_Key__file_path",            new_value=dynamo_db_item__file_path)
            num_of_rows_affected = DatabaseManager.update_string_granule_field_by_granule_id(db_name_key=sqlite_db_name_key, granule_id=granule_id, column_name="DynamoDB_Contents",                  new_value=dynamo_db_item__JSON_STRING)

            pass
        except:
            is_error = True
            # Catch Errors and output to the terminal.
            error_type, error_value, _ = sys.exc_info()
            print(f'')
            print(f"write_dynamoDB_item_to_sqlite: Error Writing to SQLite DB: {sqlite_db_name_key}\n  (dynamo_db_item): {dynamo_db_item} \n\n   -- Sys Error Info: Error Type: {error_type}, Error Value: {error_value}")
            print(f'')

        # Did we get an error?
        return is_error

    # Get the Count of the number of rows in a table
    @staticmethod
    def get_count_num_of_rows_in_table(db_name_key):
        # Get the session
        Session = DatabaseManager.get_session_for_db_name_key(db_name_key=db_name_key)

        # Default the count to -1.  If -1 is what gets returned, then the session failed some how
        count = -1

        with Session() as session:
            # Query the count of the Granule class
            # This translates to: SELECT count(*) FROM granules
            count = session.query(func.count(Granule.id)).scalar()
            return count

        return count


    # Parse a Granule ID and place the granules in one of the databases defined in the DB_CONFIGS list
    # DB_CONFIGS = {
    #     "WV01": f"sqlite:///{base_db_path}/WV01.db",
    #     "WV02": f"sqlite:///{base_db_path}/WV02.db",
    #     "WV03": f"sqlite:///{base_db_path}/WV03.db",
    #     "WV04": f"sqlite:///{base_db_path}/WV04.db",
    #     "GE01": f"sqlite:///{base_db_path}/GE01.db",
    #     "DEFAULT": f"sqlite:///{base_db_path}/default.db",
    # }
    # #
    # # Granule IDs have this format (for now): WV01_20171216212050_102001006BB28F00_17DEC16212050-P1BS-504282004090_01_P008
    # First 4 chars tell us which DB it is.
    @staticmethod
    def get__db_name_key__for__granule_id(granule_id):
        ret_value = "DEFAULT"
        try:
            granule_id__DB_Name = granule_id[0:4]     # For now, just get the first 4 characters 

            # Now do a strict matching (and catch any that do not conform to one of the existing names).
            # - Improve this code by iterating the DB Configs object (rather than hard coding) - Doing it this way for now so I can easily find all the places in the code that reference these specific datasets, so when refactoring later I can do it correctly (how do we know if the future granules have a different format?)
            if(granule_id__DB_Name == 'WV01'):
                ret_value = 'WV01'
            elif(granule_id__DB_Name == 'WV02'):
                ret_value = 'WV02'
            elif(granule_id__DB_Name == 'WV03'):
                ret_value = 'WV03'
            elif(granule_id__DB_Name == 'WV04'):
                ret_value = 'WV04'
            elif(granule_id__DB_Name == 'GE01'):
                ret_value = 'GE01'
            else:
                print(f'')
                print(f'get__db_name_key__for__granule_id: WARNING: Granule_ID: {granule_id}, First 4 chars: {granule_id__DB_Name} Did not match any of the expected DB_Config names (Currently, WV01, WV02, WV03, WV04, GE01).  Using DEFAULT as the DB')
                print(f'')
                ret_value = "DEFAULT"

        except:
            error_type, error_value, _ = sys.exc_info()
            print(f'')
            print(f"get__db_name_key__for__granule_id: Uncaught Error Trying to figure out which DB to access for input granule: {granule_id}.  Returning DEFAULT.  \n\n   -- Sys Error Info: Error Type: {error_type}, Error Value: {error_value}")
            print(f'')
            ret_value = "DEFAULT"
        
        #print(f'get__db_name_key__for__granule_id: DEBUG: DB Key Is: {ret_value}')

        # Return the value
        return ret_value

    # Update or Create Row for the manifest Datetime Flags
    # Current Manifest Columns are: is_in_NGAP_PROD, is_in_NGAP_DR_PROD
    # is_in_NGAP_PROD                 = Column(DateTime, nullable=True, index=True)
    # is_in_NGAP_DR_PROD              = Column(DateTime, nullable=True, index=True)
    @staticmethod
    def update_or_create__manifest_column__by_granule_id(manifest_column_name, granule_id):
        #def update_or_create__manifest_column__by_granule_id(db_name_key, manifest_column_name, granule_id):

        # Figure out which DB Name Key we need based on the incoming Granule ID
        db_name_key = DatabaseManager.get__db_name_key__for__granule_id(granule_id=granule_id)
        
        # Track results
        is_created_new_row      = False
        is_updated_existing_row = False

        # Get the session
        Session = DatabaseManager.get_session_for_db_name_key(db_name_key=db_name_key)

        with Session() as session:
            granule = session.query(Granule).filter(Granule.granule_id == granule_id).first()

            if granule:
                # Found the granule field, now update the appropriate column.
                if(manifest_column_name == 'is_in_NGAP_PROD'):
                    granule.is_in_NGAP_PROD = func.current_timestamp()
                    is_created_new_row = True
                if(manifest_column_name == 'is_in_NGAP_DR_PROD'):
                    granule.is_in_NGAP_DR_PROD = func.current_timestamp()
                    is_created_new_row = True
            else:
                # No granule found.  Creating a new row.
                if(manifest_column_name == 'is_in_NGAP_PROD'):
                    new_row = Granule(granule_id=granule_id, is_in_NGAP_PROD=func.current_timestamp())
                    session.add(new_row)
                    is_updated_existing_row = True
                if(manifest_column_name == 'is_in_NGAP_DR_PROD'):
                    new_row = Granule(granule_id=granule_id, is_in_NGAP_DR_PROD=func.current_timestamp())
                    session.add(new_row)
                    is_updated_existing_row = True

            session.commit()

        # Return the results
        return is_created_new_row, is_updated_existing_row

    # Get Base Path
    @staticmethod
    def get_base_db_dir_path():
        return base_db_path

    # Get Full DB file Path
    @staticmethod
    def get_db_path(db_name_key='DEFAULT'):
        ret_path = f'{base_db_path}/{db_name_key}.db'
        return ret_path
    
    # ONE-TIME Migrations - Adding Fields as needed
    @staticmethod
    def run__one_time_migration__2026_Jul_28__Add_CMR_And_Tracking_Cols(db_name_key='DEFAULT'):
        # This migration is to add these columns to ALL databases.
        #
        # Once this migration is done, uncomment the column definitions in the Granule Class.
        # Note: Once this function is run it becomes unnecessary because any future fresh DBs will already have these columns.

        print(f'run__one_time_migration__2026_Jul_28__Add_CMR_And_Tracking_Cols: ')

        # Raw SQL to execute
        modifications = [
        ("ALTER TABLE granule ADD COLUMN last_attempt_MCP_delete DATETIME", 
         "CREATE INDEX idx_granule_last_attempt_MCP_delete ON granule(last_attempt_MCP_delete)"),
        
        ("ALTER TABLE granule ADD COLUMN last_attempt_MCP_dynamoDB_delete DATETIME", 
         "CREATE INDEX idx_granule_last_attempt_MCP_dynamoDB_del ON granule(last_attempt_MCP_dynamoDB_delete)"),
        
        ("ALTER TABLE granule ADD COLUMN cmr_checked_at DATETIME", 
         "CREATE INDEX idx_granule_cmr_checked_at ON granule(cmr_checked_at)"),
        
        ("ALTER TABLE granule ADD COLUMN cmr_found_at DATETIME", 
         "CREATE INDEX idx_granule_cmr_found_at ON granule(cmr_found_at)"),
        
        ("ALTER TABLE granule ADD COLUMN cmr_downloadable_at DATETIME", 
         "CREATE INDEX idx_granule_cmr_downloadable_at ON granule(cmr_downloadable_at)"),
        
        ("ALTER TABLE granule ADD COLUMN cmr_concept_id TEXT", 
         "CREATE INDEX idx_granule_cmr_concept_id ON granule(cmr_concept_id)"),
        
        ("ALTER TABLE granule ADD COLUMN num_of_attempts_cmr_check INTEGER NOT NULL DEFAULT 0", 
         "CREATE INDEX idx_granule_num_of_attempts_cmr_check ON granule(num_of_attempts_cmr_check)"),
        
        ("ALTER TABLE granule ADD COLUMN cmr_last_attempt_at DATETIME", 
         "CREATE INDEX idx_granule_cmr_last_attempt_at ON granule(cmr_last_attempt_at)"),
        
        ("ALTER TABLE granule ADD COLUMN cmr_last_error TEXT", 
         "CREATE INDEX idx_granule_cmr_last_error ON granule(cmr_last_error)"),
        
        ("ALTER TABLE granule ADD COLUMN num_of_attempts_MCP_s3_delete INTEGER NOT NULL DEFAULT 0", 
         "CREATE INDEX idx_granule_num_of_att_mcp_s3_del ON granule(num_of_attempts_MCP_s3_delete)"),
        
        ("ALTER TABLE granule ADD COLUMN num_of_attempts_MCP_dynamoDB_delete INTEGER NOT NULL DEFAULT 0", 
         "CREATE INDEX idx_granule_num_of_att_mcp_dyn_del ON granule(num_of_attempts_MCP_dynamoDB_delete)"),
        ]

        # Get the session
        Session = DatabaseManager.get_session_for_db_name_key(db_name_key=db_name_key)
        
        # Collecting info arrays to return
        results = []
        errors = []

        #results.append('testing_1 result')
        #errors.append('testing_1 error!')

        # Enter the session
        with Session() as session:
            print(f"Starting migration for database: {db_name_key}")
        
            for alter_sql, index_sql in modifications:
                # 1. Attempt to add the column
                try:
                    session.execute(text(alter_sql))
                    session.commit()
                    #print(f"Added column successfully: {alter_sql.split('ADD COLUMN ')[1]}")
                    result__alter_sql = f"Added column successfully: {alter_sql.split('ADD COLUMN ')[1]}"
                    results.append(f'result__alter_sql: {result__alter_sql}') #(result__alter_sql)
                    print(f"{result__alter_sql}")
                except Exception as e:
                    session.rollback()
                    # Suppress error if column already exists to allow safe re-runs
                    if "duplicate column name" in str(e).lower() or "already exists" in str(e).lower():
                        #print(f"Column already exists, skipping: {alter_sql.split('ADD COLUMN ')[1]}")
                        error_msg__dup_name = f"Column already exists, skipping: {alter_sql.split('ADD COLUMN ')[1]}"
                        errors.append(f'error_msg__dup_name: {error_msg__dup_name}') #errors.append(error_msg__dup_name)
                        print(f'{error_msg__dup_name}')
                    else:
                        #print(f"Failed to alter table: {e}")
                        error_msg__failed = f"Failed to alter table: {e}"
                        errors.append(f'error_msg__failed: {error_msg__failed}')
                        print(f"{error_msg__failed}")
                        raise

                # 2. Attempt to create the corresponding index
                try:
                    session.execute(text(index_sql))
                    session.commit()
                    #print(f"Created index successfully: {index_sql.split('INDEX ')[1].split(' ON')[0]}")
                    result__index_sql = f"Created index successfully: {index_sql.split('INDEX ')[1].split(' ON')[0]}"
                    results.append(f'result__index_sql: {result__index_sql}') #(result__alter_sql) # results.append(result__index_sql)
                    print(f"{result__index_sql}")
                except Exception as e:
                    session.rollback()
                    # Suppress error if index already exists
                    if "duplicate key" in str(e).lower() or "already exists" in str(e).lower():
                        #print(f"Index already exists, skipping: {index_sql.split('INDEX ')[1].split(' ON')[0]}")
                        error_msg__dup_key = f"Index already exists, skipping: {index_sql.split('INDEX ')[1].split(' ON')[0]}"
                        errors.append(f'error_msg__dup_key: {error_msg__dup_key}')
                        print(f'{error_msg__dup_key}')
                    else:
                        #print(f"Failed to create index: {e}")
                        error_msg__failed = f"Failed to create index: {e}"
                        errors.append(f'error_msg__failed: {error_msg__failed}')
                        print(f"{error_msg__failed}")
                        raise


        # Combining results and errors.
        ret_obj = {'results': results, 'errors': errors}
        results_as_string = f'{ret_obj}'
        return results_as_string

        
#



# # Update Usage Instructions
# # To Update String type Rows
# num_of_rows_affected = DatabaseManager.update_string_granule_field_by_granule_id(db_name_key="WV04", granule_id="abcdefg_1234567", column_name=DynamoDB_Key__file_path,            new_value="DynamoDB primary key value here")
# num_of_rows_affected = DatabaseManager.update_string_granule_field_by_granule_id(db_name_key="WV04", granule_id="abcdefg_1234567", column_name=DynamoDB_Contents,                  new_value="DynamoDB json string contents")
# num_of_rows_affected = DatabaseManager.update_string_granule_field_by_granule_id(db_name_key="WV04", granule_id="abcdefg_1234567", column_name=MCP_Rep_Granule_KeyPath,            new_value="mcp key path here")
# num_of_rows_affected = DatabaseManager.update_string_granule_field_by_granule_id(db_name_key="WV04", granule_id="abcdefg_1234567", column_name=NGAP_CBA_PROD_Rep_Granule_KeyPath,  new_value="NGAP CBA PROD key path here")

# # To Update DateTime type flag rows here.
# num_of_rows_affected = DatabaseManager.update_datetime_granule_field_by_granule_id(db_name_key="WV04", granule_id="abcdefg_1234567", column_name="is_in_NGAP_PROD")
# num_of_rows_affected = DatabaseManager.update_datetime_granule_field_by_granule_id(db_name_key="WV04", granule_id="abcdefg_1234567", column_name="is_in_NGAP_DR_PROD")
# num_of_rows_affected = DatabaseManager.update_datetime_granule_field_by_granule_id(db_name_key="WV04", granule_id="abcdefg_1234567", column_name="is_found_at_EarthData_PROD")
# num_of_rows_affected = DatabaseManager.update_datetime_granule_field_by_granule_id(db_name_key="WV04", granule_id="abcdefg_1234567", column_name="is_in_metrics_PROD")
# #
# num_of_rows_affected = DatabaseManager.update_datetime_granule_field_by_granule_id(db_name_key="WV04", granule_id="abcdefg_1234567", column_name="is_deleted_from_MCP_delivery")
# num_of_rows_affected = DatabaseManager.update_datetime_granule_field_by_granule_id(db_name_key="WV04", granule_id="abcdefg_1234567", column_name="is_deleted_from_MCP_dynamoDB")



















