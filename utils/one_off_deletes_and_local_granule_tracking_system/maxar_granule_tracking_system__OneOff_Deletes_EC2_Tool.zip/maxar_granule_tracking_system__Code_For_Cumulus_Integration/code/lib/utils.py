# utils.py

from decimal import Decimal
import json
import boto3
import sys

class utils:

    utils_version = "1.0.0"

    @staticmethod
    def utils_output_test():
        print(f'Hello world from utils_output_test.  utils_version: {utils.utils_version}')

    # Helper to handle DynamoDB Decimal types for JSON serialization
    @staticmethod
    class DecimalEncoder(json.JSONEncoder):
        def default(self, obj):
            if isinstance(obj, Decimal):
                return float(obj) if obj % 1 > 0 else int(obj)
            return super(DecimalEncoder, self).default(obj)

    # STILL WIRING THIS FUNCTION UP... DO NOT USE YET... THE WORK WAS FOR A MEETING....
    @staticmethod
    def scan_dynamoDB_and_save_to_SQLite__single_threaded(dynamodb_table_name, sqlite_db_name_key, write_dynamoDB_item_to_sqlite_callback_func):
        dynamodb = boto3.resource('dynamodb', region_name='<AWS_Region>')
        table = dynamodb.Table(dynamodb_table_name)

        # Keeping track of the number of errors.
        counter__errors         = 0
        counter__dynamo_rows    = 0
        counter__dynamo_pages   = 0

        # How often to output
        output_every_N_rows = 100000 #100000

        print(f'scan_dynamoDB_and_save_to_SQLite__single_threaded: About to read {dynamodb_table_name} and write to: ')
        
        scan_kwargs = {}
        done = False
        start_key = None

        while not done:
            #print(f'scanning {dynamodb_table_name}')
            # If there is a start key, then start with that key.
            if start_key:
                scan_kwargs['ExclusiveStartKey'] = start_key
            
            response = table.scan(**scan_kwargs)
            
            # Write each dynamo_db_item to SQLite
            for dynamo_db_item in response.get('Items', []):
                
                #write_data_to_Sqlite(dynamo_db_item)
                #callback(dynamo_db_item)
                # # Defined in sqlite_wrapper.py as "def write_dynamoDB_item_to_sqlite"
                is_error = write_dynamoDB_item_to_sqlite_callback_func(sqlite_db_name_key, dynamo_db_item, utils)  # Passing in this class for utils access
                
                # If there was an error writing, increment the counter.
                if(is_error == True):
                    counter__errors = counter__errors + 1

                # Completed a row
                counter__dynamo_rows = counter__dynamo_rows + 1

                if ((counter__dynamo_rows % output_every_N_rows) == 0):
                    # Updates the terminal output instead of waiting a long time for ALL the output
                    sys.stdout.flush()
                    print(f'  .. still scanning, just passed {counter__dynamo_rows}....')
            
            # Completed a page
            counter__dynamo_pages = counter__dynamo_pages + 1
            
            # Check if there is more data to fetch
            start_key = response.get('LastEvaluatedKey')
            done = start_key is None

        print(f'Scan Complete: Scanned {counter__dynamo_rows} rows on {counter__dynamo_pages} pages.  Had {counter__errors} errors.')
        return counter__dynamo_rows, counter__errors

    @staticmethod
    def get_granule_id__from__dynamodb_file_path_field_value(dynamodb_file_path_field_value=''):

        # Example VAlue: file_path = 'path/to/granule/<granule_id>'
        file_path = dynamodb_file_path_field_value
        granule_id = file_path.split('/')[-1]
        return granule_id


    # This is a test method but also serves as an example of how to access these data types safely - As Raw JSON
    @staticmethod
    def test_get_sample_dynamoDB_Data_AS_JSON(dynamodb_table_name="unset_table_name"):
        # Initialize DynamoDB resource
        dynamodb = boto3.resource('dynamodb', region_name='<AWS_Region>')
        table = dynamodb.Table(dynamodb_table_name)

        # Scan the table with a limit of 3
        # Note: Limit controls how many items DynamoDB processes, not just returns
        response = table.scan(Limit=3)
        items = response.get('Items', [])
        #
        if items:
            # print(items[0])
            for item in items:
                #print(f'------------------------')
                print(item)
                #print(f'------------------------')
        else:
            print("The table is empty.")
        return items

    # This is a test method but also serves as an example of how to access these data types safely
    @staticmethod
    def test_get_sample_dynamoDB_Data(dynamodb_table_name="unset_table_name"):

        # Initialize DynamoDB resource
        #dynamodb = boto3.resource('dynamodb')
        dynamodb = boto3.resource('dynamodb', region_name='<AWS_Region>')
        table = dynamodb.Table(dynamodb_table_name)

        # Scan the table with a limit of 20
        # Note: Limit controls how many items DynamoDB processes, not just returns
        response = table.scan(Limit=20)
        items = response.get('Items', [])

        # Save to a local JSON file
        #filename = f'{dynamodb_table_name}_sample_backup.json'
        #with open(filename, 'w') as f:
        #    json.dump(items, f, indent=4, cls=DecimalEncoder)
        ##
        #print(f"Successfully saved {len(items)} records to {filename}")

        for row in items:
            # Access columns like a normal dictionary
            row_id__file_path = row.get('file_path', '')        # This IS the row_id
            
            # Each of these hold Dictionaries
            col__browsejpg  = row.get('BROWSE.jpg', {})
            col__tif        = row.get('tif',        {})
            col__xml        = row.get('xml',        {})
            col__tar        = row.get('tar',        {})
            col__rename     = row.get('rename',     {})

            # Flattening all the vars -- Forcing all flat types (numbers included) to be strings, so we don't assume what types they are.
            col__browsejpg__sha256          = str(col__browsejpg.get('sha256', ''))
            col__browsejpg__s3_file_size    = str(col__browsejpg.get('s3_file_size', ''))
            col__browsejpg__local_file_size = str(col__browsejpg.get('local_file_size', ''))
            col__browsejpg__s3_file_path    = str(col__browsejpg.get('s3_file_path', ''))
            #
            col__tif__sha256          = str(col__tif.get('sha256', ''))
            col__tif__s3_file_size    = str(col__tif.get('s3_file_size', ''))
            col__tif__local_file_size = str(col__tif.get('local_file_size', ''))
            col__tif__s3_file_path    = str(col__tif.get('s3_file_path', ''))
            #
            col__xml__sha256          = str(col__xml.get('sha256', ''))
            col__xml__s3_file_size    = str(col__xml.get('s3_file_size', ''))
            col__xml__local_file_size = str(col__xml.get('local_file_size', ''))
            col__xml__s3_file_path    = str(col__xml.get('s3_file_path', ''))
            #
            col__tar__sha256          = str(col__tar.get('sha256', ''))
            col__tar__s3_file_size    = str(col__tar.get('s3_file_size', ''))
            col__tar__local_file_size = str(col__tar.get('local_file_size', ''))
            col__tar__s3_file_path    = str(col__tar.get('s3_file_path', ''))
            #
            col__rename__sha256          = str(col__rename.get('sha256', ''))
            col__rename__s3_file_size    = str(col__rename.get('s3_file_size', ''))
            col__rename__local_file_size = str(col__rename.get('local_file_size', ''))
            col__rename__s3_file_path    = str(col__rename.get('s3_file_path', ''))

            # Output all of these

            print(f'')
            print(f'--Row Data--')
            print(f'row_id__file_path:      {row_id__file_path}')
            #
            print(f'col__browsejpg__sha256:          {col__browsejpg__sha256}')
            print(f'col__browsejpg__s3_file_size:    {col__browsejpg__s3_file_size}')
            print(f'col__browsejpg__local_file_size: {col__browsejpg__local_file_size}')
            print(f'col__browsejpg__s3_file_path:    {col__browsejpg__s3_file_path}')
            #
            print(f'col__tif__sha256:          {col__tif__sha256}')
            print(f'col__tif__s3_file_size:    {col__tif__s3_file_size}')
            print(f'col__tif__local_file_size: {col__tif__local_file_size}')
            print(f'col__tif__s3_file_path:    {col__tif__s3_file_path}')
            #
            print(f'col__xml__sha256:          {col__xml__sha256}')
            print(f'col__xml__s3_file_size:    {col__xml__s3_file_size}')
            print(f'col__xml__local_file_size: {col__xml__local_file_size}')
            print(f'col__xml__s3_file_path:    {col__xml__s3_file_path}')
            #
            print(f'col__tar__sha256:          {col__tar__sha256}')
            print(f'col__tar__s3_file_size:    {col__tar__s3_file_size}')
            print(f'col__tar__local_file_size: {col__tar__local_file_size}')
            print(f'col__tar__s3_file_path:    {col__tar__s3_file_path}')
            #
            print(f'col__rename__sha256:          {col__rename__sha256}')
            print(f'col__rename__s3_file_size:    {col__rename__s3_file_size}')
            print(f'col__rename__local_file_size: {col__rename__local_file_size}')
            print(f'col__rename__s3_file_path:    {col__rename__s3_file_path}')
            print(f'')

            