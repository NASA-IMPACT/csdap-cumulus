#run_tests_delete_actions.py

from lib.sqlite_wrapper import DatabaseManager

from datetime import datetime, timezone, timedelta
import time
import sys
import math


import boto3
#from botocore.exceptions import ClientError
from botocore.exceptions import ClientError, NoCredentialsError, PartialCredentialsError



# ###################################
# # Helpers: DynamoDB Section
# ###################################

# Not Needed
# def helper__dynamoDB__does_dynamoDB_key_exist(dynamoDB_table_name, dynamoDB_key):
#     """
#     Checks if an item with the given key exists in a DynamoDB table.
#     dynamoDB_key should be a dict representing the primary key, e.g. {"id": "123"}.
#     """
#     dynamodb = boto3.resource("dynamodb")
#     table = dynamodb.Table(dynamoDB_table_name)
#
#     try:
#         response = table.get_item(Key=dynamoDB_key)
#         return "Item" in response
#     except ClientError as e:
#         print(f"Error checking DynamoDB key: {e}")
#         return False


# This just makes sure I am connected to AWS before proceeding
def test_aws_credentials(is_silent=True):
    sts = boto3.client("sts")
    try:
        identity = sts.get_caller_identity()
        #print("Connected to AWS - Verified")
        if(is_silent == False):
            print("Connected to AWS!")
            print(f"Account: {identity['Account']}")
            print(f"UserArn: {identity['Arn']}")
        return True
    #except ClientError as e:
    except (ClientError, NoCredentialsError, PartialCredentialsError) as e:
        print(f'ERROR: AWS credential test failed.  Error Message: {e}')
        #print("ERROR: AWS credential test failed.")
        #print(e)
        return False

# REbuild the file paths for S3 from the DynamoDB
def get_s3_file_paths__from__dynamo_db_file_path_value(DynamoDB_Key__file_path="", granule_id_validate_string=""):
    s3_file_paths = []
    is_error__get_s3_file_paths = False
    error_message__get_s3_file_paths = ""

    is_pass_validation = True  # Falsifiable.  This turns to False if any of the validation steps fail.

    # Make sure this key path is not blank
    if(DynamoDB_Key__file_path==""):
        s3_file_paths = []
        is_error__get_s3_file_paths = True
        error_message__get_s3_file_paths = error_message__get_s3_file_paths + " | get_s3_file_paths__from__dynamo_db_file_path_value: Parameter DynamoDB_Key__file_path was blank.  You must supply a DynamoDB_Key__file_path value."
        is_pass_validation = False

    # Make sure the granule_id_validate_string is not blank
    if(granule_id_validate_string==""):
        s3_file_paths = []
        is_error__get_s3_file_paths = True
        error_message__get_s3_file_paths = error_message__get_s3_file_paths + " | get_s3_file_paths__from__dynamo_db_file_path_value: Parameter granule_id_validate_string was blank.  You must supply a granule_id_validate_string value."
        is_pass_validation = False

    # Make sure the granule id is contained in the file_path
    granule_id_in__file_path = granule_id_validate_string in DynamoDB_Key__file_path
    if(granule_id_in__file_path == False):
        s3_file_paths = []
        is_error__get_s3_file_paths = True
        error_message__get_s3_file_paths = error_message__get_s3_file_paths + " | The granule_id_validate_string parameter must be contained in DynamoDB_Key__file_path.  If the granule_id is not found in the dynamoDB Key, that means this may be the wrong file to delete.  This also validates the length and dataset by proxy."
        is_pass_validation = False

    # Only proceed if the validation passed
    if(is_pass_validation == True):
        s3_file_paths.append(f'{DynamoDB_Key__file_path}-cmr.json')
        s3_file_paths.append(f'{DynamoDB_Key__file_path}-BROWSE.jpg')
        s3_file_paths.append(f'{DynamoDB_Key__file_path}.tif')
        s3_file_paths.append(f'{DynamoDB_Key__file_path}.xml')
        s3_file_paths.append(f'{DynamoDB_Key__file_path}.tar')
        s3_file_paths.append(f'{DynamoDB_Key__file_path}.rename')
        # Additional Variants
        s3_file_paths.append(f'{DynamoDB_Key__file_path}.ntf')
        s3_file_paths.append(f'{DynamoDB_Key__file_path}-thumb.jpg')


    # Return the values
    return s3_file_paths, is_error__get_s3_file_paths, error_message__get_s3_file_paths

    # Validate the files
    #pass
    #s3_file_paths, is_error__get_s3_file_paths, error_message__get_s3_file_paths = get_s3_file_paths__from__dynamo_db_file_path_value(DynamoDB_Key__file_path=current_granule__DynamoDB_Key__file_path, granule_id_validate_string=current_granule__granule_id)

def helper__dynamoDB__get_dynamoDB_table_name__from__db_name_key(db_name_key="DEFAULT"):
    ret__dynamoDB_table_name = None

    # # DynamoDB Tables
    # WV01<dynamodb_table_name>
    # WV02<dynamodb_table_name>
    # WV03<dynamodb_table_name>
    # WV04<dynamodb_table_name>
    # GE01<dynamodb_table_name>

    if(db_name_key=="WV01"):
        ret__dynamoDB_table_name = "WV01<dynamodb_table_name>"
    if(db_name_key=="WV02"):
        ret__dynamoDB_table_name = "WV02<dynamodb_table_name>"
    if(db_name_key=="WV03"):
        ret__dynamoDB_table_name = "WV03<dynamodb_table_name>"
    if(db_name_key=="WV04"):
        ret__dynamoDB_table_name = "WV04<dynamodb_table_name>"
    if(db_name_key=="GE01"):
        ret__dynamoDB_table_name = "GE01<dynamodb_table_name>"
    

    return ret__dynamoDB_table_name


# NOT USED by the main function - Testing only
#
# Gets the item, but has the side effect of checking to see if the item exists.
def helper__dynamoDB__get_item(dynamoDB_table_name, dynamoDB_key):
    """
    Attempts to get an item from DynamoDB.
    Returns the item dict if found, otherwise returns None.
    """
    ret_error_msg = ""
    is_error = False

    dynamodb = boto3.resource("dynamodb", region_name='<AWS_Region>')
    table = dynamodb.Table(dynamoDB_table_name)

    try:
        response = table.get_item(Key=dynamoDB_key)
        return response.get("Item"), is_error, ret_error_msg  # Returns None if missing
    except ClientError as e:
        #print(f"Error retrieving DynamoDB item: {e}")
        ret_error_msg = f"Error retrieving DynamoDB item: {e}"
        is_error = True
        return None, is_error, ret_error_msg


# NOT USED by the main function - Testing only
#
# Example DynamoDB Process Data Function
def higher_level_process_function(dynamoDB_table_name, dynamoDB_key):
    """
    Attempts to retrieve a row from DynamoDB. If it exists, process it.
    If not, print a warning.
    """
    item, is_error, error_msg = helper__dynamoDB__get_item(dynamoDB_table_name, dynamoDB_key)

    if item is None:
        print(f"Warning: key {dynamoDB_key} does not exist.")
        print(f'is_error: {is_error}, error_msg: {error_msg}')
        return

    # Process the data
    print("Processing item:")
    print(item)
    # Your processing logic would go here


# ###################################
# # Helpers: S3 Section
# ###################################

# NOT USED by the main function - Testing only
#
def helper__s3__does_s3_key_exist(s3_bucket_name, s3_key_path):
    """
    Checks if an object exists in the specified S3 bucket.
    """
    s3 = boto3.client("s3")

    try:
        s3.head_object(Bucket=s3_bucket_name, Key=s3_key_path)
        return True
    except ClientError as e:
        # A 404 means the object does not exist
        if e.response["Error"]["Code"] == "404":
            return False
        print(f"Error checking S3 key: {e}")
        return False


## EXAMPLE CODE for DELETES on S3
# import boto3
# from botocore.exceptions import ClientError
#
# is_deleted__s3_delete, is_error__s3_delete, error_message__s3_delete = delete_s3_file(bucket='', key='')
def delete_s3_file(bucket='', key=''):
    s3 = boto3.client("s3")

    is_deleted      = True      # this is also a proxy for is file NOT present.. so if we try to delete a file that is not present, nothing fails and the function return tells us the file was 'deleted'.
    is_error        = False
    error_message   = f''

    #if(bucket==''):
    if bucket is None or bucket.strip() == '':
        is_deleted      = False
        is_error        = True
        error_message   = f"delete_s3_file: Failed to delete '{key}' from bucket '{bucket}': Cannot pass a blank bucket value into this function"
        return is_deleted, is_error, error_message

    #if(key==''):
    if key is None or key.strip() == '':
        is_deleted      = False
        is_error        = True
        error_message   = f"delete_s3_file: Failed to delete '{key}' from bucket '{bucket}': Cannot pass a blank key value into this function"
        return is_deleted, is_error, error_message


    try:
        response = s3.delete_object(Bucket=bucket, Key=key)
        # If we reach here, either the file existed and was deleted,
        # or it didn't exist and S3 treated it as a success.
        #print(f"File '{key}' is now gone from bucket '{bucket}'.")
        is_deleted      = True
        is_error        = False
        #return True
        return is_deleted, is_error, error_message

    except ClientError as e:
        # Handle only real failures (permissions, missing bucket, etc.)
        #print(f"Failed to delete '{key}': {e}")
        #return False
        is_deleted      = False
        is_error        = True
        error_message   = f"Failed to delete '{key}' from bucket '{bucket}': ClientError Message: {e}" #f''
        return is_deleted, is_error, error_message

# # DELETE A BATCH OF S3 KEY PATHS IN ONE AWS COMMAND WITH THIS FUNCTION (6x more efficient)
#
# 'keys' input example
# 
# keys_to_delete = [
#     "folder/object1.txt",
#     "folder/object2.txt",
#     "folder/object3.txt",
#     # ...
# ]
# 
# is_deleted, is_error, err_msg = delete_s3_files("mybucket", keys_to_delete)
#
# if is_error:
#     print(f"Batch delete failed: {err_msg}")
# else:
#     print("All objects deleted successfully (including any that didn't exist).")
#
#
# is_deleted__s3_batch_delete, is_error__s3_batch_delete, error_message__s3_batch_delete = delete_s3_files(bucket='', keys=[...])
def delete_s3_files(bucket='', keys=None):
    s3 = boto3.client("s3")

    is_deleted      = True
    is_error        = False
    error_message   = ''

    # Validate bucket
    if bucket is None or bucket.strip() == '':
        return False, True, f"delete_s3_files: Cannot pass a blank bucket value into this function.  Deletes that did NOT happen: Failed to delete '{keys}' from bucket '{bucket}'"

    # Validate keys list
    if keys is None or len(keys) == 0:
        return False, True, f"delete_s3_files: Keys list cannot be empty.  Deletes that did NOT happen: Failed to delete '{keys}' from bucket '{bucket}'"
    
    # Validate individual keys
    for key in keys:
        if key is None or key.strip() == '':
            return False, True, f"delete_s3_files: Blank key found in keys list: Blank Key: '{key}'.  Failed to delete '{keys}' from bucket '{bucket}'"

    # Build bulk delete payload
    objects = [{'Key': key} for key in keys]

    try:
        response = s3.delete_objects(
            Bucket=bucket,
            Delete={'Objects': objects}
        )

        # S3 bulk delete semantics:
        # - Missing objects count as successful deletions
        # - Only actual permission/bucket/account errors throw exceptions

        # If we reach here, the batch delete itself succeeded
        is_deleted = True
        is_error   = False
        return is_deleted, is_error, error_message

    except ClientError as e:
        is_deleted    = False
        is_error      = True
        error_message = f"delete_s3_files: ClientError during delete_objects: {e}.  Failed to delete '{keys}' from bucket '{bucket}'"
        return is_deleted, is_error, error_message



# # ONLY DELETE A SINGLE DYNAMODB ROW WITH THIS FUNCTION
#
# Deletes a dynamoDB row, 
#is_deleted__dynamoDB_Row_Delete, is_error__dynamoDB_Row_Delete, error_message__dynamoDB_Row_Delete = delete_s3_file(bucket='', key='')
#def delete_dynamoDB_row(dynamoDB_table_name='', dynamoDB_key=''):
def delete_dynamoDB_row(dynamoDB_table_name='', dynamoDB_key=None):
    
    is_deleted      = False
    is_error        = False
    error_message   = ''

    # Validate input
    if dynamoDB_table_name is None or dynamoDB_table_name.strip() == '':
        is_error = True
        error_message = 'Error: dynamoDB_table_name cannot be blank.'
        return is_deleted, is_error, error_message

    # if dynamoDB_key is None or dynamoDB_key.strip() == '':
    #     is_error = True
    #     error_message = 'Error: dynamoDB_key cannot be blank.'
    #     return is_deleted, is_error, error_message
    
    # Validate key dict
    if dynamoDB_key is None or not isinstance(dynamoDB_key, dict):
        is_error = True
        error_message = 'Error: dynamoDB_key must be a dict and cannot be None.'
        return is_deleted, is_error, error_message

    # Validate that "file_path" exists in the dict
    if "file_path" not in dynamoDB_key:
        is_error = True
        error_message = 'Error: dynamoDB_key must contain "file_path".'
        return is_deleted, is_error, error_message


    dynamodb = boto3.resource("dynamodb", region_name='<AWS_Region>')
    table = dynamodb.Table(dynamoDB_table_name)

    try:
        response = table.delete_item(
            #Key = { "file_path": dynamoDB_key },
            Key = dynamoDB_key,
            ReturnValues = "ALL_OLD"
        )

        # ALL_OLD returns the deleted item if it existed
        if "Attributes" in response:
            # Row existed and was deleted
            is_deleted = True
            return is_deleted, is_error, error_message
        else:
            # Row did not exist — treat as successfully deleted
            is_deleted = True
            return is_deleted, is_error, error_message

    except ClientError as e:
        is_error = True
        error_message = f"Error deleting DynamoDB row: {e}"
        return is_deleted, is_error, error_message


# Support Function to wrap the keys properly
def to_dynamo_key(py_key):
    return {
        "file_path": {"S": py_key["file_path"]}
    }

# # DELETE A BATCH OF DynamoDB ROWS (25 max in one request) IN ONE AWS COMMAND WITH THIS FUNCTION (about 6x more efficient)
#
# is_deleted__dynamoDB_BatchDelete, is_error__dynamoDB_BatchDelete, error_message__dynamoDB_BatchDelete = delete_dynamoDB_rows(dynamoDB_table_name=dynamoDB_table_name, dynamoDB_keys=[{...}, {...}, ...])
def delete_dynamoDB_rows(dynamoDB_table_name='', dynamoDB_keys=None):

    is_deleted      = False
    is_error        = False
    error_message   = ''

    # Validate table name
    if dynamoDB_table_name is None or dynamoDB_table_name.strip() == '':
        return False, True, "Error: dynamoDB_table_name cannot be blank."

    # Validate list of keys
    if dynamoDB_keys is None or not isinstance(dynamoDB_keys, list) or len(dynamoDB_keys) == 0:
        return False, True, f"Error: dynamoDB_keys must be a non-empty list.  Rows Not Deleted: dynamoDB_table_name: {dynamoDB_table_name}, dynamoDB_keys: {dynamoDB_keys}"

    # DynamoDB batch_write_item max = 25 items
    if len(dynamoDB_keys) > 25:
        return False, True, f"Error: DynamoDB batch delete supports a maximum of 25 rows. You passed {len(dynamoDB_keys)}.  Rows Not Deleted: dynamoDB_table_name: {dynamoDB_table_name}, dynamoDB_keys: {dynamoDB_keys}"

    # Validate each key
    for key in dynamoDB_keys:
        if key is None or not isinstance(key, dict):
            return False, True, f"Error: each DynamoDB key must be a dict.  Rows Not Deleted: dynamoDB_table_name: {dynamoDB_table_name}, dynamoDB_keys: {dynamoDB_keys}"
        if "file_path" not in key:
            return False, True, f'Error: each DynamoDB key dict must contain "file_path".  Rows Not Deleted: dynamoDB_table_name: {dynamoDB_table_name}, dynamoDB_keys: {dynamoDB_keys}'

    dynamodb = boto3.client("dynamodb", region_name="<AWS_Region>")

    # # Build batch delete request
    # delete_requests = [
    #     {"DeleteRequest": {"Key": key}}
    #     for key in dynamoDB_keys
    # ]
    delete_requests = [
        {"DeleteRequest": {"Key": to_dynamo_key(key)}} 
        for key in dynamoDB_keys
    ]

    try:
        response = dynamodb.batch_write_item(
            RequestItems={dynamoDB_table_name: delete_requests}
        )

        # If UnprocessedItems is empty → everything deleted successfully
        unprocessed = response.get("UnprocessedItems", {})
        if unprocessed and dynamoDB_table_name in unprocessed:
            # DynamoDB occasionally leaves some items unprocessed
            # You can decide whether to retry — but per your instructions,
            # error grouping is fine.
            is_deleted    = False
            is_error      = True
            error_message = f"Some DynamoDB rows were not processed (These were not deleted): {unprocessed}.  Total Rows passed in: dynamoDB_table_name: {dynamoDB_table_name}, dynamoDB_keys: {dynamoDB_keys}"
            return is_deleted, is_error, error_message

        # All rows deleted or treated as deleted (missing rows count as success)
        is_deleted = True
        is_error   = False
        return is_deleted, is_error, error_message

    except ClientError as e:
        is_deleted    = False
        is_error      = True
        error_message = f"Error deleting DynamoDB rows: {e}.  Rows Not Deleted: dynamoDB_table_name: {dynamoDB_table_name}, dynamoDB_keys: {dynamoDB_keys}"
        return is_deleted, is_error, error_message



# ###################################
# # Tests - The Actual Tests Section
# ###################################

#def run_integrated_test_01__Delete_Granules_from_S3_and_DynamoDB():
#
# # Batch Delete Params:
# is_delete_granules_in_batches=True,       # This means that up to N number of granules will be collected before a boto3 s3 and DynamoDB delete operation is performed.  Performing multiple deletes in a single command is far more efficient than calling boto3 for every s3 file and for every dynamoDB row.  The only cost here is that if there is one fail, the local DB will get a fail/retry count for all the granules in the batch.
# max_num_of_granules_per_delete_batch=25   # We are limited to 25 granules because we can only delete 25 dynamoDB rows in a single call, each dynamoDB row is a single granule.  S3 can do up to 1000 files in one call, to keep the deletes synced, I'm letting the dynamoDB limiting factor be the limiter for S3 as well, so we can batch 25 granules worth of files into the s3 as well, which is about 150 files (6 files x 1 granule).
#
def run_integrated_test_01__Delete_Granules_from_S3_and_DynamoDB(db_name_key="DEFAULT", delivery_deletes__num_of_batches_to_run=2, delivery_deletes__max_num_of_granules_to_select_per_batch=3, max_db_chunk_size=100000, delivery_deletes__max_retries=3, is_just_do_all_remaining=False, highly_detailed_logging=False, is_delete_granules_in_batches=True, max_num_of_granules_per_delete_batch=25):
    print(f'')
    print(f'run_integrated_test_01__Delete_Granules_from_S3_and_DynamoDB:      STARTED')
    print(f'')

    # This is the max number of rows that can be deleted from a dynamoDB table on AWS in a single boto3 request.
    aws_dynamoDB_Max_rows_per_delete = 25

    # Total Time Tracking - Start Time
    time__total__start = time.time()

    # Hard Coded for now because it is the only bucket we are working with for now.
    s3_bucket_name = "<delivery-bucket-name>"

    # # We likely do not need chunks for this, but will keep the logic here to keep the selects down
    # Setting for how many items we can get from the DB at one time (this is based on memory constraints balanced with performance gains)
    #max_db_chunk_size = 100000  # 100k seems like a fair number to start with, at 2000 granules per batch, that would give us 50 batches per chunk query.
    
    ## Settings Needed for any of these inputs # # Moved these out to the Function Params
    #print(f'run_integrated_test_01__Delete_Granules_from_S3_and_DynamoDB: WARN: HardCoding DB Name Key To WV01.  The real, live version needs to be dynamic or passed in as an external parameter. ')
    #db_name_key = "WV01"

    # Settings # # Moved these out to the Function Params
    #print(f'run_integrated_test_01__Delete_Granules_from_S3_and_DynamoDB: WARN: HardCoding Double check these settings before going to the live version.')
    #delivery_deletes__num_of_batches_to_run                     = 2 #4 # 2   # How many times the outer loop will run.
    #delivery_deletes__max_num_of_granules_to_select_per_batch   = 3 # 500 #7 #4 #500  # Testing this with 4 at a time, 500 is what we will run in production.
    #delivery_deletes__max_retries                               = 3       # Max Retries per granule for selecting from our local database.
    ##delivery_deletes__min_delay_seconds_between_delete_requests = 1.5     # How long we should delay between requests to S3/DynamoDB -- likely none.

    ## This shows detailed Granule Data from the Process.  # # Moved these out to the Function Params
    ## # Turn this on if I need to debug something on the live server.
    #highly_detailed_logging                                 = False




    # Info for the report at the bottom of this function
    time__db_select__elapsed__LIST = []
    time__db_update__elapsed__LIST = []
    time__db_count__elapsed__LIST = []
    #
    time__loop__elapsed__LIST = [] # This one is a bit different and tracks loop time, but does the same analysis on it. # time__loop__elapsed  


    # Get the Count of how many Total Granules there are remaining
    time__db_count__start   = time.time()
    total_remaining_count__BEFORE = DatabaseManager.get_count__Granules_Ready_For_Delete(db_name_key=db_name_key, max_retries=delivery_deletes__max_retries)
    time__db_count__end     = time.time()
    time__db_count__elapsed = time__db_count__end - time__db_count__start
    time__db_count__elapsed__LIST.append(time__db_count__elapsed)

    # This var current_granule_rows_remaining_count is really just a running estimate.. making the above query inside the batch destroys the efficiency on very large tables (instead of taking micro seconds, the query takes minutes).. so using this variable for estimates instead.
    current_granule_rows_remaining_count = total_remaining_count__BEFORE

    # This var is for keeping track of how many granules we are trying to chew through on this run.  It is initially calculated based on how many batches and how many granules per batch.
    total_estimated_granules_this_run = 0 # Defaults at 0, so if nothing changes, then nothing happens further below.

    # If we just want to do as many of the remaining granules as possible...
    print(f'')
    if(is_just_do_all_remaining == True):
        # Then calculate how many batches we would need to run and overwrite: delivery_deletes__num_of_batches_to_run with that number.
        if(delivery_deletes__max_num_of_granules_to_select_per_batch > 0):
            est_num_of_batches_to_run           = int(total_remaining_count__BEFORE / delivery_deletes__max_num_of_granules_to_select_per_batch) + 2 # Adding two to account for int rounding down and an extra 1 for padding.
            print(f'  is_just_do_all_remaining: was set to {is_just_do_all_remaining}.  Calculating')
            print(f'    Estimated that about {est_num_of_batches_to_run} batches will be needed of size {delivery_deletes__max_num_of_granules_to_select_per_batch} to complete processing for {total_remaining_count__BEFORE} Remaining Granules in DB {db_name_key}')
            print(f'    Overwriting original delivery_deletes__num_of_batches_to_run value of: {delivery_deletes__num_of_batches_to_run} batches to run, with new calculated value of: {est_num_of_batches_to_run} batches to run.')
            #delivery_deletes__num_of_batches_to_run = est_num_of_batches_to_run * delivery_deletes__max_num_of_granules_to_select_per_batch
            delivery_deletes__num_of_batches_to_run = est_num_of_batches_to_run 
            #
            #total_estimated_granules_this_run = delivery_deletes__num_of_batches_to_run
            total_estimated_granules_this_run = delivery_deletes__num_of_batches_to_run * delivery_deletes__max_num_of_granules_to_select_per_batch
            print(f'    Expected that about {total_estimated_granules_this_run} total granules will be run in {delivery_deletes__num_of_batches_to_run} batches of size {delivery_deletes__max_num_of_granules_to_select_per_batch} granules each.  Before this run begins, there are {total_remaining_count__BEFORE} Remaining Granules in the DB {db_name_key}')
    else:
        print(f'  is_just_do_all_remaining: was set to {is_just_do_all_remaining}.  Using input value for delivery_deletes__num_of_batches_to_run of {delivery_deletes__num_of_batches_to_run}')
        total_estimated_granules_this_run = delivery_deletes__num_of_batches_to_run * delivery_deletes__max_num_of_granules_to_select_per_batch
        #print(f'    Estimated that about {delivery_deletes__num_of_batches_to_run} batches will be needed of size {delivery_deletes__max_num_of_granules_to_select_per_batch} to complete processing for {total_remaining_count__BEFORE} Remaining Granules')
        print(f'    Expected that about {total_estimated_granules_this_run} total granules will be run in {delivery_deletes__num_of_batches_to_run} batches of size {delivery_deletes__max_num_of_granules_to_select_per_batch} granules each.  Before this run begins, there are {total_remaining_count__BEFORE} Remaining Granules in the DB {db_name_key}')

    # Calculate number of chunks
    number_of_db_chunks = 0
    if(total_estimated_granules_this_run > 0):
        if(max_db_chunk_size > 0):
            number_of_db_chunks = math.ceil(total_estimated_granules_this_run / max_db_chunk_size) # The last chunk will always select a smaller number of rows (rounding up catches the remainder)
            print(f'  number_of_db_chunks: {number_of_db_chunks}.  (Number times a select of max size {max_db_chunk_size} is done from the DB for this run).  Each Select Costs can cost minutes of processing time.')
        
    # Tracking the total number of time spent doing certain DB Queries.
    db_query_seconds__selects = 0
    db_query_seconds__updates = 0

    # Show the time estimate
    previously_observed_seconds_per_batch = 25.0
    est_seconds_to_complete     = (delivery_deletes__num_of_batches_to_run * previously_observed_seconds_per_batch) # somewhat over estimated observed batch average seconds. #__min_delay_seconds_between_api_requests)
    est_hours_to_complete       = math.ceil(est_seconds_to_complete / (60 * 60)) #int(est_seconds_to_complete / (60 * 60))
    #
    print(f'      Based on previously observed seconds per batch of {previously_observed_seconds_per_batch} per batch, This process will take an estimated total {est_hours_to_complete} hours to complete (Total Estimated Seconds: {est_seconds_to_complete}). ')
    print(f'        (Note: This estimate does NOT include an accurate time to do Count or Selection Queries which can take several Minutes on DBs with more than 1 million rows.)')
    print(f'        (Note: Update Queries on large databases can take several seconds, rather than microseconds on very small databases)')
    print(f'')
    #
    # Calculate additional time for DB queries - Update after I know how long these things actually take.
    est_seconds_per_large_select_statement = float(10.0) # About 10 seconds average observed in GE01.  #int(5*60) # First estimate is 5 minutes per select statement
    est_seconds_added_for_all_select_statements     = est_seconds_per_large_select_statement * number_of_db_chunks
    est_hours_added_for_all_select_statements       = math.ceil(est_seconds_added_for_all_select_statements / (60 * 60)) #int(est_seconds_added_for_all_select_statements / (60 * 60))
    #
    est_seconds_per_small_update_statement = float(0.001) # 0.001 per update is actually pretty close to observed in GE01.   # First estimate is 1000 granules can be updated per second.  Will modify with real data.
    est_seconds_added_for_all_update_statements     = est_seconds_per_small_update_statement * total_estimated_granules_this_run
    est_hours_added_for_all_update_statements       = math.ceil(est_seconds_added_for_all_update_statements / (60 * 60)) #int(est_seconds_added_for_all_select_statements / (60 * 60))
    #
    est_seconds_per_count_statement = float(2.27)  # 2.27 seconds Observed in GE01 #float(5*60) # First estimate is 5 minutes per count statement
    est_seconds_added_for_all_count_statements     = est_seconds_per_count_statement * 2 # We only count twice, once before processing and once at the end of the run.
    est_hours_added_for_all_count_statements       = math.ceil(est_seconds_added_for_all_count_statements / (60 * 60)) #int(est_seconds_added_for_all_select_statements / (60 * 60))
    #
    print(f'      Additional Time Estimates for DB Queries')
    print(f'        All Large Chunk Select Statements: ({number_of_db_chunks} Large Select Statements) Totals: Est Total Hours: {est_hours_added_for_all_select_statements}.  Est Total Seconds: {est_seconds_added_for_all_select_statements}')
    print(f'        All Small Update Statements:       ({total_estimated_granules_this_run} Small Update Statements) Totals: Est Total Hours: {est_hours_added_for_all_update_statements}.  Est Total Seconds: {est_seconds_added_for_all_update_statements}')
    print(f'        All Count Statements:              (2 Count Statements) Totals: Est Total Hours: {est_hours_added_for_all_count_statements}.  Est Total Seconds: {est_seconds_added_for_all_count_statements}')
    print(f'')
    #
    est_total_seconds = est_seconds_to_complete + est_seconds_added_for_all_select_statements + est_seconds_added_for_all_update_statements + est_seconds_added_for_all_count_statements
    est_total_hours   = math.ceil(est_total_seconds / (60 * 60))
    print(f'      Total Execution Time, Including SQL Additions.')
    print(f'        Est. Total Hours (rounded up):   {est_total_hours}, Est. Total Seconds: {est_total_seconds}')
    
    # An Array to hold granules being poped out of the chunk select, and placed into the batch array to be processed in each batch.
    current_db_chunk_granule_list = []


    #print(f'  FIX THE REPORT SECTION AFTER I HAVE THE LOGIC PATH WAYS WORKED OUT AND FINALIZED... DRAFT: GRANULES_DELETED, GRANULES_NOT_DELETED')
    # Reference - defined earlier in the code
    #
    # # Info for the report at the bottom of this function
    # time__db_select__elapsed__LIST = []
    # time__db_update__elapsed__LIST = []
    # time__db_count__elapsed__LIST = []
    #
    report__num_of_chunks_selected = 0              # New Report Param, keeping track of how many Select Statements we ran
    report__total_num_of_granules_selected = 0      # New Report Param, keeping track of how many actual granules were selected (including the last chunk which will likely be smaller than the max size.)
    report__num_of_batches_attempted = 0
    report__num_of_batches_completed = 0
    #
    #report__num_of_updates_made__localDB_granules_not_found_in_cmr  = 0
    #report__num_of_updates_made__localDB_granules_found_in_cmr      = 0
    #report__num_of_updates_made__new_granules_found_in_cmr          = 0
    report__num_of_updates_made__localDB_granules_deleted           = 0     # Deleted from both S3 and DynamoDB (Or was already in that state where it was all deleted)
    report__num_of_updates_made__localDB_granules_NOT_deleted       = 0     # At least an S3 file and/or DynamoDB item was found and Could not be deleted.  This increments the num_of_attempts_counter
    #
    report__num_of_errors = 0
    report__error_log = []

    # Output for the log
    print(f'')
    print(f'  About to enter the Batch Granule Processing Loop: Params:')
    print(f'    Settings:')
    print(f'      is_just_do_all_remaining:                                   {is_just_do_all_remaining}')
    print(f'      delivery_deletes__num_of_batches_to_run:                    {delivery_deletes__num_of_batches_to_run}')
    print(f'      delivery_deletes__max_retries:                              {delivery_deletes__max_retries}')
    print(f'      delivery_deletes__max_num_of_granules_to_select_per_batch:  {delivery_deletes__max_num_of_granules_to_select_per_batch}')
    print(f'      Expected Number of DB Chunks (Select Statements):           {number_of_db_chunks}')
    print(f'      Max DB Chunk Size (Max Num of Granules Selected per Chunk): {max_db_chunk_size}')
    print(f'      is_delete_granules_in_batches:                              {is_delete_granules_in_batches}')
    print(f'      Max Number of Granules to delete per delete_batch:          {max_num_of_granules_per_delete_batch}, (This is different than selection batches above.  25 is the max possible value)')
    print(f'    Params:')
    print(f'      db_name_key:                 {db_name_key}')
    print(f'')
    print(f'      highly_detailed_logging:     {highly_detailed_logging}')
    print(f'')
    sys.stdout.flush()  # Force Terminal Output (helps with monitoring progress) # Forces all buffered print statements above to output right now




    # Control Variables
    can_proceed_with_delete_attempts__TopLevel = True

    # Get the DynamoDB
    dynamoDB_table_name = helper__dynamoDB__get_dynamoDB_table_name__from__db_name_key(db_name_key=db_name_key)
    #print(f' DEBUG: dynamoDB_table_name: {dynamoDB_table_name} ')
    
    if dynamoDB_table_name is None:
        #print(f"ERROR: Could not find a Matching DynamoDB Table name for {db_name_key}.  If there is no DynamoDB table, we cannot proceed.")
        error_message = f'ERROR: Could not find a Matching DynamoDB Table name for {db_name_key}.  If there is no DynamoDB table, we cannot proceed.'
        report__error_log.append(error_message)
        print(f'  {error_message}')
        report__num_of_errors = report__num_of_errors + 1
        sys.stdout.flush()
        can_proceed_with_delete_attempts__TopLevel = False
    
    ##item = helper__dynamoDB__get_item(dynamoDB_table_name, dynamoDB_key)
    #if item is None:
    #    print(f"Warning: key {dynamoDB_key} does not exist.")

    if(can_proceed_with_delete_attempts__TopLevel == False):
        print(f'There was a caught error.  Cannot continue with the Deletes')
    else:
        
        # Each run through this loop is for a single batch.
        for i in range(delivery_deletes__num_of_batches_to_run):

            try:
                # Start tracking the time inside the loop.  I am also using this as a mechanism for delaying the next API Request to the CMR
                time__loop__start = time.time()

                # When a batch is run, we get a datetime object to store the attempt time
                batch_date_time = datetime.now(timezone.utc)
            
                # Starting a batch, need to increment the attempt counter 
                report__num_of_batches_attempted = report__num_of_batches_attempted + 1

                # Count starts at 0, for logging, adding 1 to it for readability
                current_batch_number = i + 1
                print(f'')
                print(f'  ------------------------------------------------------------------------')
                print(f'    Batch: {current_batch_number} of {delivery_deletes__num_of_batches_to_run}: Starting to process a new Batch of {delivery_deletes__max_num_of_granules_to_select_per_batch} Granules to Execute Delivery Buckets Delete at Datetime: {batch_date_time}')

                # Chunking Mechanism - so we don't run select statements very often.
                current_granule_rows_list = [] # These are the original Batch Items (inside this part of the loop, we have a whole batch of granules).
                #
                # Check the Current Length (how many rows are left in the db chunk list)
                current_length_of_db_chunk_list = len(current_db_chunk_granule_list)
                if(current_length_of_db_chunk_list == 0):
                    # The chunk list is empty.  This is either the first time through the loop, or a middle time through the loop that needs refilling, or maybe the last time through the loop (where there are still batches, but no more granules to select)
                    # Figure out which time through the loop (if we should be trying to reload the chunk selection or not)
                    if(report__num_of_chunks_selected < number_of_db_chunks):
                        # Does not matter if this is the first time or middle time, at this point, we need to select the next chunk.
                        time__db_select__start   = time.time()
                        current_db_chunk_granule_list = DatabaseManager.get_granules__That_Are_Ready_For_Deletes(db_name_key=db_name_key, max_num_of_granules=max_db_chunk_size, max_retries=delivery_deletes__max_retries) # max_retries=3 (max_retries is an Optional Param defaulted at 3)
                        # Fix for when out of granules (can't handle lenght of None)
                        if(current_db_chunk_granule_list == None):
                            print(f'   *Attempted New Chunk: {report__num_of_chunks_selected}, but it seems we are now out of granules to select!')
                            current_db_chunk_granule_list = []
                        time__db_select__end     = time.time()
                        time__db_select__elapsed = time__db_select__end - time__db_select__start
                        len__current_db_chunk_granule_list = len(current_db_chunk_granule_list)
                        print(f'   *** New Chunk: {report__num_of_chunks_selected}, Selected: {len__current_db_chunk_granule_list} Granules.  Seconds Elapsed: {time__db_select__elapsed}')
                        #
                        # Increment the trackers
                        time__db_select__elapsed__LIST.append(time__db_select__elapsed)
                        report__num_of_chunks_selected = report__num_of_chunks_selected + 1
                        report__total_num_of_granules_selected = report__total_num_of_granules_selected + len__current_db_chunk_granule_list
                    else:
                        # We have reached the max number of chunks that we needed to select.  Do nothing here
                        print(f'      We have reached the max number of chunks ({report__num_of_chunks_selected} out of {number_of_db_chunks}) selected for this run.  No more selections for this run.  If this repeats, it might just be trying to finish the batch numbers.') #  If this message repeats more than once, that is an error, DEBUG IT!')
                #
                # Now we have to put chunked granules in the 'current_granule_rows_list' variable.
                len_2__current_length_of_db_chunk_list = len(current_db_chunk_granule_list)
                if(len_2__current_length_of_db_chunk_list > 0):
                    # Can only proceed with this if we actually have granules in the chunked list.
                    current_granule_rows_list = [] # Have to be a list (not a 'None' for this to work)
                    #
                    # Always expecting this list to run something like 2000 times.
                    for i in range(delivery_deletes__max_num_of_granules_to_select_per_batch): 
                        # Now can only put something in the list if there is something to pop.  Can only pop if the list is NOT 0, or there will be an error!
                        # Since popping actually changes the array size while inside this first if statement, I have to do the if checking again.
                        len_3__current_length_of_db_chunk_list = len(current_db_chunk_granule_list)
                        if(len_3__current_length_of_db_chunk_list > 0):
                            # This bit of code actually will move the granule off the chunk list and then append it to the 'current_granule_rows_list', which should close the loop on this refactor!
                            granule_to_move = current_db_chunk_granule_list.pop()   # Remove Item from the chunked list
                            current_granule_rows_list.append(granule_to_move)       # Adding the removed item from the chunked list to the original current_granule_rows_list. 

                # Fix for when out of granules (can't handle lenght of None)
                len___current_granule_rows_list = len(current_granule_rows_list)

                # Print how many total granules are left, and how many were selected.
                current_num_of_granules_selected = 0
                #if(current_granule_rows_list == None):
                if(len___current_granule_rows_list == 0):
                    print(f'    No granules selected this iteration... Maybe there are no remaining granules in our local database?')
                    current_num_of_granules_selected = 0
                    current_granule_rows_list = []        # Setting from None to empty list to prevent a for loop error below.
                else:
                    current_num_of_granules_selected = len(current_granule_rows_list)
                    len_4__remaining_chunk_granules = len(current_db_chunk_granule_list)
                    #print(f'    Selected {current_num_of_granules_selected} out of (estimated) {current_granule_rows_remaining_count} remaining Granules')
                    print(f'    Pulled in {current_num_of_granules_selected} out of (estimated) {current_granule_rows_remaining_count} remaining Granules from the current selected chunk.  Selected Chunk Granules Remaining {len_4__remaining_chunk_granules}')
                    #
                    # Setting up the estimate for the next time around the loop.
                    current_granule_rows_remaining_count = current_granule_rows_remaining_count - current_num_of_granules_selected
                    if(current_granule_rows_remaining_count < 0):
                        current_granule_rows_remaining_count = 0

                # If we need Granule Update objects.  This is the place for it.
                #
                # Line 331 (main_interface.py)

                # Force Terminal Output (helps with monitoring progress) # Forces all buffered print statements above to output right now
                sys.stdout.flush()

                # # Actually Process and Try to Delete the granule for the whole batch right here.
                # Only run this part of the loop if we actually selected at least 1 granule from the local database.
                if(current_num_of_granules_selected > 0):
                    try:


                        # Test the AWS Connection
                        is_connected_to_aws_with_valid_creds = test_aws_credentials(is_silent=True)
                        #if test_aws_credentials():
                        if(is_connected_to_aws_with_valid_creds == True):
                            print("    Connected to AWS:  Proceeding with DynamoDB + S3 operations...")
                            

                            # # REFACTOR - Adding Batch Delete Params
                            # is_delete_granules_in_batches=True, max_num_of_granules_per_delete_batch=25
                            # Somewhere here, we need to fork the paths and either delete one at a time, or collect and do a batch delete.
                            #
                            # delete_in_batches_message = f'  To be deleted one S3 File and one DynamoDB Row at a time.'
                            # if(is_delete_granules_in_batches == True):
                            #     delete_in_batches_message = f'  To be deleted in batches of {max_num_of_granules_per_delete_batch} granules.'

                            #print(f'    About to iterate {current_num_of_granules_selected} granules.{delete_in_batches_message}')
                            print(f'    About to iterate {current_num_of_granules_selected} granules.')
                            if(is_delete_granules_in_batches == True):
                                # Collect batches of granules (if there are any granules to collect) and perform delete operations at once on the group
                                print(f'      To be collected and deleted in batches of {max_num_of_granules_per_delete_batch} granules.')
                                
                                # Collect Granules
                                granule_collector__dynamo_db_rows       = []  # This one can only grow to max size of 25 before being reset.
                                granule_collector__s3_file_keypaths     = []  # This one can only grow to max size of 1000.
                                granule_collector__local_db_granule_ids = []  # This one can only grow to max size of ???  // Not limited by either of the two above items
                                #
                                # Iterate all granules in the selection chunk fraction (selection batch)
                                #for current_granule in current_granule_rows_list:
                                for idx, current_granule in enumerate(current_granule_rows_list):

                                    # Will need to know later if this is the last element in the list.
                                    is_last_granule = (idx == len(current_granule_rows_list) - 1)

                                    # Get the DynamoDB file_path (which is also the primary key)
                                    current_granule__DynamoDB_Key__file_path = current_granule.DynamoDB_Key__file_path
                                    dynamoDB_key = {"file_path": f'{current_granule__DynamoDB_Key__file_path}'}

                                    # Get the Granule ID, to be used to provide some validation to the s3 file paths function
                                    current_granule__granule_id = current_granule.granule_id

                                    if(highly_detailed_logging == True):
                                        print(f'      current_granule__granule_id: {current_granule__granule_id}')
                                        print(f'        dynamoDB_key: {dynamoDB_key}')

                                    # Use the 'file_path' value to rebuild the files. 
                                    s3_file_paths, is_error__get_s3_file_paths, error_message__get_s3_file_paths = get_s3_file_paths__from__dynamo_db_file_path_value(DynamoDB_Key__file_path=current_granule__DynamoDB_Key__file_path, granule_id_validate_string=current_granule__granule_id)

                                    # log errors if any so far.
                                    if(is_error__get_s3_file_paths == True):
                                        # In here, there are no attempts to delete being made.
                                        report__num_of_errors = report__num_of_errors + 1
                                        report__error_log.append(error_message__get_s3_file_paths)

                                    # Now add the dynamo_db row and the s3_file_paths to the granule collector arrays.
                                    granule_collector__dynamo_db_rows.append(dynamoDB_key)                          # Adding DynamoDB Primary Keys (1 per granule): [{"file_path": "<path/to/granule/root>/wv01././././<granule_id>"}, {} ]
                                    granule_collector__local_db_granule_ids.append(current_granule__granule_id)     # Adding Granule ID string "<granule_id>".
                                    for s3_file_path in s3_file_paths:
                                        granule_collector__s3_file_keypaths.append(s3_file_path)  # Adding individual s3 key paths (multiple files per granule) "<path/to/granule/root>/wv01././././<granule_id>.<ext>"  # Suffix file names on the granule, sometimes more than just the extension.

                                    #
                                    # If the collector has reached it's max size, it is time to execute the deletes, if not, then just keep looping.
                                    #

                                    # Track if we have filled up the granule collector.
                                    is_granule_collector_full = False

                                    len__granule_collector__dynamo_db_rows = len(granule_collector__dynamo_db_rows)
                                    if(len__granule_collector__dynamo_db_rows < max_num_of_granules_per_delete_batch):
                                        is_granule_collector_full = False

                                        # Now just make extra sure we are not passed the DynamoDB AWS Limit
                                        if(len__granule_collector__dynamo_db_rows == aws_dynamoDB_Max_rows_per_delete):  # 25
                                            # The collector is full if we are at a value that is equal to the AWS Maximum (aws_dynamoDB_Max_rows_per_delete)
                                            is_granule_collector_full = True

                                        # Is this the very last element in the current_granule_rows_list?
                                        if (is_last_granule == True):
                                            # If we are on the last element in the list, the collector is not really full, but we will need to go ahead and do the deletes since there will not be another iteration with the current data in the collectors.
                                            is_granule_collector_full = True

                                    else:
                                        # The collector is full if we are at a value that is equal to the max_num_of_granules_per_delete_batch
                                        is_granule_collector_full = True


                                    # If the granule collector is full,
                                    if(is_granule_collector_full == True):
                                        # Time to do a batch delete and update statements.
                                        
                                        # Control Variables to determine the Update Statement Below
                                        did_any_s3_file_deletes_fail_to_delete  = False
                                        is_any_s3_errors                        = False
                                        is_any_dynamo_db_errors                 = False
                                        is_dynamo_db_record_deleted             = False

                                        # Delete Block for S3
                                        try:
                                            #is_deleted__delete_s3_key,  is_error__delete_s3_key,   error_message__delete_s3_key   = delete_s3_file(bucket= s3_bucket_name, key= s3_file_path)
                                            is_deleted__s3_batch_delete, is_error__s3_batch_delete, error_message__s3_batch_delete = delete_s3_files(bucket=s3_bucket_name, keys=granule_collector__s3_file_keypaths)  # [...]

                                            # Now process if there was an error,
                                            if(is_error__s3_batch_delete == True):
                                                is_any_s3_errors = True
                                                did_any_s3_file_deletes_fail_to_delete = True 
                                                report__error_log.append(error_message__s3_batch_delete)
                                                report__num_of_errors = report__num_of_errors + 1
                                                print(error_message__s3_batch_delete)
                                                sys.stdout.flush()
                                            else:
                                                # If there were no errors, but the file failed to delete somehow.
                                                if(is_deleted__s3_batch_delete == False):
                                                    is_any_s3_errors = True
                                                    did_any_s3_file_deletes_fail_to_delete = True 
                                                    custom_error_message = f'ERROR: No Errors when attempting to batch delete, but the files were not actually deleted.  Further Debuging required here'
                                                    report__error_log.append(custom_error_message)
                                                    report__num_of_errors = report__num_of_errors + 1
                                                    print(custom_error_message)
                                                    sys.stdout.flush()

                                        except:
                                            is_any_s3_errors = True
                                            did_any_s3_file_deletes_fail_to_delete = True 
                                            # Here would be an error deleting an individual specific S3 file path.  (In this block, it's single batch delete operation, so about 150 key paths, not single s3key)
                                            error_message = f'ERROR: There was an unexpected Error while attempting batch delete these s3_file_paths: {granule_collector__s3_file_keypaths}, Batch Number: {i}  Error Info: {e}'
                                            report__error_log.append(error_message)
                                            print(f'    {error_message}')
                                            report__num_of_errors = report__num_of_errors + 1
                                            sys.stdout.flush()


                                        # Similar logic to single s3 key delete, but works for batch deletes as well.
                                        # If ANY of the s3 deletes above failed or all the files were not deleted, then we flip this flag.  Start off assuming everything worked, and then check for the summerized conditions
                                        is_s3_files_all_gone    = True
                                        if(did_any_s3_file_deletes_fail_to_delete == True):
                                            # At least 1 file failed to delete
                                            is_s3_files_all_gone = False
                                        if(is_any_s3_errors == True):
                                            # At least 1 file delete attempt threw an error.
                                            is_s3_files_all_gone = False


                                        # Delete Block for DynamoDB
                                        #
                                        # # Nested In here is: # Delete Block for DynamoDB
                                        # If at this point, there are no S3 errors, than we are good.
                                        # Only proceed if S3 files had no errors and were deleted
                                        if(is_any_s3_errors == False):
                                            if(is_s3_files_all_gone == True):

                                                # Delete Block for DynamoDB
                                                try:
                                                    # Now delete the batch of DynamoDB Records from the server
                                                    #is_deleted__dynamoDB_Row_Delete, is_error__dynamoDB_Row_Delete,  error_message__dynamoDB_Row_Delete  = delete_dynamoDB_row(dynamoDB_table_name= dynamoDB_table_name, dynamoDB_key=dynamoDB_key)
                                                    is_deleted__dynamoDB_BatchDelete, is_error__dynamoDB_BatchDelete, error_message__dynamoDB_BatchDelete = delete_dynamoDB_rows(dynamoDB_table_name=dynamoDB_table_name, dynamoDB_keys=granule_collector__dynamo_db_rows)   # [{...}, {...}, ...]

                                                    # Simulate DynamoDB Errors and/or Success here.  This is for Debug if needed (See run_tests_delete_actions.py for how to set that up right here)

                                                    # Setting the Update Control Variables based on the function return
                                                    is_any_dynamo_db_errors     = is_error__dynamoDB_BatchDelete
                                                    is_dynamo_db_record_deleted = is_deleted__dynamoDB_BatchDelete

                                                    # Capturing the error for the log
                                                    if(is_error__dynamoDB_BatchDelete == True):
                                                        report__error_log.append(error_message__dynamoDB_BatchDelete)
                                                        report__num_of_errors = report__num_of_errors + 1
                                                        print(error_message__dynamoDB_BatchDelete)
                                                        sys.stdout.flush()

                                                except Exception as e:
                                                    # Here would be an error deleting the dynamoDB record
                                                    error_message = f'ERROR: There was an unexpected Error while attempting batch delete DynamoDB rows: {granule_collector__dynamo_db_rows}, Batch Number: {i}  Error Info: {e}'
                                                    report__error_log.append(error_message)
                                                    print(f'    {error_message}')
                                                    report__num_of_errors = report__num_of_errors + 1
                                                    sys.stdout.flush() 

                                        # Update Block for Local SQLite DB
                                        # Update Block
                                        #
                                        # This part is tricky.  
                                        # Since we are treating all the update statements as a single entity during batch deletes (we need this major optimization), then we will just look at the last granule in the batch and use that retry number to set the whole group.
                                        # This also has the added benefit of keeping the logic similar to the single granule delete operation elsewhere in the code (easier to debug).
                                        current_granule_id                      = current_granule.granule_id 
                                        #
                                        current__num_of_attempts_MCP_s3_delete  = current_granule.num_of_attempts_MCP_s3_delete
                                        new__num_of_attempts_MCP_s3_delete      = current__num_of_attempts_MCP_s3_delete + 1
                                        #
                                        current__num_of_attempts_MCP_dynamoDB_delete  = current_granule.num_of_attempts_MCP_dynamoDB_delete
                                        new__num_of_attempts_MCP_dynamoDB_delete      = current__num_of_attempts_MCP_dynamoDB_delete + 1

                                        # DB Reference in Single Granule Delete Area
                                        #
                                        # Update Statment - Including the timing of the function call
                                        time__db_update__start   = time.time()
                                        rows_updated = 0
                                        len__granule_collector__local_db_granule_ids = len(granule_collector__local_db_granule_ids)
                                        if(len__granule_collector__local_db_granule_ids > 0):
                                            rows_updated = DatabaseManager.update__granule__was_attempted_to_delete(db_name_key=db_name_key, granule_id_list=granule_collector__local_db_granule_ids, is_deleted__from_s3=is_s3_files_all_gone, is_deleted__from_dynamo_db=is_dynamo_db_record_deleted, new_num_attempts__s3=new__num_of_attempts_MCP_s3_delete, new_num_attempts__dynamoDB=new__num_of_attempts_MCP_dynamoDB_delete)
                                        #rows_updated = DatabaseManager.update__granule__was_attempted_to_delete(db_name_key=db_name_key, granule_id_list=granule_collector__local_db_granule_ids, is_deleted__from_s3=is_s3_files_all_gone, is_deleted__from_dynamo_db=is_dynamo_db_record_deleted, new_num_attempts__s3=new__num_of_attempts_MCP_s3_delete, new_num_attempts__dynamoDB=new__num_of_attempts_MCP_dynamoDB_delete)
                                        #rows_updated = DatabaseManager.update__granule__was_attempted_to_delete(db_name_key=db_name_key, granule_id_list=[current_granule_id], is_deleted__from_s3=is_s3_files_all_gone, is_deleted__from_dynamo_db=is_dynamo_db_record_deleted, new_num_attempts__s3=new__num_of_attempts_MCP_s3_delete, new_num_attempts__dynamoDB=new__num_of_attempts_MCP_dynamoDB_delete)
                                        #rows_updated = DatabaseManager.update__granule__was_attempted_to_delete(db_name_key=db_name_key, granule_id=current_granule_id, is_deleted__from_s3=is_s3_files_all_gone, is_deleted__from_dynamo_db=is_dynamo_db_record_deleted, new_num_attempts__s3=new__num_of_attempts_MCP_s3_delete, new_num_attempts__dynamoDB=new__num_of_attempts_MCP_dynamoDB_delete)
                                        #print(f'MOCK: DB Update HERE.. Would call Update function with these params: DatabaseManager.update__granule__was_attempted_to_delete(db_name_key={db_name_key}, granule_id={current_granule_id}, is_deleted__from_s3={is_s3_files_all_gone}, is_deleted__from_dynamo_db={is_dynamo_db_record_deleted}, new_num_attempts__s3={new__num_of_attempts_MCP_s3_delete}, new_num_attempts__dynamoDB={new__num_of_attempts_MCP_dynamoDB_delete})')
                                        #
                                        # Time Tracking End
                                        time__db_update__end     = time.time()
                                        time__db_update__elapsed = time__db_update__end - time__db_update__start
                                        time__db_update__elapsed__LIST.append(time__db_update__elapsed)

                                        # Reporting Stuff
                                        # Reporting Paths
                                        # report__num_of_updates_made__localDB_granules_deleted
                                        # report__num_of_updates_made__localDB_granules_NOT_deleted
                                        if(is_s3_files_all_gone == True):
                                            if(is_dynamo_db_record_deleted == True):
                                                # The only path that counts as fully deleted for each run's count.
                                                report__num_of_updates_made__localDB_granules_deleted = report__num_of_updates_made__localDB_granules_deleted + rows_updated # 1
                                            else:
                                                report__num_of_updates_made__localDB_granules_NOT_deleted = report__num_of_updates_made__localDB_granules_NOT_deleted + rows_updated # 1
                                        else:
                                            report__num_of_updates_made__localDB_granules_NOT_deleted = report__num_of_updates_made__localDB_granules_NOT_deleted + rows_updated # 1


                                        # Time to reset the granule collector arrays to prepare for the next delete batch.
                                        if(highly_detailed_logging == True):
                                            len__granule_collector__local_db_granule_ids = len(granule_collector__local_db_granule_ids)
                                            print(f'      Updated {len__granule_collector__local_db_granule_ids} local DB items.')
                                            print(f'        About to reset the granule collector for the next batch')
                                        granule_collector__dynamo_db_rows       = []
                                        granule_collector__s3_file_keypaths     = []
                                        granule_collector__local_db_granule_ids = [] 

                                        # END

                                    else:
                                        # Do nothing, just iterate again so we can add more granules and file paths to the collectors.
                                        pass

                                # END OF:       for idx, current_granule in enumerate(current_granule_rows_list):

                            else:
                                # Delete individual files and individual DynamoDB rows
                                print(f'      To be deleted one S3 File and one DynamoDB Row at a time.')

                                # Iterate all granules in the selection chunk fraction (selection batch)
                                for current_granule in current_granule_rows_list:

                                    #print(f'      FINISH THIS PIPELINE CODE - MAKE THE RIGHT CODE OUT OF THE BELOW PIPELINE NOTES PLAN')
                                    
                                    # # Note, this is the mixing scenario for when we can do this in an automated way
                                    # # This path depends on reconstructing the original Delivery path when we do not have a DynamoDB entry
                                    # # In order to do that, we would need to have an MCP manifest (or full ls directory listing of the MCP Delivery bucket S3 and work from that list rather than the dynamoDB list)
                                    #
                                    # This is where the Pipeline specific logic goes for each granule.
                                    # This is where it differs from how the CMR Validation is done.  In that group, an api reqeust is made, then each granule is processed.
                                    # In this delivery deletes code, there is no api request, just iterate all granules, and log their logic path.
                                    #
                                    # # Pipeline Notes
                                    #
                                    # -Select DynamoDB record, 
                                    #     -If the record does not exist, take note of that (can mean this part was already deleted)
                                    #         -Check the local version and see if we have the S3 files or not (check for existence of S3 files)
                                    #             -If the S3 files exist, then we need to delete them
                                    #                 -Attempt Delete of the S3 Files
                                    #             -If the S3 files do not exist, then we need to record that this granule was already deleted.  (or just 'deleted')
                                    #     -If the record DOES exist
                                    #         -The remote DynamoDB matches the local one I should already have
                                    #             -if it does not match, 
                                    #                 MAYBE-then do an update where the one we just fetched becomes the one saved in SQLite.
                                    #         -Read the DynamoDB record and find the exact files that need to be deleted from S3 (they are all listed in the DynamoDB record)
                                    #         -Attempt Delete of the S3 files
                                    #             -If ALL of the S3 files are not there, then we can assume the missing ones were deleted
                                    #             -Make sure to attempt each one, one at a time inside their own try/catch and record the progress and/errors.
                                    #             -Only when ALL expected files for a single granule are deleted do we count the S3 part as 'deleted'
                                    #         -If Success of ALL of the files, 
                                    #             -then delete the DynamoDB Record
                                    #                 -If delete the DynamoDB Record succeeds, we are done!
                                    # -Only if Both, (a) ALL expected Granule S3 files are deleted, and (b) The DynamoDB record was successfully removed do we count this granule as 'deleted'
                                    #     - (just saying the same thing again!) Only a complete Delete of all related granule s3 files and the DynamoDB record count as 'deleted'

                                    # # Here is the simpler version that soley relies on the state of Dynamo DB (because reconstructing the path from an MCP Manifest requires significantly more compute and effort)
                                    #
                                    # - Attempt to select the DynamoDB record from DynamoDB
                                    #   - If a DynamoDB record is NOT found, 
                                    #     - Update that this granule failed it's delete. (EXIT Granule)
                                    #   - If a DynamoDB record IS found, 
                                    #     - Setup the expected full file paths for the granule
                                    #     - Setup the remaining file that is never part of the DynamoDB Record (CMR file)
                                    #   -  
                                    

                                    # Check for Local DynamoDB Granule (ALL granules should have this, it's in the query)
                                    # // Use the 'file_path' and the above list to rebuild S3 paths to delete (so most of DynamoDB info gets ignored)
                                    # // Make sure to also rebuild the '-cmr.json' file path (from the base path)
                                    # // Delete the S3 files (try catch for each file)
                                    # // If ALL s3 deletes succeeded
                                    #     // Delete the dynamoDB record
                                    #         // Mark it as deleted after passing this part (if it worked or not)
                                    # // if ANY of the s3 deletes failed, update this record to do retries.

                                    # Get the DynamoDB file_path (which is also the primary key)
                                    current_granule__DynamoDB_Key__file_path = current_granule.DynamoDB_Key__file_path
                                    dynamoDB_key = {"file_path": f'{current_granule__DynamoDB_Key__file_path}'}

                                    # Get the Granule ID, to be used to provide some validation to the s3 file paths function
                                    current_granule__granule_id = current_granule.granule_id

                                    if(highly_detailed_logging == True):
                                        print(f'      current_granule__granule_id: {current_granule__granule_id}')
                                        print(f'        dynamoDB_key: {dynamoDB_key}')

                                    # Use the 'file_path' value to rebuild the files. 
                                    #s3_file_paths, is_error__get_s3_file_paths, error_message__get_s3_file_paths = get_s3_file_paths__from__dynamo_db_file_path_value(DynamoDB_Key__file_path=current_granule__DynamoDB_Key__file_path)
                                    s3_file_paths, is_error__get_s3_file_paths, error_message__get_s3_file_paths = get_s3_file_paths__from__dynamo_db_file_path_value(DynamoDB_Key__file_path=current_granule__DynamoDB_Key__file_path, granule_id_validate_string=current_granule__granule_id)
                                    if(is_error__get_s3_file_paths == True):
                                        # In here, there are no attempts to delete being made.
                                        report__num_of_errors = report__num_of_errors + 1
                                        report__error_log.append(error_message__get_s3_file_paths)
                                    else:
                                        # Now Iterate each s3 file path
                                        did_any_s3_file_deletes_fail_to_delete = False
                                        is_any_s3_errors        = False
                                        #
                                        #is_s3_files_all_gone    = False   
                                        
                                        is_any_dynamo_db_errors = False
                                        is_dynamo_db_record_deleted = False
                                        
                                        # Delete Block for S3
                                        for s3_file_path in s3_file_paths:
                                            try:


                                                # This is where to run the actual S3 Delete function
                                                is_deleted__delete_s3_key, is_error__delete_s3_key, error_message__delete_s3_key = delete_s3_file(bucket=s3_bucket_name, key=s3_file_path)
                                                #print(f'MOCK: DELETE S3 Key Path:  This is where the function call goes for: is_deleted, is_error, error_message = delete_s3_file(bucket={s3_bucket_name}, key={s3_file_path})')
                                                
                                                ## Simulating S3 Error Condition
                                                # is_error__delete_s3_key = True
                                                # is_deleted__delete_s3_key = False
                                                # error_message__delete_s3_key = "ERROR: Testing S3 Error functionality."

                                                ## Simulating S3 Deleted Success
                                                # is_error__delete_s3_key = False
                                                # is_deleted__delete_s3_key = True
                                                # error_message__delete_s3_key = ""

                                                # Now process if there was an error,
                                                if(is_error__delete_s3_key == True):
                                                    is_any_s3_errors = True
                                                    did_any_s3_file_deletes_fail_to_delete = True 
                                                    report__error_log.append(error_message__delete_s3_key)
                                                    report__num_of_errors = report__num_of_errors + 1
                                                    print(error_message__delete_s3_key)
                                                    sys.stdout.flush()
                                                    #
                                                    # Do not break out of loop on error.  So we at least attempt all requested deletes for this granule.
                                                    # Break out of the loop
                                                    #break;
                                                else:
                                                    # If there were no errors, but the file failed to delete somehow.
                                                    if(is_deleted__delete_s3_key == False):
                                                        is_any_s3_errors = True
                                                        did_any_s3_file_deletes_fail_to_delete = True 
                                                        custom_error_message = f'ERROR: No Errors when attempting to delete, but the file was not actually deleted.  Further Debuging required here'
                                                        report__error_log.append(error_message__delete_s3_key)
                                                        report__num_of_errors = report__num_of_errors + 1
                                                        print(error_message__delete_s3_key)
                                                        sys.stdout.flush()
                                                        #
                                                        # Do not break out of loop on error.  So we at least attempt all requested deletes for this granule.
                                                        # Break out of the loop
                                                        #break;
                                                        


                                            except Exception as e:
                                                is_any_s3_errors = True
                                                did_any_s3_file_deletes_fail_to_delete = True 
                                                # Here would be an error deleting an individual specific S3 file path.
                                                error_message = f'ERROR: There was an unexpected Error while attempting delete s3_file_path: {s3_file_path}, Batch Number: {i}  Error Info: {e}'
                                                report__error_log.append(error_message)
                                                print(f'    {error_message}')
                                                report__num_of_errors = report__num_of_errors + 1
                                                sys.stdout.flush()

                                        # If ANY of the s3 deletes above failed or all the files were not deleted, then we flip this flag.  Start off assuming everything worked, and then check for the summerized conditions
                                        is_s3_files_all_gone    = True
                                        if(did_any_s3_file_deletes_fail_to_delete == True):
                                            # At least 1 file failed to delete
                                            is_s3_files_all_gone = False
                                        if(is_any_s3_errors == True):
                                            # At least 1 file delete attempt threw an error.
                                            is_s3_files_all_gone = False

                                        # If at this point, there are no S3 errors, than we are good.
                                        # Only proceed if S3 files had no errors and were deleted
                                        if(is_any_s3_errors == False):
                                            if(is_s3_files_all_gone == True):

                                                # Delete Block for DynamoDB
                                                try:
                                                    # Now delete DynamoDB Record from the server
                                                    #is_deleted__dynamoDB_Row_Delete, is_error__dynamoDB_Row_Delete, error_message__dynamoDB_Row_Delete = delete_s3_file(bucket='', key='')
                                                    #print(f'MOCK DELETE DyanmoDB Record:  This is the function call goes for: is_deleted__dynamoDB_Row_Delete, is_error__dynamoDB_Row_Delete, error_message__dynamoDB_Row_Delete = delete_dynamoDB_row(dynamoDB_table_name={dynamoDB_table_name}, dynamoDB_key={dynamoDB_key})')
                                                    is_deleted__dynamoDB_Row_Delete, is_error__dynamoDB_Row_Delete, error_message__dynamoDB_Row_Delete = delete_dynamoDB_row(dynamoDB_table_name=dynamoDB_table_name, dynamoDB_key=dynamoDB_key)                                                
                                                    
                                                    # # Simulating DynamoDB Error Condition
                                                    # #is_any_dynamo_db_errors = True
                                                    # is_deleted__dynamoDB_Row_Delete     = False
                                                    # is_error__dynamoDB_Row_Delete       = True 
                                                    # error_message__dynamoDB_Row_Delete  = "ERROR: Testing DynamoDB Error functionality."
                                                    #
                                                    # # Simulating DynamoDB Success Condition
                                                    # is_deleted__dynamoDB_Row_Delete     = True
                                                    # is_error__dynamoDB_Row_Delete       = False
                                                    # error_message__dynamoDB_Row_Delete  = ""

                                                    # Setting the Update Control Variables based on the function return
                                                    is_any_dynamo_db_errors     = is_error__dynamoDB_Row_Delete
                                                    is_dynamo_db_record_deleted = is_deleted__dynamoDB_Row_Delete

                                                    # Capturing the error for the log
                                                    if(is_error__dynamoDB_Row_Delete == True):
                                                        report__error_log.append(error_message__dynamoDB_Row_Delete)
                                                        report__num_of_errors = report__num_of_errors + 1
                                                        print(error_message__dynamoDB_Row_Delete)
                                                        sys.stdout.flush()


                                                except Exception as e:
                                                    # Here would be an error deleting the dynamoDB record
                                                    error_message = f'ERROR: There was an unexpected Error while attempting delete DynamoDB: {dynamoDB_key}, Batch Number: {i}  Error Info: {e}'
                                                    report__error_log.append(error_message)
                                                    print(f'    {error_message}')
                                                    report__num_of_errors = report__num_of_errors + 1
                                                    sys.stdout.flush()


                                        # Update Block
                                        current_granule_id                      = current_granule.granule_id
                                        #
                                        current__num_of_attempts_MCP_s3_delete  = current_granule.num_of_attempts_MCP_s3_delete
                                        new__num_of_attempts_MCP_s3_delete      = current__num_of_attempts_MCP_s3_delete + 1
                                        #
                                        current__num_of_attempts_MCP_dynamoDB_delete  = current_granule.num_of_attempts_MCP_dynamoDB_delete
                                        new__num_of_attempts_MCP_dynamoDB_delete      = current__num_of_attempts_MCP_dynamoDB_delete + 1


                                        # DB Records
                                        # is_deleted_from_MCP_delivery    = Column(DateTime, nullable=True, index=True)
                                        # is_deleted_from_MCP_dynamoDB    = Column(DateTime, nullable=True, index=True)
                                        #
                                        # last_attempt_MCP_delete             = Column(DateTime, nullable=True, index=True)
                                        # last_attempt_MCP_dynamoDB_delete    = Column(DateTime, nullable=True, index=True)
                                        # #
                                        # num_of_attempts_MCP_s3_delete           = Column(Integer, nullable=False, server_default="0", index=True)
                                        # num_of_attempts_MCP_dynamoDB_delete     = Column(Integer, nullable=False, server_default="0", index=True)
                                        #

                                        # Update Statment - Including the timing of the function call
                                        time__db_update__start   = time.time()
                                        rows_updated = DatabaseManager.update__granule__was_attempted_to_delete(db_name_key=db_name_key, granule_id_list=[current_granule_id], is_deleted__from_s3=is_s3_files_all_gone, is_deleted__from_dynamo_db=is_dynamo_db_record_deleted, new_num_attempts__s3=new__num_of_attempts_MCP_s3_delete, new_num_attempts__dynamoDB=new__num_of_attempts_MCP_dynamoDB_delete)
                                        #rows_updated = DatabaseManager.update__granule__was_attempted_to_delete(db_name_key=db_name_key, granule_id=current_granule_id, is_deleted__from_s3=is_s3_files_all_gone, is_deleted__from_dynamo_db=is_dynamo_db_record_deleted, new_num_attempts__s3=new__num_of_attempts_MCP_s3_delete, new_num_attempts__dynamoDB=new__num_of_attempts_MCP_dynamoDB_delete)
                                        #print(f'MOCK: DB Update HERE.. Would call Update function with these params: DatabaseManager.update__granule__was_attempted_to_delete(db_name_key={db_name_key}, granule_id={current_granule_id}, is_deleted__from_s3={is_s3_files_all_gone}, is_deleted__from_dynamo_db={is_dynamo_db_record_deleted}, new_num_attempts__s3={new__num_of_attempts_MCP_s3_delete}, new_num_attempts__dynamoDB={new__num_of_attempts_MCP_dynamoDB_delete})')
                                        #
                                        # Time Tracking End
                                        time__db_update__end     = time.time()
                                        time__db_update__elapsed = time__db_update__end - time__db_update__start
                                        time__db_update__elapsed__LIST.append(time__db_update__elapsed)

                                        # Reporting Paths
                                        # report__num_of_updates_made__localDB_granules_deleted
                                        # report__num_of_updates_made__localDB_granules_NOT_deleted
                                        if(is_s3_files_all_gone == True):
                                            if(is_dynamo_db_record_deleted == True):
                                                # The only path that counts as fully deleted for each run's count.
                                                report__num_of_updates_made__localDB_granules_deleted = report__num_of_updates_made__localDB_granules_deleted + 1
                                            else:
                                                report__num_of_updates_made__localDB_granules_NOT_deleted = report__num_of_updates_made__localDB_granules_NOT_deleted + 1
                                        else:
                                            report__num_of_updates_made__localDB_granules_NOT_deleted = report__num_of_updates_made__localDB_granules_NOT_deleted + 1
                                    # END OF:   if(is_error__get_s3_file_paths == True):        else:

                                    # Also the end of the forloop... (one tab to the left)

                                    
                                # END OF:       for current_granule in current_granule_rows_list:
                                #print(f'      --  FINISH IN HERE, THIS IS WHERE WE NEXT DO THE CHUNK STUFF, THERE IS A TRY CATCH HERE, AND THEN FURTHER DOWN WE DO THE S3 DELETE, AND THEN THE DYNAMO DB DELETE IF THAT SUCCEEDS, THEN THE UPDATE')
                            # END OF:       if(is_delete_granules_in_batches == True):          else:

                        else:
                            #print("Stopping because AWS credentials are not valid.")
                            error_message = f'ERROR: AWS Credentials Check Failed: Stopping because AWS credentials are not valid.  If running locally, do you have working Short Term Keys?  Unlikely, but is AWS Down?  Batch Number: {i}'
                            report__error_log.append(error_message)
                            print(f'    {error_message}')
                            report__num_of_errors = report__num_of_errors + 1
                            sys.stdout.flush()
                        # END OF:       if(is_connected_to_aws_with_valid_creds == True):       else:
                    
                    except Exception as e:
                        #print(f'    ERROR: There was an unexpected Error while attempting the execute the delivery deletes for this batch.  This could be because of 1 or more individual items.  Is AWS (s3 or dynamoDB or <AWS_Region>) Down?  Batch Number: {i}  Error Info: {e}')
                        error_message = f'ERROR: There was an unexpected Error while attempting the execute the delivery deletes for this batch.  This could be because of 1 or more individual items.  If running locally, do you have working Short Term Keys?  Is AWS (s3 or dynamoDB or <AWS_Region>) Down?  Batch Number: {i}  Error Info: {e}'
                        report__error_log.append(error_message)
                        print(f'    {error_message}')
                        report__num_of_errors = report__num_of_errors + 1
                        sys.stdout.flush()

                else:
                    print(f'    Out of Granules to process for this batch!')
                # END OF:   if(current_num_of_granules_selected > 0):

                # Force Terminal Output (helps with monitoring progress) # Forces all buffered print statements above to output right now
                sys.stdout.flush()

                # # Simulating variable work
                # #time.sleep(3.1)  

                # End of the loop, if needed, wait before starting on the next batch.   (that was only for CMR Requests.  If the volume gets huge during autoamted operations, this part may be necessary for S3 read/writes cap)
                #num_of_seconds_to_sleep, time__loop__elapsed = get_sleep_seconds_to_wait(min_time_needed_to_wait=cmr_checking__min_delay_seconds_between_api_requests, time__start=time__loop__start)
                num_of_seconds_to_sleep = 0.0 # I can Override this with a calculation if a delay ever needs to be forced here.
                time__loop__elapsed = time.time() - time__loop__start   # time__elapsed = time.time() - time__start
                time__loop__elapsed__LIST.append(time__loop__elapsed)
                time__loop__elapsed__rounded_up = math.ceil(time__loop__elapsed)
                #
                current_total_loop_time     = sum(time__loop__elapsed__LIST)
                current_loop_time_count     = len(time__loop__elapsed__LIST)
                #
                print(f'    Total Seconds Elapsed for this Batch: Rounded Up: {time__loop__elapsed__rounded_up}.  Actual: {time__loop__elapsed}.  Total Accumulated Loop time for {current_loop_time_count} Loops: {current_total_loop_time} Seconds')
                if(num_of_seconds_to_sleep > 0.0):
                    print(f'    Batch: {current_batch_number} of {cmr_checking__num_of_batches_to_run}: ...Waiting {num_of_seconds_to_sleep} seconds before next API Request')
                    time.sleep(num_of_seconds_to_sleep)
                print(f'')
                
                # Increment the counter that tracks when a batch is completed
                report__num_of_batches_completed = report__num_of_batches_completed + 1

                print(f'  ------------------------------------------------------------------------')
                print(f'')
                # Force Terminal Output (helps with monitoring progress) # Forces all buffered print statements above to output right now
                sys.stdout.flush()


            except Exception as e:
                #print(f'    ERROR: There was an unexpected Error at the Batch Level.  Is there a problem selecting granules from the Local DB?  Batch Number: {i}  Error Info: {e}')
                error_message = f'ERROR: There was an unexpected Error at the Batch Level.  Is there a problem selecting granules from the Local DB?  Batch Number: {i}  Error Info: {e}'
                report__error_log.append(error_message)
                print(f'    {error_message}')
                report__num_of_errors = report__num_of_errors + 1
                sys.stdout.flush()
            # END OF:       try: single batch

        # END OF:       for i in range(delivery_deletes__num_of_batches_to_run):

    # END OF:   if(can_proceed_with_delete_attempts__TopLevel == False):    else:

    # Now get the counts AFTER  all is done.
    time__db_count__start   = time.time()
    total_remaining_count__AFTER = DatabaseManager.get_count__Granules_Ready_For_Delete(db_name_key=db_name_key, max_retries=delivery_deletes__max_retries)
    time__db_count__end     = time.time()
    time__db_count__elapsed = time__db_count__end - time__db_count__start
    time__db_count__elapsed__LIST.append(time__db_count__elapsed)

    # Calculate how roughly how many granules {report__num_of_chunks_selected} (x {max_db_chunk_size}
    max_db_chunk_capacity_this_run = report__num_of_chunks_selected * max_db_chunk_size


    # # DB Statements - Future, maybe move this repeat thing into a function!
    #
    # Reference lists (defined earlier in the code, near the top where report stuff is defined)
    #time__db_select__elapsed__LIST = []
    #time__db_update__elapsed__LIST = []
    #time__db_count__elapsed__LIST = []
    #time__loop__elapsed__LIST = []         # Not a DB thing, but the entire batch loop.
    #
    # Select Statements
    first_db_select_time    = 0.0
    last_db_select_time     = 0.0
    average_db_select_time  = 0.0
    total_db_select_time    = 0.0
    len__time__db_select__elapsed__LIST = len(time__db_select__elapsed__LIST)
    if(len__time__db_select__elapsed__LIST > 0):
        first_db_select_time    = time__db_select__elapsed__LIST[0]
        last_db_select_time     = time__db_select__elapsed__LIST[-1]
        total_db_select_time    = sum(time__db_select__elapsed__LIST)
        average_db_select_time  = total_db_select_time / len__time__db_select__elapsed__LIST
    #
    # Update Statements
    first_db_update_time    = 0.0
    last_db_update_time     = 0.0
    average_db_update_time  = 0.0
    total_db_update_time    = 0.0
    len__time__db_update__elapsed__LIST = len(time__db_update__elapsed__LIST)
    if(len__time__db_update__elapsed__LIST > 0):
        first_db_update_time    = time__db_update__elapsed__LIST[0]
        last_db_update_time     = time__db_update__elapsed__LIST[-1]
        total_db_update_time    = sum(time__db_update__elapsed__LIST)
        average_db_update_time  = total_db_update_time / len__time__db_update__elapsed__LIST
    #
    # Count Statements
    first_db_count_time     = 0.0
    last_db_count_time      = 0.0
    average_db_count_time   = 0.0
    total_db_count_time     = 0.0
    len__time__db_count__elapsed__LIST = len(time__db_count__elapsed__LIST)
    if(len__time__db_count__elapsed__LIST > 0):
        first_db_count_time     = time__db_count__elapsed__LIST[0]
        last_db_count_time      = time__db_count__elapsed__LIST[-1]
        total_db_count_time     = sum(time__db_count__elapsed__LIST)
        average_db_count_time   = total_db_count_time / len__time__db_count__elapsed__LIST
    #
    #
    # Batch Loop Time Tracking
    first_loop_time     = 0.0
    last_loop_time      = 0.0
    average_loop_time   = 0.0
    total_loop_time     = 0.0
    len__time__loop__elapsed__LIST = len(time__loop__elapsed__LIST)
    if(len__time__loop__elapsed__LIST > 0):
        first_loop_time     = time__loop__elapsed__LIST[0]
        last_loop_time      = time__loop__elapsed__LIST[-1]
        total_loop_time     = sum(time__loop__elapsed__LIST)
        average_loop_time   = total_loop_time / len__time__loop__elapsed__LIST
    #
    #
    print(f'')
    print(f'')
    print(f'# ####################################')
    print(f'###### Diagnostics ###### START ######')
    print(f'#')
    print(f'#   DB: {db_name_key}.  Going from: {total_remaining_count__BEFORE} --to-->: {total_remaining_count__AFTER} granules')
    print(f'#')
    print(f'# DB Statement Times')
    print(f'#')
    print(f'#   Select Statements')
    print(f'#     (total_db_select_time): {total_db_select_time} seconds (with {len__time__db_select__elapsed__LIST} total select statements)')
    print(f'#       (average_db_select_time): {average_db_select_time} seconds (per select statement)')
    print(f'#       (first_db_select_time):     1: {first_db_select_time} seconds')
    print(f'#       (last_db_select_time):    N-1: {last_db_select_time} seconds')
    print(f'#')
    print(f'#   Update Statements')
    print(f'#     (total_db_update_time): {total_db_update_time} seconds (with {len__time__db_update__elapsed__LIST} total update statements)')
    print(f'#       (average_db_update_time): {average_db_update_time} seconds (per update statement)')
    print(f'#       (first_db_update_time):     1: {first_db_update_time} seconds')
    print(f'#       (last_db_update_time):    N-1: {last_db_update_time} seconds')
    print(f'#')
    print(f'#   Count Statements')
    print(f'#     (total_db_count_time):  {total_db_count_time} seconds (with {len__time__db_count__elapsed__LIST} total count statements)')
    print(f'#       (average_db_count_time):  {average_db_count_time} seconds (per count statement)')
    print(f'#       (first_db_count_time):      1: {first_db_count_time} seconds')
    print(f'#       (last_db_count_time):     N-1: {last_db_count_time} seconds')
    print(f'#')
    print(f'#')
    print(f'# Batch Loop Times')
    print(f'#')
    print(f'#   Batch Loop')
    print(f'#     (total_loop_time): {total_loop_time} seconds (with {len__time__loop__elapsed__LIST} total batch loops)')
    print(f'#       (average_loop_time): {average_loop_time} seconds (per batch loop)')
    print(f'#       (first_loop_time):     1: {first_loop_time} seconds')
    print(f'#       (last_loop_time):    N-1: {last_loop_time} seconds')
    print(f'#')
    print(f'#')
    print(f'###### Diagnostics ###### END ######')
    print(f'# ##################################')
    print(f'')

    print(f'')
    print(f'  About to Output the report:  (Settings relisted here in context with the report) ')
    print(f'    Settings:')
    print(f'      is_just_do_all_remaining:                                   {is_just_do_all_remaining}')
    print(f'      delivery_deletes__num_of_batches_to_run:                    {delivery_deletes__num_of_batches_to_run}')
    print(f'      delivery_deletes__max_retries:                              {delivery_deletes__max_retries}')
    print(f'      delivery_deletes__max_num_of_granules_to_select_per_batch:  {delivery_deletes__max_num_of_granules_to_select_per_batch}')
    print(f'    Params:')
    print(f'      db_name_key:                 {db_name_key}')
    print(f'')
    print(f'      highly_detailed_logging:     {highly_detailed_logging}')
    print(f'')
    sys.stdout.flush()
    
    # Final Run Report
    print(f'')
    print(f'############################################################################################################')
    print(f'#')
    print(f'# Delivery Bucket and DynamoDB Deletes and Updating Report: DB: {db_name_key}')
    print(f'# total_remaining_count__BEFORE:    {total_remaining_count__BEFORE}')
    print(f'#')
    print(f'# Number of Chunks Selected:      {report__num_of_chunks_selected} (x {max_db_chunk_size} = Max Chunk Capacity this run: {max_db_chunk_capacity_this_run}).  Actual Granules Selected: {report__total_num_of_granules_selected}')
    print(f'# Number of Batches Attempted:    {report__num_of_batches_attempted}')
    print(f'# Number of Batches Completed:    {report__num_of_batches_completed}')
    print(f'#')
    #
    #
    #print(f'####### IMPORTANT - PUT IN THE REAL VALUES FOR THE PATHS: DRAFT GRANULES_DELETED, GRANULES_NOT_DELETED  ----- RIGHT HERE IS WHERE THE CODE IS TO ADD TO THE REPORT')
    #print(f'####### IMPORTANT - PUT IN THE REAL VALUES FOR THE PATHS: DRAFT GRANULES_DELETED, GRANULES_NOT_DELETED  ----- RIGHT HERE IS WHERE THE CODE IS TO ADD TO THE REPORT')
    #print(f'# Number of Locally Tracked Granules Found in CMR (Already Ingested):          {report__num_of_updates_made__localDB_granules_found_in_cmr}')
    #print(f'# Number of Locally Tracked Granules NOT found in CMR (Needs to be ingested):  {report__num_of_updates_made__localDB_granules_not_found_in_cmr}')
    #print(f'# Number of New Granules Found in CMR (Needs Manifest Verifications):          {report__num_of_updates_made__new_granules_found_in_cmr}')
    print(f'# Number of Locally Tracked Granules Deleted or Already Deleted:                      {report__num_of_updates_made__localDB_granules_deleted}')
    print(f'# Number of Locally Tracked Granules NOT Deleted (Still exist S3 and/or DynamoDB):    {report__num_of_updates_made__localDB_granules_NOT_deleted}')
    #report__num_of_updates_made__localDB_granules_deleted           = 0     # Deleted from both S3 and DynamoDB (Or was already in that state where it was all deleted)
    #report__num_of_updates_made__localDB_granules_NOT_deleted       = 0     # At least an S3 file and/or DynamoDB item was found and Could not be deleted.  This increments the num_of_attempts_counter
    #print(f'####### IMPORTANT - PUT IN THE REAL VALUES FOR THE PATHS: DRAFT GRANULES_DELETED, GRANULES_NOT_DELETED  ----- RIGHT HERE IS WHERE THE CODE IS TO ADD TO THE REPORT')
    #print(f'####### IMPORTANT - PUT IN THE REAL VALUES FOR THE PATHS: DRAFT GRANULES_DELETED, GRANULES_NOT_DELETED  ----- RIGHT HERE IS WHERE THE CODE IS TO ADD TO THE REPORT')
    #
    #
    print(f'#')
    print(f'#')
    print(f'# Number of Errors in the whole process:    {report__num_of_errors}')
    print(f'#  Error Log:')
    sys.stdout.flush()
    error_line_counter = 0
    for error_line in report__error_log:
        print(f'#    {error_line_counter}: {error_line}')
        error_line_counter = error_line_counter + 1
    print(f'#')
    print(f'# total_remaining_count__AFTER:     {total_remaining_count__AFTER}')
    print(f'#')
    print(f'############################################################################################################')

    sys.stdout.flush()


    # Put this at the begining of any of these processes
    # # Total Time Tracking - Start Time
    # time__total__start = time.time()
    #
    # Total Time Tracking - End Time
    time__total__end = time.time()
    #
    # Raw Seconds
    time__total__elapsed = time__total__end - time__total__start  
    #
    # Converting raw seconds into Days, Hours, Minutes, and Seconds
    time_delta = timedelta(seconds=time__total__elapsed)
    # Format the time_delta cleanly into a human-readable single line
    days = time_delta.days
    hours, remainder = divmod(time_delta.seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    #
    # Output the Time Elapsed
    print(f'')
    print(f'  Total Elapsed Time for this run: {time__total__elapsed:.2f} total Seconds ')
    print(f'    Human Readable Total Duration: {days} Days, {hours} Hours, {minutes} Minutes, {seconds} Seconds')
    print(f'      -- Original Time Estimates were: {est_total_hours} Total Hours (rounded up) | {est_total_seconds} Total Seconds')
    
     
    print(f'')




    print(f'')
    print(f'run_integrated_test_01__Delete_Granules_from_S3_and_DynamoDB:      REACHED THE END')
    print(f'')
    #
    # END of:   def run_integrated_test_01__Delete_Granules_from_S3_and_DynamoDB():


# Entry Point
#main_test()
#run_unit_test_01__Select_Granules_For_Deletes()
#run_integrated_test_01__Delete_Granules_from_S3_and_DynamoDB()
#
#run_integrated_test_01__Delete_Granules_from_S3_and_DynamoDB(db_name_key="WV01", delivery_deletes__num_of_batches_to_run=2, delivery_deletes__max_num_of_granules_to_select_per_batch=3, max_db_chunk_size=100000, delivery_deletes__max_retries=3, is_just_do_all_remaining=False, highly_detailed_logging=False)
#run_integrated_test_01__Delete_Granules_from_S3_and_DynamoDB(db_name_key="WV01", delivery_deletes__num_of_batches_to_run=1, delivery_deletes__max_num_of_granules_to_select_per_batch=1, max_db_chunk_size=100000, delivery_deletes__max_retries=3, is_just_do_all_remaining=False, highly_detailed_logging=True)
run_integrated_test_01__Delete_Granules_from_S3_and_DynamoDB(db_name_key="WV04", delivery_deletes__num_of_batches_to_run=1, delivery_deletes__max_num_of_granules_to_select_per_batch=1, max_db_chunk_size=100000, delivery_deletes__max_retries=3, is_just_do_all_remaining=False, highly_detailed_logging=True)

# Production Numbers
#run_integrated_test_01__Delete_Granules_from_S3_and_DynamoDB(db_name_key="WV01", delivery_deletes__num_of_batches_to_run=100, delivery_deletes__max_num_of_granules_to_select_per_batch=2000, delivery_deletes__max_retries=3, is_just_do_all_remaining=False, highly_detailed_logging=True)


# END