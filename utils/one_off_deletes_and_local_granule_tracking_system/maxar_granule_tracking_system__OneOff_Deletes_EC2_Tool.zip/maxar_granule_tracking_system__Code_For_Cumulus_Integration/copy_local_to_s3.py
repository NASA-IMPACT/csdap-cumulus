# copy_local_to_s3.py

# python code/copy_local_to_s3.py
# python copy_local_to_s3.py

# Zip up whatever is in the code subdirectory
# Save the zip in the 'temp_out' as mgts.zip
# Also Save the zip in the 'out_zips_versions' sub directory but with a datetime in the file name (like mtgs_YYYY_MM_DD__HH_MM.zip)
# Copy the file from 'temp_out/mgts.zip' over to the S3 bucket.

# Meant to be used from a local machine developing code.

# Working Directory is the directory that has this script in it.  It is expected that there is a subdirectory called, 'code' which has the requirements.txt file in it.

import os
import zipfile
import shutil
from datetime import datetime
#
import boto3
from botocore.exceptions import NoCredentialsError

# Settings
SETTINGS__local_dir_path__code          = 'code/'                                               # Local Directory that contains code being worked on
SETTINGS__local_dir_path__temp_out      = 'temp_out/'                                           # Local Directory where the zipped file goes -- that will get copied and sent to S3
SETTINGS__local_dir_path__zip_versions  = 'out_zips_versions/'                                  # Local Directory where versioned zipped files will go.
SETTINGS__local_file_name_prefix        = 'mgts'                                                # File name part that is used as the prefix for the zipped file names.
SETTINGS__out_s3_bucket_name            = '<gts-utilities-bucket-name>'                         # Output Destination - S3 Bucket Name where code transfers go
SETTINGS__out_s3_key_path               = '<Code_Destination_Key_Path>/mgts.zip'                # Output Destination - Key Path up to the file name.

# Zip all the files in the code directory

# Lists all the files in the directory path.
def get_all_files(in_directory_path):
    # Returns a list of filenames in the specified directory
    try:
        return [f for f in os.listdir(in_directory_path) if os.path.isfile(os.path.join(in_directory_path, f))]
    except FileNotFoundError:
        return "Directory not found."

# Usage
# files = get_all_files(SETTINGS__local_dir_path__code)

# Zip the code directory
def zip_entire_directory(in_directory_path, output_dir, output_filename="myfile_full"):
    # Ensure the output directory exists
    os.makedirs(output_dir, exist_ok=True)

    # Define the full path (shutil.make_archive adds .zip automatically)
    full_output_path = os.path.join(output_dir, output_filename)

    # This will create "myfile_full.zip" containing everything in in_directory_path
    # Note: make_archive adds the '.zip' extension automatically
    shutil.make_archive(full_output_path, 'zip', in_directory_path)
    print(f"Archive '{full_output_path}.zip' created successfully.")

# Zip the code directory, but add the utc date time to the file name
def zip_entire_dir_with_timestamp(in_directory_path, output_dir, output_filename="myfile_full"):
    # Ensure the output directory exists
    os.makedirs(output_dir, exist_ok=True)

    # Define the full path (shutil.make_archive adds .zip automatically)
    #full_output_path = os.path.join(output_dir, output_filename)
    #output_name = f"{output_filename}_{timestamp}"
    timestamp = datetime.utcnow().strftime("%Y_%m_%d__%H_%M")
    output_filename_with_timestamp = f"{output_filename}_{timestamp}"
    full_output_path = os.path.join(output_dir, output_filename_with_timestamp)
    shutil.make_archive(full_output_path, 'zip', in_directory_path)
    print(f"Archive '{full_output_path}.zip' created successfully.")

# Upload to S3
#
# # Usage
# upload_zip_to_s3()
def upload_zip_to_s3():
    # Construct the local path
    local_file = f"{SETTINGS__local_dir_path__temp_out}{SETTINGS__local_file_name_prefix}.zip"
    
    # Initialize the S3 client
    # Boto3 automatically looks for environment variables for credentials
    s3_client = boto3.client('s3')

    # To set Credentials, do this (Mac Instructions)
    # export AWS_ACCESS_KEY_ID='your_access_key_here'
    # export AWS_SECRET_ACCESS_KEY='your_secret_key_here'
    # export AWS_DEFAULT_REGION='<AWS_Region>' # or your specific region
    
    try:
        print(f"Uploading {local_file} to s3://{SETTINGS__out_s3_bucket_name}/{SETTINGS__out_s3_key_path}...")
        
        s3_client.upload_file(
            Filename=local_file,
            Bucket=SETTINGS__out_s3_bucket_name,
            Key=SETTINGS__out_s3_key_path
        )
        
        print("Upload Successful!")
    except FileNotFoundError:
        print(f"The local file {local_file} was not found.")
    except NoCredentialsError:
        print(f'')
        print(f'************************** ERROR COPYING FILES TO S3 **************************')
        print(f'')
        print("Credentials not available. Please check your environment variables.")
        print(f'')
        print(f'  You may have to go get credentials and then run these commands before running this script:')
        print(f"    export AWS_ACCESS_KEY_ID='your_access_key_here'")
        print(f"    export AWS_SECRET_ACCESS_KEY='your_secret_key_here'")
        print(f"    export AWS_SESSION_TOKEN='your_session_token'")
        print(f"    export AWS_DEFAULT_REGION='<AWS_Region>' # or your specific region")
        print(f'')
        print(f'************************** ERROR COPYING FILES TO S3 **************************')
        print(f'')
    except Exception as e:
        print(f"An error occurred: {e}")



# Main Entry Point
def main():
    print(f'')
    print(f'About to zip files and send to S3')
    print(f'')
    list_of_files = get_all_files(in_directory_path=SETTINGS__local_dir_path__code)
    print(f'  Files Found: {list_of_files}')
    print(f'')
    print(f'Creating Zip Files.')
    zip_entire_directory(         in_directory_path=SETTINGS__local_dir_path__code, output_dir=SETTINGS__local_dir_path__temp_out,     output_filename=SETTINGS__local_file_name_prefix)
    zip_entire_dir_with_timestamp(in_directory_path=SETTINGS__local_dir_path__code, output_dir=SETTINGS__local_dir_path__zip_versions, output_filename=SETTINGS__local_file_name_prefix)
    print(f'')
    print(f'Zip files created.  About to send to S3 Bucket: {SETTINGS__out_s3_bucket_name} to KeyPath {SETTINGS__out_s3_key_path}')
    upload_zip_to_s3()
    print(f'')
    print(f'Should be all done now.')

    pass

main()