# copy_s3_to_ec2_local.py

# Grab zip file from specific S3 location
# Extract and replace files located in the code directory

# Meant to be used on the EC2 Instance when pulling code down.
# To avoid the checkin and the egg problem, you may have to copy the contents of this file and manually create it on the EC2 instance with vim.
# Alternatively, To keep it real simple, you could also do a git clone from the repo while logged into the EC2 instance

# Run this from the dir:
# /root/dev/gts_code 				// Executable Python Code
# /drive1n1/app/data/gts_code       // Executable Python Code

import os
import boto3
import zipfile

# Settings
SETTINGS__local_dir_path__code          = 'code/'                                               # Local Directory that contains code being worked on
SETTINGS__in_s3_key_path               	= '<Code_Destination_Key_Path>/mgts.zip'                # Input Source - Key Path up to the file name.
SETTINGS__in_s3_bucket_name            	= '<gts-utilities-bucket-name>'                         # Input Source - S3 Bucket Name where code transfers go
SETTINGS__local_dir_path__temp_in       = 'temp_in/'                                           	# Local Directory where the zipped file will be recieved -- that will get downloaded from S3 to local dir
SETTINGS__local_file_name_prefix 		= 'mgts' 												# First part of the File Name

def download_and_extract_from_s3():
    # Define where the zip will be saved locally before extraction
    local_zip_path = os.path.join(SETTINGS__local_dir_path__temp_in, f"{SETTINGS__local_file_name_prefix}_downloaded.zip")
    
    # Ensure the temp directory exists
    os.makedirs(SETTINGS__local_dir_path__temp_in, exist_ok=True)
    # Ensure the extraction directory exists
    os.makedirs(SETTINGS__local_dir_path__code, exist_ok=True)
    
    s3_client = boto3.client('s3')
    
    try:
        print(f"Downloading from S3: {SETTINGS__in_s3_key_path}...")
        
        # 1. Download the file
        s3_client.download_file(
            Bucket=SETTINGS__in_s3_bucket_name,
            Key=SETTINGS__in_s3_key_path,
            Filename=local_zip_path
        )
        
        # 2. Extract the file
        print(f"Extracting to {SETTINGS__local_dir_path__code}...")
        with zipfile.ZipFile(local_zip_path, 'r') as zip_ref:
            zip_ref.extractall(SETTINGS__local_dir_path__code)
            
        print("Extraction complete!")
        
        # Optional: Clean up the downloaded zip file after extraction
        #os.remove(local_zip_path)
        #print("Temp zip file removed!")
        
    except Exception as e:
        print(f"An error occurred: {e}")

# Usage 
# download_and_extract_from_s3()


# Entry Point
download_and_extract_from_s3()