#!/usr/bin/env bash

# backup_working_dir_to_s3.sh

# On the Server, run this from: 	/drive1n1/app/data/gts_code
# sh backup_working_dir_to_s3.sh

# 1. Step out of the gts_code directory to target it from the outside
cd ..

# 2. Create a timestamped zip file of the gts_code directory
zip -r gts_code_$(date +%Y%m%d_%H%M%S).zip gts_code/

# 3. Upload the created zip file to your S3 backup path
aws s3 cp . s3://<gts-utilities-bucket-name>/<Code_Destination_Key_Path>/ --recursive --exclude "*" --include "gts_code_*.zip"

# 4. Delete the local zip file to save space on your EC2 drive
rm gts_code_*.zip